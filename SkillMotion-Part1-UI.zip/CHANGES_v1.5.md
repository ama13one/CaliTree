# CaliTree 1.5 changes

## Workout planner
- Added a dedicated Persian "برنامه" tab.
- Select 7, 14, 30, 45, or 60 days.
- Select easier, balanced, or more challenging suggestions. Suggestions are limited to skills whose prerequisites are already unlocked.
- Select 1–3 short sessions per day.
- Mark a suggested session complete, skip a day, or advance the schedule by two days.
- Restart the plan after completing it.
- Plan settings and current day/session are saved locally on the device.

## Color themes
- Added green, blue, red, purple, ocean, and multicolor sunset palettes.
- Palette selection is separate from system/light/dark appearance.

## Safety notes
- The planner does not force missed sessions to be made up in one day.
- Users are reminded that rest is part of training and to progress gradually.

## Build
The project uses Android Gradle Plugin and Kotlin/Compose settings already in the repository. Open the project in Android Studio or run `gradle assembleDebug` in an environment with Android SDK and Gradle installed. The local environment used to prepare this ZIP did not have Gradle installed, so a local APK build could not be verified here.

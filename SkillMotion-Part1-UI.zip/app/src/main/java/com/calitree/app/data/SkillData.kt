package com.calitree.app.data

/** Compact builder. pre = comma separated prerequisite ids, steps = pipe separated. */
internal fun sk(
    id: String,
    tree: TreeId,
    name: String,
    d: Int,
    lane: Int,
    pre: String,
    desc: String,
    req: String,
    vol: String,
    goal: String,
    steps: String,
    tip: String
): Skill = Skill(
    id = id,
    tree = tree,
    name = name,
    difficulty = d,
    lane = lane,
    prereqs = if (pre.isBlank()) emptyList() else pre.split(","),
    description = desc,
    requirement = req,
    volume = vol,
    goal = goal,
    steps = steps.split("|"),
    tip = tip
)

object SkillData {
    val all: List<Skill> = pushSkills() + pullSkills() + legsSkills() + coreSkills() +
        handstandSkills() + leverSkills() + plancheSkills() + flagSkills() + ringSkills()

    val byId: Map<String, Skill> = all.associateBy { it.id }

    private val nextMap: Map<String, List<Skill>> = all
        .flatMap { s -> s.prereqs.map { p -> p to s } }
        .groupBy({ it.first }, { it.second })

    private val levelCache = HashMap<String, Int>()

    fun inTree(tree: TreeId): List<Skill> = all.filter { it.tree == tree }

    fun nextOf(id: String): List<Skill> = nextMap[id] ?: emptyList()

    /** Row of the skill inside its own tree (longest chain of same-tree prerequisites). */
    fun level(id: String): Int {
        val cached = levelCache[id]
        if (cached != null) return cached
        val s = byId[id] ?: return 0
        val same = s.prereqs.mapNotNull { byId[it] }.filter { it.tree == s.tree }
        val result = if (same.isEmpty()) 0 else same.maxOf { level(it.id) } + 1
        levelCache[id] = result
        return result
    }
}

package com.calitree.app.data

/**
 * Exercise demonstration data.
 *
 * Every skill id has exactly one Demo (see DemoData.forId). The animation itself is a tiny
 * vector description (a few key poses of a stick figure plus props like a bar or a wall),
 * so all 132 demonstrations together are only a few kilobytes and work fully offline.
 *
 * mediaUrl is reserved for optional remote media. It is null for every exercise today; if it is
 * ever filled in, the UI should still fall back to the offline vector animation.
 */
enum class MediaType { VECTOR_ANIMATION }

data class Prop(val kind: Int, val a: Float, val b: Float, val c: Float, val d: Float)

/** poses: each pose has 14 numbers (see tools/lib.py). */
class Motion(
    val ymin: Float,
    val ymax: Float,
    val hold: Boolean,
    val props: List<Prop>,
    val poses: List<FloatArray>
)

data class Demo(
    val id: String,
    val mediaType: MediaType,
    val mediaResource: String,
    val mediaUrl: String?,
    val formTips: List<String>,
    val commonMistakes: List<String>
)

object DemoData {
    private val cache = HashMap<String, Motion>()

    fun motion(resource: String): Motion {
        val cached = cache[resource]
        if (cached != null) return cached
        val parsed = parse(MOTION_DATA.getValue(resource))
        cache[resource] = parsed
        return parsed
    }

    /** The demonstration that belongs to a skill / exercise id. */
    fun forId(id: String): Demo? {
        if (!MOTION_DATA.containsKey(id)) return null
        val family = DEMO_FAMILY[id] ?: return null
        val tips = (DEMO_TIPS[family] ?: "").split("|").filter { it.isNotBlank() }
        val mistakes = (DEMO_MISTAKES[id] ?: "").split("|").filter { it.isNotBlank() }
        return Demo(id, MediaType.VECTOR_ANIMATION, id, null, tips, mistakes)
    }

    private fun parse(s: String): Motion {
        val parts = s.split("#")
        val head = parts[0].trim().split(" ")
        val props = parts[1].split(";").filter { it.isNotBlank() }.map { raw ->
            val v = raw.trim().split(" ").map { it.toFloat() }
            Prop(v[0].toInt(), v[1], v[2], v[3], v[4])
        }
        val poses = parts[2].split("|").map { raw ->
            raw.trim().split(" ").map { it.toFloat() }.toFloatArray()
        }
        return Motion(head[0].toFloat(), head[1].toFloat(), head[2] == "1", props, poses)
    }
}

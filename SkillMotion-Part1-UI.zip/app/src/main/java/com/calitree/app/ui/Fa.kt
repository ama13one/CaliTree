package com.calitree.app.ui

import android.icu.text.SimpleDateFormat
import android.icu.util.ULocale
import java.util.Date

private const val FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"

/** Replaces every ASCII digit (0-9) with the matching Persian digit. */
fun faDigits(s: String): String {
    val sb = StringBuilder(s.length)
    for (c in s) {
        sb.append(if (c in '0'..'9') FA_DIGITS[c - '0'] else c)
    }
    return sb.toString()
}

/** An integer written with Persian digits. */
fun fa(n: Int): String = faDigits(n.toString())

private val persianDateFormat: SimpleDateFormat by lazy {
    SimpleDateFormat("d MMMM y", ULocale("fa_IR@calendar=persian"))
}

/** A date in the Persian (Jalali) calendar with Persian digits, for example ۲۱ مهر ۱۴۰۵. */
fun faDate(millis: Long): String = faDigits(persianDateFormat.format(Date(millis)))

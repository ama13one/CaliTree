package com.calitree.app

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.calitree.app.data.ProgressStore
import com.calitree.app.ui.CaliApp
import java.util.Locale

class MainActivity : ComponentActivity() {
    /** Persian is the only language: always use the fa-IR locale and a right-to-left layout. */
    override fun attachBaseContext(newBase: Context) {
        val locale = Locale("fa", "IR")
        Locale.setDefault(locale)
        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProgressStore(applicationContext)
        setContent { CaliApp(store) }
    }
}

package com.calitree.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore

@Composable
fun WelcomeScreen(store: ProgressStore) {
    var name by remember { mutableStateOf(store.name) }
    var motivation by remember { mutableStateOf(store.motivation) }
    var pushups by remember { mutableStateOf(store.pushupBaseline.toString()) }
    var pullups by remember { mutableStateOf(store.pullupBaseline.toString()) }
    var visible by remember { mutableStateOf(false) }
    val pulse = rememberInfiniteTransition(label = "welcomePulse")
    val scale by pulse.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoPulse"
    )
    androidx.compose.runtime.LaunchedEffect(Unit) { visible = true }
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(cs.primaryContainer, cs.background, cs.background)))
            .padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(650)) + slideInVertically(initialOffsetY = { it / 8 }, animationSpec = tween(650))
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = cs.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("💪", modifier = Modifier.scale(scale), style = MaterialTheme.typography.displayLarge)
                    Text(
                        "به ${store.appName.ifBlank { "کالی‌تری" }} خوش آمدی!",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        "این مسیر مال توست؛ قدم‌به‌قدم قوی‌تر شو.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("اسمت چیه؟") },
                        placeholder = { Text("اسم خودت را بنویس") }
                    )
                    Text("💪 ارزیابی اولیه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("تعداد تقریبی را وارد کن؛ اگر هنوز نمی‌توانی، صفر بنویس.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                    OutlinedTextField(value = pushups, onValueChange = { pushups = it.filter(Char::isDigit).take(3) }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("چند شنای معمولی می‌توانی بزنی؟") })
                    OutlinedTextField(value = pullups, onValueChange = { pullups = it.filter(Char::isDigit).take(3) }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("چند بارفیکس می‌توانی بزنی؟") })
                    OutlinedTextField(
                        value = motivation,
                        onValueChange = { motivation = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        label = { Text("جمله‌ی انگیزشی (اختیاری)") },
                        placeholder = { Text("مثلاً: هر روز یک قدم جلوتر می‌روم.") }
                    )
                    Button(
                        onClick = { store.completeOnboarding(name, motivation); store.saveFitnessBaseline(pushups.toIntOrNull() ?: 0, pullups.toIntOrNull() ?: 0) },
                        enabled = name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("شروع مسیر من 🚀", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "این اطلاعات فقط روی همین گوشی ذخیره می‌شود.",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

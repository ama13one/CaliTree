@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData

@Composable
fun SearchScreen(
    store: ProgressStore,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim().lowercase()
    val results = if (q.isEmpty()) {
        SkillData.all
    } else {
        SkillData.all.filter {
            it.name.lowercase().contains(q) ||
                it.tree.title.lowercase().contains(q) ||
                it.description.lowercase().contains(q)
        }
    }

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            "جست‌وجو",
            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("جست‌وجوی تمرین، مثلاً پلانش") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "پاک کردن")
                    }
                }
            }
        )
        Text(
            fa(results.size) + " تمرین",
            modifier = Modifier.padding(vertical = 8.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (results.isEmpty()) {
            Text(
                "هیچ تمرینی با جست‌وجوی شما مطابقت ندارد.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(results, key = { it.id }) { s ->
                    SkillRow(s, store.statusOf(s), store.isFavorite(s.id), { onOpen(s.id) })
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(
    store: ProgressStore,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val favorites = SkillData.all.filter { store.isFavorite(it.id) }

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            "علاقه‌مندی‌ها",
            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        if (favorites.isEmpty()) {
            Text(
                "هنوز علاقه‌مندی‌ای ندارید. یک تمرین را باز کنید و روی قلب بالای صفحه بزنید تا اینجا ذخیره شود.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(favorites, key = { it.id }) { s ->
                    SkillRow(s, store.statusOf(s), true, { onOpen(s.id) })
                }
            }
        }
    }
}

package com.calitree.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.R
import com.calitree.app.data.Demo
import com.calitree.app.data.DemoData
import com.calitree.app.data.Motion
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// Body proportions. These must match tools/lib.py.
private const val LT = 0.30f
private const val UA = 0.17f
private const val FA = 0.17f
private const val TH = 0.25f
private const val SH = 0.25f
private const val HEAD_R = 0.062f
private const val HEAD_D = 0.125f

private const val X_MIN = -0.4f
private const val X_SPAN = 2.0f

private const val PHASE_START = 0
private const val PHASE_MOVE = 1
private const val PHASE_END = 2

private class Seg(val dur: Float, val from: Int, val to: Int, val phase: Int)

private fun buildSegs(m: Motion): List<Seg> {
    val n = m.poses.size
    val segs = ArrayList<Seg>()
    segs.add(Seg(0.8f, 0, 0, PHASE_START))
    for (i in 0 until n - 1) segs.add(Seg(0.95f, i, i + 1, PHASE_MOVE))
    segs.add(Seg(if (m.hold) 2.4f else 0.8f, n - 1, n - 1, PHASE_END))
    for (i in n - 1 downTo 1) segs.add(Seg(0.85f, i, i - 1, PHASE_MOVE))
    return segs
}

private fun rad(deg: Float): Float = (deg * (PI / 180.0)).toFloat()

private fun smooth(u: Float): Float = u * u * (3f - 2f * u)

private fun phaseAt(segs: List<Seg>, time: Float): Int {
    var t = time
    for (s in segs) {
        if (t < s.dur) return s.phase
        t -= s.dur
    }
    return PHASE_START
}

private fun poseAt(m: Motion, segs: List<Seg>, time: Float, out: FloatArray) {
    var t = time
    var seg = segs[segs.size - 1]
    var u = 1f
    for (s in segs) {
        if (t < s.dur) {
            seg = s
            u = t / s.dur
            break
        }
        t -= s.dur
    }
    val a = m.poses[seg.from]
    val b = m.poses[seg.to]
    val k = if (seg.from == seg.to) 0f else smooth(u.coerceIn(0f, 1f))
    for (i in 0 until 12) {
        out[i] = if (i == 2) {
            // torso angle: take the shortest way round
            val da = ((b[2] - a[2] + 540f) % 360f) - 180f
            a[2] + da * k
        } else {
            a[i] + (b[i] - a[i]) * k
        }
    }
    out[12] = if (k < 0.5f) a[12] else b[12]
    out[13] = if (k < 0.5f) a[13] else b[13]
}

/** Two-bone IK. Returns [jointX, jointY, endX, endY]. */
private fun ik(ax: Float, ay: Float, tx: Float, ty: Float, l1: Float, l2: Float, sign: Float, r: FloatArray) {
    val dx = tx - ax
    val dy = ty - ay
    val dist = hypot(dx, dy)
    if (dist < 1e-6f) {
        r[0] = ax; r[1] = ay - l1; r[2] = ax; r[3] = ay - l1 - l2
        return
    }
    val ux = dx / dist
    val uy = dy / dist
    var d = min(dist, l1 + l2 - 1e-4f)
    d = max(d, abs(l1 - l2) + 1e-4f)
    val a = (l1 * l1 - l2 * l2 + d * d) / (2f * d)
    val h = sqrt(max(0f, l1 * l1 - a * a))
    r[0] = ax + a * ux + sign * h * (-uy)
    r[1] = ay + a * uy + sign * h * ux
    r[2] = ax + d * ux
    r[3] = ay + d * uy
}

private class DemoColors(
    val figure: Color,
    val farLimb: Color,
    val prop: Color,
    val floor: Color,
    val fill: Color
)

private fun DrawScope.drawDemo(m: Motion, p: FloatArray, c: DemoColors) {
    val w = size.width
    val h = size.height
    val ySpan = m.ymax - m.ymin
    val sc = min(w / X_SPAN, h / ySpan)
    val padX = (w - X_SPAN * sc) / 2f
    val padY = (h - ySpan * sc) / 2f
    fun sx(x: Float): Float = padX + (x - X_MIN) * sc
    fun sy(y: Float): Float = h - padY - (y - m.ymin) * sc
    fun pt(x: Float, y: Float): Offset = Offset(sx(x), sy(y))

    // ---- props ----
    for (pr in m.props) {
        when (pr.kind) {
            0 -> drawLine(c.floor, pt(X_MIN, 0f), pt(X_MIN + X_SPAN, 0f), strokeWidth = 2.dp.toPx())
            1 -> {
                drawLine(c.prop, pt(pr.a - 0.13f, pr.b), pt(pr.a + 0.13f, pr.b), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
            }
            2 -> drawLine(c.prop, pt(pr.a, 0f), pt(pr.a, m.ymax), strokeWidth = 4.dp.toPx())
            3 -> {
                val tl = pt(pr.a, pr.d)
                val sz = Size((pr.c - pr.a) * sc, (pr.d - pr.b) * sc)
                drawRect(c.fill, topLeft = tl, size = sz)
                drawRect(c.prop, topLeft = tl, size = sz, style = Stroke(width = 1.5.dp.toPx()))
            }
            4 -> {
                drawLine(c.floor, pt(pr.a, pr.b + 0.04f), pt(pr.a, m.ymax), strokeWidth = 1.5.dp.toPx())
                drawCircle(c.prop, radius = 0.04f * sc, center = pt(pr.a, pr.b), style = Stroke(width = 2.5.dp.toPx()))
            }
            5 -> drawLine(c.prop, pt(pr.a, 0f), pt(pr.a, m.ymax), strokeWidth = 5.dp.toPx())
            6 -> drawLine(c.prop, pt(pr.a, pr.b), pt(pr.c, pr.d), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        }
    }

    // ---- figure ----
    val hipX = p[0]
    val hipY = p[1]
    val ta = rad(p[2])
    val shX = hipX + LT * cos(ta)
    val shY = hipY + LT * sin(ta)
    val ha = rad(p[2] + p[3])
    val headX = shX + HEAD_D * cos(ha)
    val headY = shY + HEAD_D * sin(ha)

    val r = FloatArray(4)
    val limb = 0.036f * sc
    val torso = 0.055f * sc

    fun limbDraw(color: Color, ax: Float, ay: Float, tx: Float, ty: Float, l1: Float, l2: Float, sign: Float) {
        ik(ax, ay, tx, ty, l1, l2, sign, r)
        drawLine(color, pt(ax, ay), pt(r[0], r[1]), strokeWidth = limb, cap = StrokeCap.Round)
        drawLine(color, pt(r[0], r[1]), pt(r[2], r[3]), strokeWidth = limb, cap = StrokeCap.Round)
    }

    // far limbs first
    limbDraw(c.farLimb, shX, shY, p[6], p[7], UA, FA, p[12])
    limbDraw(c.farLimb, hipX, hipY, p[10], p[11], TH, SH, p[13])
    // torso
    drawLine(c.figure, pt(hipX, hipY), pt(shX, shY), strokeWidth = torso, cap = StrokeCap.Round)
    // near limbs
    limbDraw(c.figure, hipX, hipY, p[8], p[9], TH, SH, p[13])
    limbDraw(c.figure, shX, shY, p[4], p[5], UA, FA, p[12])
    // head
    drawCircle(c.figure, radius = HEAD_R * sc, center = pt(headX, headY))
}

@Composable
fun DemoPlayer(skillName: String, demo: Demo, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val motion = remember(demo.mediaResource) { DemoData.motion(demo.mediaResource) }
    val segs = remember(motion) { buildSegs(motion) }
    val cycle = remember(segs) { segs.sumOf { it.dur.toDouble() }.toFloat() }

    var time by remember(demo.id) { mutableStateOf(0f) }
    var playing by remember(demo.id) { mutableStateOf(true) }
    val phase by remember(segs) { derivedStateOf { phaseAt(segs, time) } }

    // The loop only runs while this composable is on screen and playing.
    LaunchedEffect(playing, cycle, demo.id) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = (now - last) / 1_000_000_000f
                last = now
                time = (time + dt) % cycle
            }
        }
    }

    val colors = DemoColors(
        figure = cs.primary,
        farLimb = cs.primary.copy(alpha = 0.45f),
        prop = cs.onSurfaceVariant,
        floor = cs.outline,
        fill = cs.surface
    )
    val pose = remember(demo.id) { FloatArray(14) }
    val description = skillName + " " + stringResource(R.string.demo_description_suffix)

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = cs.surfaceVariant
    ) {
        Column(Modifier.padding(bottom = 4.dp)) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(X_SPAN / 1.4f)
                    .semantics { contentDescription = description }
            ) {
                poseAt(motion, segs, time, pose)
                drawDemo(motion, pose, colors)
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PhaseLabel(stringResource(R.string.demo_start), phase == PHASE_START)
                PhaseLabel(stringResource(R.string.demo_movement), phase == PHASE_MOVE)
                PhaseLabel(
                    stringResource(if (motion.hold) R.string.demo_hold else R.string.demo_end),
                    phase == PHASE_END
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = {
                    time = 0f
                    playing = true
                }) { Text(stringResource(R.string.demo_replay)) }
                TextButton(onClick = { playing = !playing }) {
                    Text(stringResource(if (playing) R.string.demo_pause else R.string.demo_play))
                }
            }
        }
    }
}

@Composable
private fun PhaseLabel(text: String, active: Boolean) {
    val cs = MaterialTheme.colorScheme
    Text(
        text,
        modifier = Modifier.padding(end = 14.dp),
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
        color = if (active) cs.primary else cs.onSurfaceVariant
    )
}

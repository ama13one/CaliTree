package com.calitree.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.calitree.app.data.difficultyLabel

/**
 * The five difficulty levels and their colors. This is the single place that maps a skill's
 * existing difficulty number (1..5) to a color, so the tree, the lists, the detail screen and the
 * legend always agree.
 *
 *  1 green  = easy                 2 yellow = fairly easy / beginner-friendly
 *  3 orange = intermediate         4 red    = hard           5 purple = advanced
 */
private val DifficultyPalette = listOf(
    Color(0xFF22C55E), // 1 green
    Color(0xFFFACC15), // 2 yellow
    Color(0xFFF97316), // 3 orange
    Color(0xFFEF4444), // 4 red
    Color(0xFFA855F7)  // 5 purple
)

fun difficultyColor(d: Int): Color = DifficultyPalette[d.coerceIn(1, 5) - 1]

/** Text color that stays readable on top of [difficultyColor]. */
private fun difficultyOnColor(d: Int): Color =
    if (d >= 4) Color.White else Color(0xFF111827)

/**
 * A round badge in the difficulty color. It shows the level number so the level is also readable
 * without relying on color alone. It never changes with completion status.
 */
@Composable
fun DifficultyBadge(difficulty: Int, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    val label = "سطح دشواری " + fa(difficulty.coerceIn(1, 5)) + ": " + difficultyLabel(difficulty)
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(difficultyColor(difficulty))
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        Text(
            fa(difficulty.coerceIn(1, 5)),
            color = difficultyOnColor(difficulty),
            fontSize = (size.value * 0.5f).sp,
            lineHeight = (size.value * 0.5f).sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/** One-line legend that explains the five colors. */
@Composable
fun DifficultyLegend(modifier: Modifier = Modifier) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (d in 1..5) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(difficultyColor(d))
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    difficultyLabel(d),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

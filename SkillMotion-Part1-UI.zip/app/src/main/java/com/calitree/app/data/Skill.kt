package com.calitree.app.data

enum class TreeId(val title: String, val tagline: String) {
    PUSH("فشاری", "شنا، دیپ و قدرت پرس"),
    PULL("کششی", "روئینگ، بارفیکس، ماسل‌آپ و کشیدن یک‌دستی"),
    LEGS("پا", "اسکوات، پیستول، نوردیک و پرش"),
    CORE("مرکز بدن", "پلانک، ال‌سیت، وی‌سیت، دراگون فلگ و مانا"),
    HANDSTAND("هندستند", "تعادل، پرس‌ها و شنا هندستند"),
    LEVERS("لورها", "فرانت لور (چپ) و بک لور (راست)"),
    PLANCHE("پلانش", "خم شدن، جمع‌شده، واگرا و پلانش کامل"),
    FLAG("پرچم انسانی", "قدرت میله و پرچم انسانی"),
    RINGS("حلقه", "قدرت حلقه، اتکا و ماسل‌آپ روی حلقه")
}

data class Skill(
    val id: String,
    val tree: TreeId,
    val name: String,
    val difficulty: Int,
    val lane: Int,
    val prereqs: List<String>,
    val description: String,
    val requirement: String,
    val volume: String,
    val goal: String,
    val steps: List<String>,
    val tip: String
)

/** Five difficulty levels. The colors are defined in ui/Difficulty.kt (difficultyColor). */
fun difficultyLabel(d: Int): String = when (d) {
    1 -> "آسان"
    2 -> "نسبتاً آسان"
    3 -> "متوسط"
    4 -> "سخت"
    else -> "پیشرفته"
}

fun levelTitle(completed: Int): String = when {
    completed < 5 -> "تازه‌کار"
    completed < 15 -> "شاگرد"
    completed < 35 -> "ورزشکار"
    completed < 65 -> "ورزشکار پیشرفته"
    completed < 100 -> "استاد"
    else -> "اسطوره"
}

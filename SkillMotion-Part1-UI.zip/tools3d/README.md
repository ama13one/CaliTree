# 3D exercise demonstrations

The app plays back `app/src/main/assets/demo3d.bin` (about 380 KB for all 132 exercises). Nothing is downloaded and no
3D library is needed; the renderer is `app/src/main/java/com/calitree/app/ui/Demo3D.kt` (Jetpack Compose Canvas).

How it is built
- `rig.py`     20-joint skeleton, bone lengths of a 1.77 m athlete, analytic 2-bone IK for arms and legs.
- `h.py`       builders (push-up support, hangs, handstands, ...).
- `ex_*.py`    one file per skill tree. Every exercise is a list of key poses (start ... end) written as
               positions of hands, feet, pelvis and torso direction, so contacts (palms on the floor, hands on
               the bar, toes on the wall) stay put. Each exercise also lists its own camera angles and props.
- `motion.py`  baking: unwrap angles, spline through the key poses, arcs around shoulder / hip, IK, refine, cache.
- `refine.py`  contact-aware correction of every frame (planted hands/feet, floor, limb overlap, joint range).
- `body.py`    capsule geometry shared by the audit and the refiner (radii identical to Demo3D.kt).
- `audit.py`   measures every exercise;  `verify_asset.py` parses demo3d.bin like the app does.
- `filmstrip.py` / `worst.py`  look at the IN-BETWEEN frames (preview.py only shows key poses).
- `build3d.py` writes the binary asset and fails if an exercise id is missing.
- `preview.py` / `t_gen.py`  contact sheets for review:  `python3 tools3d/t_gen.py push ex_push 12`

Rebuild after editing a pose:  `python3 tools3d/build3d.py`   (needs Python 3, numpy, matplotlib for previews)

World axes: +x = direction the athlete faces, +y up, +z = athlete's right side. Units: metres.

## Animation quality (v1.3)
Baking pipeline: (1) angles move by the short arc between keys, (2) monotone cubic spline through the keys (speed is
continuous through middle keys, zero at the start and end of the move), (3) free hand/foot targets whose straight path
would cross the shoulder/hip travel on an arc around it, (4) IK with an anatomical knee (faces forward after the hip
flexion; swivel limited to 55 deg and to 12 deg/frame), temporal pole memory for elbows and a foot heading that is
carried along with the shin (max 18 deg/frame), (5) `refine.py`: planted targets (unchanged between two keys) stay
put and the body moves instead, nothing sinks below the floor or a box, capsules do not overlap, elbow/knee never fold
beyond 18/14 degrees; corrections are tied to neighbouring frames and smoothed, frames that are already fine are not
touched. Results are cached in `tools3d/.cache` (delete it or set CALITREE_NOCACHE=1 to force a re-bake; a full bake
takes about 6 minutes).

Checks:  `python3 tools3d/audit.py -v`  (add `--strict` to fail on any flag),  `python3 tools3d/verify_asset.py <old.bin>`.
Free limits are chosen by us, not taken from a standard: heel >= 19 cm from the hip joint, hand >= 12 cm from the
shoulder, knee interior angle >= 14, elbow >= 18.

Known open items (authoring problems that need a new key pose, not a pipeline fix; run the audit for the current list):
- `legs_boxjump`: the loop restarts 1.16 m away from where it ended (the athlete steps off the box, then the clip jumps back).
- Capsule overlaps of 6 to 9 cm in tuck levers / flags (`bl_skin`, `bl_german`, `fl_tuck`, `fg_pole`), `legs_dragon`,
  `core_tuck_lsit` (seat 9 cm below the floor), `hs_compress`.
- Static balance (centre of mass outside the support polygon) in a few handstand / planche / frog poses.
- Hip and shoulder range of motion in the extreme lever poses is reported, not corrected.
These could only be judged on screen by a person; the audit measures capsules, not how a pose looks.

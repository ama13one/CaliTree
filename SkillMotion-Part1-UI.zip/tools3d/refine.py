"""Contact-aware refinement of an interpolated pose sequence (step 4 of the baking pipeline).

The authored key poses and the spline between them describe the *intent*. This module makes every frame
physically consistent without touching how exercises are authored:

  * planted hands / feet (targets that do not move between two keys) stay exactly where they are: the body
    (pelvis position, trunk angle, ...) moves instead of the limb being stretched off its contact
  * nothing sinks into the floor or into a box
  * body capsules do not pass through each other (elbow / knee swivel, trunk angle, free feet / hands are
    pushed out of the torso)
  * elbows and knees stay inside their anatomical range (no fold-over, knee hinge stays near the pelvis axis)
  * the corrections are smoothed over time, so a correction never appears as a pop

Frames that already satisfy every constraint are not modified at all.
"""
import math
import os
import numpy as np
from scipy.optimize import least_squares

import body
from rig import (solve, JI, UA, FA, THIGH, SHIN, ARM, LEG, nrm)

EFFECTORS = ("hr", "hl", "fr", "fl")
LIMB = {"hr": "armR", "hl": "armL", "fr": "legR", "fl": "legL"}
ROOT = {"hr": "shR", "hl": "shL", "fr": "hipR", "fl": "hipL"}
ELBOW_MIN, KNEE_MIN = 18.0, 14.0            # smallest interior angle (deg); soft tissue allows heel-to-buttock tucks
DMIN_ARM = math.sqrt(UA ** 2 + FA ** 2 - 2 * UA * FA * math.cos(math.radians(ELBOW_MIN)))
DMIN_LEG = math.sqrt(THIGH ** 2 + SHIN ** 2 - 2 * THIGH * SHIN * math.cos(math.radians(KNEE_MIN)))
KNEE_TWIST_OK = 50.0
# free (non-planted) targets are kept this far from their root joint: heel >= 19 cm from the hip joint centre,
# hand >= 12 cm from the shoulder. Closer targets make the limb whip around the joint between two frames.
FREE_MIN_LEG, FREE_MIN_ARM = 0.19, 0.12

# optimisation variables: pelvis xyz, trunk angle, roll, yaw, spine flex, foot pitch R/L, swivel er el kr kl
VN = ["px", "py", "pz", "ta", "roll", "yaw", "flex", "pfr", "pfl", "swer", "swel", "swkr", "swkl"]
VSCALE = np.array([0.05, 0.05, 0.05, 5, 5, 5, 5, 5, 5, 10, 10, 10, 10], float)
VLO = np.array([-0.45, -0.45, -0.15, -45, -20, -20, -20, -25, -25, -35, -35, -30, -30], float)
VHI = -VLO
# regularisation (cost of moving each variable by one VSCALE)
VREG = np.array([0.6, 0.6, 0.6, 0.35, 0.3, 0.3, 0.3, 0.12, 0.12, 0.5, 0.5, 0.6, 0.6], float)

W_REACH, W_FLOOR, W_CLIP, W_LIMIT = 220.0, 60.0, 30.0, 6.0
VTIME = np.array([0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 4.0, 4.0, 4.0, 4.0], float)   # cost of changing a correction between two frames (x VSCALE); swivels are stiff: a flipping swivel is a visible pop
TOL_REACH, TOL_FLOOR, TOL_CLIP = 0.0015, 0.004, 0.004


# ----------------------------------------------------------------------------------- helpers
def _copy(q):
    return {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in q.items()}


def apply(q0, x):
    q = _copy(q0)
    q["p"] = q0["p"] + x[0:3]
    for i, k in enumerate(("ta", "roll", "yaw", "flex"), start=3):
        q[k] = q0[k] + x[i]
    q["pfr"], q["pfl"] = q0["pfr"] + x[7], q0["pfl"] + x[8]
    for i, k in enumerate(("swer", "swel", "swkr", "swkl"), start=9):
        q[k] = q0[k] + x[i]
    return q


def planted_flags(keys, key_idx, n):
    """For every frame: which of hr / hl / fr / fl are contacts (their target does not move between the keys
    on either side of the frame)."""
    seg = []
    for i in range(len(keys) - 1):
        seg.append({e: float(np.linalg.norm(keys[i][e] - keys[i + 1][e])) < 0.02 for e in EFFECTORS})
    out = []
    for f in range(n):
        flags = {e: False for e in EFFECTORS}
        for i in range(len(keys) - 1):
            if key_idx[i] <= f <= key_idx[i + 1]:
                for e in EFFECTORS:
                    flags[e] = flags[e] or seg[i][e]
        out.append(flags)
    return out


def box_pen(J, props):
    """Depth (m) of capsule ends below a box top (only ends above the box footprint and near its top)."""
    worst = 0.0
    for p in props:
        if p[0] != 3:
            continue
        x0, y0, z0, x1, y1, z1 = p[1:]
        for k in body.SEG_NAMES:
            a, b, r = body.SEG[k]
            for n in (a, b):
                q = J[JI[n]]
                if x0 - 0.01 <= q[0] <= x1 + 0.01 and z0 - 0.01 <= q[2] <= z1 + 0.01 and y1 - 0.20 < q[1] < y1 + r:
                    worst = max(worst, y1 + r - q[1])
    return worst


def knee_twist_and_min(J):
    rr = J[JI["hipR"]] - J[JI["hipL"]]
    rr = rr / (np.linalg.norm(rr) + 1e-9)
    out = []
    for s in "RL":
        hp, kn, an = J[JI["hip" + s]], J[JI["kn" + s]], J[JI["an" + s]]
        inter = float(body.interior(hp[None], kn[None], an[None])[0])
        hh = np.cross(kn - hp, an - kn)
        hh = hh / (np.linalg.norm(hh) + 1e-9)
        tw = math.degrees(math.acos(max(-1.0, min(1.0, -float(np.dot(hh, rr))))))
        out.append((tw if inter < 150 else 0.0, inter))
    return out


def elbow_min(J):
    return [float(body.interior(J[JI["sh" + s]][None], J[JI["el" + s]][None], J[JI["wr" + s]][None])[0]) for s in "RL"]


def residual(x, q0, planted, props, st, xprev=None, parts=False):
    q = apply(q0, x)
    info = {}
    J, _ = solve(q, dict(st), info)
    r = []
    # reach of planted contacts: neither stretched off the contact nor folded in on itself
    for e in EFFECTORS:
        if planted[e]:
            err = info["err"][LIMB[e]]
            r.append(W_REACH * max(0.0, err - TOL_REACH))
            dist = float(np.linalg.norm(q[e] - J[JI[ROOT[e]]]))
            dmin = DMIN_ARM if e[0] == "h" else DMIN_LEG
            r.append(W_REACH * max(0.0, dmin - dist))
    # floor and boxes
    fp = body.floor_pen(J) - TOL_FLOOR
    r.extend(W_FLOOR * np.maximum(fp, 0.0))
    if any(p[0] == 3 for p in props):
        r.append(W_FLOOR * max(0.0, box_pen(J, props) - TOL_FLOOR))
    # self intersection
    r.extend(W_CLIP * np.maximum(body.penetrations(J) - TOL_CLIP, 0.0))
    # joint limits
    for tw, inter in knee_twist_and_min(J):
        r.append(W_LIMIT * max(0.0, tw - KNEE_TWIST_OK) / 10.0)
        r.append(W_LIMIT * max(0.0, KNEE_MIN - inter) / 10.0)
    for inter in elbow_min(J):
        r.append(W_LIMIT * max(0.0, ELBOW_MIN - inter) / 10.0)
    n_constraint = len(r)
    r.extend(VREG * (x / VSCALE))
    if xprev is not None:
        r.extend(VTIME * (x - xprev) / VSCALE)
    r = np.array(r)
    if parts:
        return r[:n_constraint]
    return r


def violation(q, planted, props, st):
    return float(np.abs(residual(np.zeros(len(VN)), q, planted, props, st, None, parts=True)).max())


# ----------------------------------------------------------------------------------- free targets
def project_free_targets(q, planted, st):
    """Free (non planted) hands / feet: keep the target out of the fold-over zone (limb folded onto itself).
    Pushing targets out of the torso was tried and removed: the push direction flips when a target crosses the
    body axis and made the knee swing 180 deg. Limb-vs-torso overlap is left to the optimiser (swivel, trunk)."""
    J, _ = solve(q, dict(st))
    q = _copy(q)
    for e in EFFECTORS:
        if planted[e]:
            continue
        root = J[JI[ROOT[e]]]
        t = q[e].copy()
        d = t - root
        L = float(np.linalg.norm(d))
        dmin = FREE_MIN_ARM if e[0] == "h" else FREE_MIN_LEG
        if L < dmin:
            u = J[JI["chest"]] - J[JI["pelvis"]]
            rr = J[JI["hipR"]] - J[JI["hipL"]]
            fwd = np.cross(u, rr)
            fwd = fwd / (np.linalg.norm(fwd) + 1e-9)
            u = u / (np.linalg.norm(u) + 1e-9)
            # anatomical default for a target at the root: heel under / behind the buttock, hand in front of the shoulder
            side = 1.0 if e[1] == "r" else -1.0
            rl = rr / (np.linalg.norm(rr) + 1e-9)
            # (with a lateral part so the two heels / hands never land on top of each other)
            fb = nrm(-0.8 * fwd - 0.3 * u + side * 0.7 * rl) if e[0] == "f" else nrm(0.8 * fwd + 0.3 * u + side * 0.5 * rl)
            g = (1.0 - L / dmin) ** 2
            dirv = d / dmin + fb * (1.5 * g)
            t = root + nrm(dirv) * dmin
        q[e] = t
    return q


# ----------------------------------------------------------------------------------- optimiser
def optimise(q0, planted, props, st, xprev=None, nfev=25):
    """Corrections for one frame, warm started from (and tied to) the previous frame's corrections so that
    neighbouring frames always land on the same branch of the solution."""
    if xprev is None or not np.any(xprev):
        if violation(q0, planted, props, st) < 1e-4:
            return np.zeros(len(VN))
        xprev = None
    x0 = np.zeros(len(VN)) if xprev is None else np.clip(xprev, VLO + 1e-6, VHI - 1e-6)
    sol = least_squares(residual, x0, args=(q0, planted, props, st, xprev), bounds=(VLO, VHI), x_scale=VSCALE,
                        diff_step=1e-3, max_nfev=nfev, xtol=1e-5, ftol=1e-6)
    return sol.x


def _flat(q, names):
    return np.concatenate([np.atleast_1d(np.asarray(q[k], float)) for k in names])


def _unflat(v, names, like):
    q, i = {}, 0
    for k in names:
        n = np.size(like[k])
        q[k] = v[i:i + n].copy() if isinstance(like[k], np.ndarray) else float(v[i])
        i += n
    return q


def refine(poses, keys, key_idx, props):
    names = list(poses[0].keys())
    n = len(poses)
    planted = planted_flags(keys, key_idx, n)
    st0, qs = {}, []
    for f in range(n):
        qs.append(project_free_targets(poses[f], planted[f], st0))
        solve(poses[f], st0)
    # sweep 1 (forward, warm started) and sweep 2 (backward): every frame is tied to its neighbours' corrections
    xs = [np.zeros(len(VN)) for _ in range(n)]
    for sweep, order in enumerate((range(n), range(n - 1, -1, -1))):
        st = {}
        for f in order:
            nb = [xs[g] for g in (f - 1, f + 1) if 0 <= g < n]
            tie = np.mean(nb, axis=0) if nb else None
            if sweep == 0:
                tie = xs[f - 1] if f > 0 else None
            xs[f] = optimise(qs[f], planted[f], props, {}, tie, 25 if sweep == 0 else 12)
    X = np.array(xs)
    for _ in range(3):                      # smooth the corrections themselves (they are the only source of new motion)
        P = np.vstack([X[:1], X, X[-1:]])
        X = 0.25 * P[:-2] + 0.5 * P[1:-1] + 0.25 * P[2:]
    xs = list(X)
    out, st = [], {}
    for f in range(n):
        q = apply(qs[f], xs[f])
        out.append(q)
        solve(q, st)
    return out

from h import *
import copy
import ex_pull, ex_push
from ex_pull import hp, legs_to, row_keys, HANG_SY, BY
from motion import EX

RZ = 0.23                      # half distance between the rings
RTOP = 2.9
def RINGS(off=0.07):           # rings follow the hands; straps run up to fixed anchors
    return (9, RTOP, RZ + 0.02, off, 0, 0, 0)
RV = [("3/4 front", 40, 12), ("Side", 90, 6), ("Front", 0, 6)]
RVS = [("Side", 90, 6), ("3/4 front", 40, 12), ("Front", 0, 6)]


def regrip(q, z=RZ):
    q = dict(q)
    for k, sg in (("hr", 1), ("hl", -1)):
        v = q[k].copy(); v[2] = sg * z; q[k] = v
    return q

# ---- ring support: stand holding rings at hip height, then press up to straight-arm support
def rg_support_keys(ry=1.00, turn=False):
    wy = ry - 0.04
    def key(S_y, ta, legs_h):
        q = pose_from_shoulder(V(0.0, S_y, 0), ta, shup=-0.06, er=V(-1, 0.4, 0.4), el=V(-1, 0.4, 0.4))
        q["hr"] = V(0.0, wy, RZ); q["hl"] = V(0.0, wy, -RZ)
        return q
    top = key(wy + ARM * 0.975, 90, 0)
    legs_to(top, 6, pf=60, knee=(1, 0, 0.1))
    if turn:
        for k, sg in (("hr", 1), ("hl", -1)):
            v = top[k].copy(); v[2] = sg * (RZ + 0.10); top[k] = v
        top["hdr"] = V(1, 0, 0.8); top["hdl"] = V(1, 0, -0.8); top["hwr"] = top["hwl"] = 0.5
    return top
sup_top = rg_support_keys()
start = stand(0.0)
start.update(hr=V(0.05, 0.96, RZ), hl=V(0.05, 0.96, -RZ), er=V(-1, 0.4, 0.6), el=V(-1, 0.4, 0.6))
start["p"] = V(-0.10, HIP_Y, 0)
reg("rg_support", [start, sup_top], [RINGS()], RV, hold=True, durs=[1.4])
reg("rg_rto", [rg_support_keys(), rg_support_keys(turn=True)], [RINGS()], [("Front", 0, 6), ("3/4 front", 40, 12), ("Top", 0, 78)], hold=True, durs=[1.6])
lsit_q = rg_support_keys()
legs_to(lsit_q, 88, pf=62, knee=(0, 1, 0.05))
lsit_q["ta"] = 96.0
reg("rg_lsit", [rg_support_keys(), lsit_q], [RINGS()], RVS, hold=True, durs=[1.6])

# ---- ring rows
lo, hi = row_keys(1.12, grip=RZ)
reg("rg_row", [lo, hi], [RINGS(0.0)], RV, durs=[1.7], rdurs=[2.0])

# ---- false grip hang (wrist rests on top of the ring) and ring pull-ups
fg_hang = regrip(EX["pull_hang"]["keys"][0])
reg("rg_false", [fg_hang, fg_hang], [RINGS(-0.03)], RV, hold=True)
pu = [regrip(k) for k in EX["pull_pullup"]["keys"]]
reg("rg_pullup", pu, [RINGS()], RV, durs=[1.7], rdurs=[2.0])
fgp = [regrip(k) for k in EX["pull_pullup"]["keys"]]
reg("rg_fg_pullup", fgp, [RINGS(-0.03)], RV, durs=[1.7], rdurs=[2.0])

# ---- ring push-up (rings at 30 cm, elbows tucked) and ring fly
t, b, hx = pushup_keys(hz=RZ, er=(-1, 0.3, 0.25), hy=0.28, Fy=0.25)
reg("rg_pushup", [t, b], [RINGS(0.0)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.7], rdurs=[1.6])
t, b, hx = pushup_keys(hz=0.2, er=(-0.4, 0.2, 1), hy=0.28, Fy=0.25, dnS=0.40)
bw = dict(b)
bw["hr"] = V(hx, 0.28, 0.58); bw["hl"] = V(hx, 0.28, -0.58)
th = th_for(0.25, 0.40)
bw = sup(0, 0.25, th, hx, 0.28, 0.58, er=(-0.3, 0.1, 1.0))
reg("rg_fly", [t, bw], [RINGS(0.0)], [("Front", 0, 8), ("3/4 front", 50, 16), SIDE_V], durs=[1.9], rdurs=[1.9])

# ---- ring dip
td, bd = ex_push.dip()
td, bd = regrip(td), regrip(bd)
for q in (td, bd):
    q["er"] = q["el"] = V(-1, 0.5, 0.15)
reg("rg_dip", [td, bd], [RINGS()], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.8], rdurs=[1.7])

# ---- muscle-up family reusing the verified bar motions with ring grip
for rid, src in (("rg_transition", "pull_mu_trans"), ("rg_mu", "pull_mu"), ("rg_strict", "pull_mu_strict")):
    e = EX[src]
    reg(rid, [regrip(k) for k in e["keys"]], [RINGS(0.0 if rid == "rg_transition" else 0.07)], [SIDE_V, ("3/4 front", 40, 12), FRONT_V],
        durs=e["durs"], rdurs=e["rdurs"])

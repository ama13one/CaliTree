"""Writes app/src/main/assets/demo3d.bin from every registered motion.
Run from the project root:  python3 tools3d/build3d.py"""
import os, struct, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import motion
import ex_push, ex_pull, ex_legs, ex_core, ex_hs, ex_levers, ex_planche_flag, ex_rings  # noqa: F401
from skills_dump import load

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "app/src/main/assets/demo3d.bin")


# Persian names of the camera angles (shown in the app as chips)
VIEW_FA = {
    "Side": "از کنار",
    "Front": "از روبه‌رو",
    "3/4 front": "سه‌چهارم جلو",
    "3/4 rear": "سه‌چهارم عقب",
    "Rear": "از پشت",
    "Top": "از بالا",
}


def utf(s):
    b = s.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def main():
    ids = [s["id"] for s in load()]
    missing = [i for i in ids if i not in motion.EX]
    extra = [i for i in motion.EX if i not in ids]
    assert not missing and not extra, ("missing", missing, "extra", extra)
    out = bytearray(struct.pack(">ii", 0x44334431, len(ids)))
    bad = 0
    for i in ids:
        e = motion.EX[i]
        if e["warns"]:
            bad += 1
            print("WARN", i, e["warns"])
        fr = e["frames"]
        allp = fr.reshape(-1, 3)
        pts = [allp]
        c = (allp.max(0) + allp.min(0)) / 2
        rad = float(np.linalg.norm(allp - c, axis=1).max()) + 0.18
        out += utf(i)
        out += struct.pack(">B", (1 if e["hold"] else 0) | (2 if e["loop"] else 0))
        out += struct.pack(">ffff", c[0], c[1], c[2], rad)
        out += struct.pack(">B", len(e["props"]))
        for p in e["props"]:
            out += struct.pack(">B", p[0]) + struct.pack(">6f", *p[1:])
        out += struct.pack(">B", len(e["views"]))
        for n, az, el in e["views"]:
            out += utf(VIEW_FA.get(n, n)) + struct.pack(">ff", az, el)
        out += struct.pack(">B", len(e["key_idx"]))
        for k in e["key_idx"]:
            out += struct.pack(">H", k)
        for d in e["durs"]:
            out += struct.pack(">f", d)
        for d in e["rdurs"]:
            out += struct.pack(">f", d)
        out += struct.pack(">H", len(fr))
        mm = np.clip(np.round(fr * 1000), -32000, 32000).astype(">i2")
        out += mm.tobytes()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, "wb").write(bytes(out))
    print("wrote", OUT, len(out) // 1024, "KB,", len(ids), "exercises,", bad, "with warnings")


if __name__ == "__main__":
    main()

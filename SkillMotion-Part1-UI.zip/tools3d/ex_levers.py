from h import *
from ex_pull import hp, legs_to, legs_tuck, BY, HANG_SY, PULL_PROPS

LVR = [("Side", 90, 6), ("3/4 front", 45, 12), ("Front", 0, 6)]
LVR_B = [("Side", 90, 6), ("3/4 rear", 135, 12), ("Rear", 180, 6)]
GRIP = 0.28
WR = BY - 0.075


def lever(ta, Sx, Sy, shup=-0.03, er=(-0.3, -1, 0.3), neck=0.0, flex=0.0, grip=GRIP):
    q = pose_from_shoulder(V(Sx, Sy, 0), ta, shup=shup, er=V(*er), el=V(*er), neck=neck, flex=flex)
    q["hr"] = V(0, WR, grip); q["hl"] = V(0, WR, -grip)
    return q


def legs_abs(q, kind, side=1.0, hz=0.07, pf=60, scale=0.995, horiz_dir=(1, 0), spread=0.0):
    """Leg configurations for horizontal levers. horiz_dir = direction of the straight legs (+x front lever, -x back lever)."""
    p = q["p"]
    hd = V(horiz_dir[0], 0, 0)
    sgn = horiz_dir[0]
    up = V(0, 1, 0) if q["ta"] > 90 and q["ta"] < 270 else V(0, -1, 0)   # side the chest faces
    if kind == "straight":
        t = p + LEG * scale * hd
        q.update(fr=t + V(0, 0, hz), fl=t + V(0, 0, -hz))
        q.update(pfr=pf, pfl=pf, kr=up, kl=up)
    elif kind == "straddle":
        a = math.radians(spread)
        d = V(sgn * math.cos(a), 0, math.sin(a))
        q["fr"] = p + LEG * scale * d; q["fl"] = p + LEG * scale * V(d[0], 0, -d[2])
        q.update(pfr=pf, pfl=pf, kr=up, kl=up)
    q["flr"] = q["fll"] = 0.0
    return q


def tuck(q, kind, up_dir, hz=0.09):
    """kind: 'tuck' (knees to chest) or 'adv' (hips open, thighs perpendicular to the back)."""
    p = q["p"]
    sgn = 1.0 if q["ta"] > 90 and q["ta"] < 270 else 1.0
    if kind == "tuck":
        head = V(-1, 0, 0) if up_dir[1] > 0 else V(1, 0, 0)
        a = math.radians(50)
        k = p + THIGH * (head * math.cos(a) + up_dir * math.sin(a))
        ank = k + SHIN * 0.98 * (-head * 0.55 - up_dir * 0.83) / 1.0
    else:
        k = p + THIGH * up_dir
        legdir = V(1, 0, 0) if up_dir[1] > 0 else V(-1, 0, 0)
        ank = k + SHIN * 0.99 * legdir
    q.update(fr=ank + V(0, 0, hz), fl=ank + V(0, 0, -hz), pfr=55, pfl=55, flr=0, fll=0, kr=up_dir + V(0, 0, 0.1), kl=up_dir + V(0, 0, 0.1))
    return q


UPV = V(0, 1, 0)
DNV = V(0, -1, 0)
HANG = hp(HANG_SY, shup=0.03)

# ---------------- front lever (supine, legs toward +x) ----------------
FL_SY = WR - 0.545
def fl_pose(kind, spread=0.0, rowup=False, pull=False):
    Sy = FL_SY
    q = lever(180, 0.0, Sy, shup=-0.04)
    if kind in ("tuck", "adv"):
        tuck(q, kind, UPV)
    elif kind == "one":
        tuck(q, "adv", UPV)
        t = q["p"] + LEG * 0.995 * V(1, 0, 0)
        q["fr"] = t + V(0, 0, 0.07); q["pfr"] = 60.0; q["kr"] = UPV
    elif kind == "straddle":
        legs_abs(q, "straddle", spread=spread)
    else:
        legs_abs(q, "straight")
    return q
def fl_row_top():
    q = lever(180, 0.04, WR - 0.20, shup=-0.02, er=(-0.4, -1, 0.5))
    tuck(q, "adv", UPV)
    return q
def fl_pull_top():
    q = lever(168, -0.06, BY - 0.13, shup=-0.02, er=(-0.4, -1, 0.5), neck=-6)
    legs_abs(q, "straight")
    p = q["p"]
    t = p + LEG * 0.995 * V(math.cos(math.radians(-12)), math.sin(math.radians(-12)), 0)
    q["fr"] = t + V(0, 0, 0.07); q["fl"] = t + V(0, 0, -0.07)
    return q
reg("fl_tuck", [HANG, fl_pose("tuck")], PULL_PROPS, LVR, hold=True, durs=[1.8])
reg("fl_adv_tuck", [fl_pose("tuck"), fl_pose("adv")], PULL_PROPS, LVR, hold=True, durs=[1.6])
reg("fl_row", [fl_pose("adv"), fl_row_top()], PULL_PROPS, LVR, durs=[1.8], rdurs=[2.0])
reg("fl_oneleg", [fl_pose("adv"), fl_pose("one")], PULL_PROPS, LVR, hold=True, durs=[1.6])
reg("fl_straddle", [fl_pose("one"), fl_pose("straddle", spread=42)], PULL_PROPS, [("Rear", 180, 8), ("3/4 front", 45, 12), ("Top", 90, 78)][:2] + [("Side", 90, 6)], hold=True, durs=[1.6])
reg("fl_full", [HANG, fl_pose("straight")], PULL_PROPS, LVR, hold=True, durs=[2.0])
reg("fl_pullup", [fl_pose("straight"), fl_pull_top()], PULL_PROPS, LVR, durs=[2.2], rdurs=[2.2])

# ---------------- skin the cat / German hang ----------------
GH_S = V(0.30, WR - 0.47, 0)
def gh(ta=80.0, tucked=False):
    q = pose_from_shoulder(GH_S, ta, shup=0.04, er=V(-0.5, -1, 0.3), el=V(-0.5, -1, 0.3), neck=-6)
    q["hr"] = V(0, WR, GRIP); q["hl"] = V(0, WR, -GRIP)
    if tucked:
        p = q["p"]
        k = p + V(0.15, -0.30, 0); ank = p + V(-0.10, -0.55, 0)
        q.update(fr=ank + V(0, 0, 0.07), fl=ank + V(0, 0, -0.07), kr=V(1, 0, 0.1), kl=V(1, 0, 0.1), pfr=50, pfl=50, flr=0, fll=0)
    else:
        legs_to(q, 4, pf=60, knee=(1, 0, 0.1))
    return q
def cat_k1():
    q = hp(BY - 0.60, sx=-0.12, ta=118, shup=-0.02)
    legs_tuck(q, kx=0.28, ky=0.18)
    return q
def cat_k2():
    q = pose_from_shoulder(V(-0.04, BY - 0.62, 0), 250, shup=-0.03, er=V(-0.5, -1, 0.3), el=V(-0.5, -1, 0.3), neck=20)
    q["hr"] = V(0, WR, GRIP); q["hl"] = V(0, WR, -GRIP)
    p = q["p"]
    ank = p + V(0.28, 0.30, 0)
    q.update(fr=ank + V(0, 0, 0.07), fl=ank + V(0, 0, -0.07), pfr=50, pfl=50, flr=0, fll=0, kr=V(-1, 0.6, 0.1), kl=V(-1, 0.6, 0.1))
    return q
def cat_k3():
    q = pose_from_shoulder(V(0.16, BY - 0.60, 0), 330, shup=0.0, er=V(-0.5, -1, 0.3), el=V(-0.5, -1, 0.3), neck=10)
    q["hr"] = V(0, WR, GRIP); q["hl"] = V(0, WR, -GRIP)
    p = q["p"]
    ank = p + V(0.55, -0.35, 0)
    q.update(fr=ank + V(0, 0, 0.07), fl=ank + V(0, 0, -0.07), pfr=50, pfl=50, flr=0, fll=0, kr=V(0, 1, 0.1), kl=V(0, 1, 0.1))
    return q
def cat_gh():
    q = gh(440.0, tucked=False)
    return q
reg("bl_skin", [HANG, cat_k1(), cat_k2(), cat_k3(), cat_gh()], PULL_PROPS, [SIDE_V, ("3/4 rear", 135, 12), FRONT_V], durs=[1.2, 1.4, 1.4, 1.4], rdurs=[1.4, 1.4, 1.4, 1.2])
reg("bl_german", [HANG, cat_k2(), cat_k3(), cat_gh()], PULL_PROPS, [SIDE_V, ("3/4 rear", 135, 12), FRONT_V], hold=True, durs=[1.4, 1.4, 1.6], rdurs=[1.6, 1.4, 1.4])

# ---------------- back lever (face down, legs toward -x) ----------------
BL_S = V(0.12, WR - 0.50, 0)
def bl_pose(kind, spread=0.0):
    q = pose_from_shoulder(BL_S, 0.0, shup=-0.03, er=V(-0.4, -1, 0.3), el=V(-0.4, -1, 0.3), neck=-12)
    q["hr"] = V(0, WR, GRIP); q["hl"] = V(0, WR, -GRIP)
    if kind in ("tuck", "adv"):
        tuck(q, kind, DNV)
    elif kind == "one":
        tuck(q, "adv", DNV)
        t = q["p"] + LEG * 0.995 * V(-1, 0, 0)
        q["fr"] = t + V(0, 0, 0.07); q["pfr"] = 60.0; q["kr"] = DNV
    elif kind == "straddle":
        legs_abs(q, "straddle", spread=spread, horiz_dir=(-1, 0))
    else:
        legs_abs(q, "straight", horiz_dir=(-1, 0))
    return q
reg("bl_tuck", [cat_gh(), bl_pose("tuck")], PULL_PROPS, LVR_B, hold=True, durs=[2.0])
reg("bl_adv_tuck", [bl_pose("tuck"), bl_pose("adv")], PULL_PROPS, LVR_B, hold=True, durs=[1.6])
reg("bl_oneleg", [bl_pose("adv"), bl_pose("one")], PULL_PROPS, LVR_B, hold=True, durs=[1.6])
reg("bl_straddle", [bl_pose("one"), bl_pose("straddle", spread=42)], PULL_PROPS, [("Rear", 180, 8), ("3/4 rear", 135, 12), ("Side", 90, 6)], hold=True, durs=[1.6])
reg("bl_full", [cat_gh(), bl_pose("straight")], PULL_PROPS, LVR_B, hold=True, durs=[2.2])

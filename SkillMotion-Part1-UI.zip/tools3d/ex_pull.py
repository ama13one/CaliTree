from h import *

BY = 2.35
HANG_SY = BY - 0.075 - 0.553


def legs_to(q, ang=0.0, spread=0.07, pf=55, knee=(1, 0, 0.1), scale=0.998):
    """Straight legs from the pelvis; ang = degrees forward of straight-down (90 = horizontal)."""
    a = math.radians(ang)
    t = q["p"] + LEG * scale * V(math.sin(a), -math.cos(a), 0)
    q.update(fr=t + V(0, 0, spread), fl=t - V(0, 0, spread), pfr=pf, pfl=pf, flr=0, fll=0,
             kr=V(*knee), kl=V(*knee))
    return q


def legs_tuck(q, kx=0.36, ky=0.10, pf=50, spread=0.07, k_pole=(1, 0.6, 0.12)):
    """Knees bent: ankles hang below/behind the knees. kx,ky = knee position relative to the hip."""
    p = q["p"]
    knee = p + V(kx, ky, 0)
    ank = knee + V(-0.22, -0.34, 0)
    q.update(fr=ank + V(0, 0, spread), fl=ank - V(0, 0, spread), pfr=pf, pfl=pf, flr=0, fll=0,
             kr=V(*k_pole), kl=V(*k_pole))
    return q


def hp(Sy, sx=-0.02, ta=90, grip=0.28, legs=0.0, er=(-0.3, -1, 0.35), neck=0.0, shup=0.0, lean=0.0, by=BY, pf=55, knee=(1, 0, 0.1), **kw):
    q = pose_from_shoulder(V(sx, Sy, 0), ta, neck=neck, shup=shup, er=V(*er), el=V(*er), lean=lean, **kw)
    q["hr"] = V(0, by - 0.075, grip)
    q["hl"] = V(0, by - 0.075, -grip)
    legs_to(q, legs, pf=pf, knee=knee)
    return q


PULL_PROPS = [bar(0, BY, 0.7)]
V_PULL = [("Side", 90, 6), ("3/4 front", 40, 12), ("Front", 0, 6)]
V_PULL2 = [("3/4 front", 40, 12), ("Side", 90, 6), ("Front", 0, 6)]

hang = hp(HANG_SY, shup=0.04)
reg("pull_hang", [hang, hang], PULL_PROPS, V_PULL2, hold=True)

# ---- scapular pull-up: arms stay straight, shoulder blades depress, body rises ~7 cm
passive = hp(HANG_SY, shup=0.05)
active = hp(HANG_SY + 0.07, shup=-0.02)
reg("pull_scap", [passive, active], PULL_PROPS, [("Side", 90, 6), ("Front", 0, 6)], hold=True, durs=[1.0])

# ---- the pull-up family
TOP = dict(Sy=BY - 0.10, sx=-0.05, ta=102, neck=-14, legs=6, shup=-0.03)
def top_pose(grip=0.28, **kw):
    d = dict(TOP); d.update(kw)
    Sy = d.pop("Sy")
    return hp(Sy, grip=grip, **d)
reg("pull_pullup", [hp(HANG_SY, shup=0.03), top_pose()], PULL_PROPS, V_PULL, durs=[1.6], rdurs=[2.0])
reg("pull_chin", [hp(HANG_SY, shup=0.03, grip=0.20), top_pose(grip=0.20)], PULL_PROPS, V_PULL2, durs=[1.6], rdurs=[2.0])
reg("pull_weighted", [hp(HANG_SY, shup=0.03), top_pose()], PULL_PROPS + [(7, 0, 0, 0, 0, 0, 0)], V_PULL, durs=[1.8], rdurs=[2.0])
reg("pull_explosive", [hp(HANG_SY, shup=-0.01), top_pose(Sy=BY - 0.02, ta=108, legs=15)], PULL_PROPS, V_PULL, durs=[0.55], rdurs=[1.8])
reg("pull_ctb", [hp(HANG_SY, shup=-0.01), hp(BY + 0.04, sx=-0.10, ta=114, neck=-8, legs=18, shup=-0.03)], PULL_PROPS, V_PULL, durs=[0.65], rdurs=[1.8])

# L-sit pull-up: straight legs held at horizontal the whole time
reg("pull_lpullup", [hp(HANG_SY, shup=0.0, ta=96, legs=88, pf=60, knee=(0, 1, 0.05)),
                     hp(BY - 0.10, sx=-0.05, ta=104, neck=-14, legs=88, pf=60, knee=(0, 1, 0.05), shup=-0.03)],
    PULL_PROPS, V_PULL, durs=[1.8], rdurs=[2.0])

# negative: top -> slow 5 s lowering -> dead hang. Reset is quick.
top = top_pose()
reg("pull_neg", [top, top, hp(HANG_SY, shup=0.03)], PULL_PROPS + [box(-0.5, 0, -0.35, -0.15, 1.5, 0.35)][:0], V_PULL,
    durs=[1.0, 5.0], rdurs=[1.0, 1.4])

# ---- archer pull-up: wide grip, chin to the right hand, left arm stays straight
def archer_pull():
    g = 0.56
    hang_w = hp(BY - 0.075 - math.sqrt((ARM * 0.985) ** 2 - (g - SH_HALF) ** 2), grip=g, shup=0.03)
    q = hp(BY - 0.20, sx=-0.06, ta=102, grip=g, neck=-5, legs=10, lean=-16, er=(-0.3, -1, 0.35))
    q["p"] = q["p"] + V(0, 0, 0.14)
    legs_to(q, 10)
    q["el"] = V(-0.1, -1, 0.1)
    return hang_w, q
a, b = archer_pull()
reg("pull_archer", [a, b], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), ("Side", 90, 6)], durs=[2.0], rdurs=[2.0])

# ---- one-arm pull-up: right hand on the bar, left arm relaxed at the side
def one_arm(top=True):
    gz = 0.06
    def mk(Sy, sx, ta, neck, legs, shup, lean=0.0):
        q = pose_from_shoulder(V(sx, Sy, 0.0), ta, neck=neck, shup=shup, lean=lean,
                               er=V(-0.2, -1, 0.3), el=V(-0.4, -0.2, 0.9))
        q["hr"] = V(0, BY - 0.075, gz)
        q["hl"] = q["p"] + V(0.0, 0.1, -0.30)
        legs_to(q, legs)
        return q
    return mk(HANG_SY - 0.02, -0.01, 90, 0, 6, 0.03), mk(BY - 0.09, -0.03, 104, -12, 14, -0.03, lean=-6)
a, b = one_arm()
reg("pull_oa", [a, b], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), ("Side", 90, 6)], durs=[2.4], rdurs=[2.4])
reg("pull_oa_assist", [a, b], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), ("Side", 90, 6)], durs=[2.0], rdurs=[2.0])
# the helper hand holds the working wrist
for k in ("pull_oa_assist",):
    pass
x = motion = None
from motion import EX
def _assist():
    ka, kb = [dict(q) for q in EX["pull_oa_assist"]["keys"]]
    for q in (ka, kb):
        J, _ = solve(q)
        q["hl"] = J[JI["wrR"]] + V(0, -0.0, -0.06)
        q["el"] = V(-0.4, -0.5, 0.6)
    reg("pull_oa_assist", [ka, kb], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), ("Side", 90, 6)], durs=[2.0], rdurs=[2.0])
_assist()
# one-arm negative: top -> very slow lowering with the free hand off the bar
b2 = EX["pull_oa"]["keys"][1]
reg("pull_oa_neg", [b2, b2, EX["pull_oa"]["keys"][0]], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), ("Side", 90, 6)],
    durs=[1.0, 6.0], rdurs=[1.0, 1.5])

# ---- inverted rows (supine under a bar, heels on the floor)
def row_pose(bar_y, ph_deg, heelx, grip=0.28, er=(-0.2, -0.2, 0.7)):
    ph = math.radians(ph_deg)
    total = LEG + TORSO
    ta = 180 - ph_deg
    S = V(heelx - total * math.cos(ph), ANKLE_H + total * math.sin(ph), 0)
    u = V(math.cos(math.radians(ta)), math.sin(math.radians(ta)), 0)
    q = P(p=S - TORSO * u, ta=ta, fr=V(heelx, ANKLE_H, 0.10), fl=V(heelx, ANKLE_H, -0.10), flr=0, fll=0,
          pfr=-5, pfl=-5, kr=V(0, 1, 0.1), kl=V(0, 1, 0.1), er=V(*er), el=V(*er))
    q["hr"] = V(0.0, bar_y - 0.07, grip)
    q["hl"] = V(0.0, bar_y - 0.07, -grip)
    return q
def row_keys(bar_y, grip=0.28):
    total = LEG + TORSO
    ph_hi = math.degrees(math.asin((bar_y - 0.15 - ANKLE_H) / total))
    heelx = -0.05 + total * math.cos(math.radians(ph_hi))
    hand = V(0, bar_y - 0.07, grip)
    best = None
    for ph in np.arange(5, ph_hi, 0.25):
        S = V(heelx - total * math.cos(math.radians(ph)), ANKLE_H + total * math.sin(math.radians(ph)), 0)
        d = np.linalg.norm(V(S[0], S[1], SH_HALF) - hand)
        if best is None or abs(d - ARM * 0.985) < best[0]:
            best = (abs(d - ARM * 0.985), ph)
    lo = row_pose(bar_y, best[1], heelx, grip)
    hi = row_pose(bar_y, ph_hi, heelx, grip, er=(-1, -0.4, 0.55))
    return lo, hi
lo, hi = row_keys(1.10)
reg("pull_row", [lo, hi], [bar(0, 1.10, 0.7)], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[1.7], rdurs=[2.0])
lo, hi = row_keys(1.38)
reg("pull_row_inc", [lo, hi], [bar(0, 1.38, 0.7)], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[1.7], rdurs=[2.0])

# ---- muscle-up family (bar muscle-up, strict, low-bar transition drill)
def support_top(by=BY, sx=0.07):
    S = V(sx, by + 0.04 + ARM * 0.985, 0)
    q = pose_from_shoulder(S, 84, shup=-0.05, er=V(-1, 0.3, 0.35), el=V(-1, 0.3, 0.35))
    q["hr"] = V(0, by + 0.045, 0.24); q["hl"] = V(0, by + 0.045, -0.24)
    q["hwr"] = q["hwl"] = 1.0
    legs_to(q, -4, pf=50)
    return q
def transition(by=BY):
    q = pose_from_shoulder(V(0.05, by + 0.14, 0), 70, neck=-4, er=V(-1, 0.9, 0.35), el=V(-1, 0.9, 0.35))
    q["hr"] = V(0.0, by + 0.0, 0.26); q["hl"] = V(0.0, by + 0.0, -0.26)
    q["hwr"] = q["hwl"] = 0.6
    legs_to(q, 8, pf=50)
    return q
def pull_chest(by=BY):
    return hp(by - 0.02, sx=-0.10, ta=112, neck=-8, legs=20, shup=-0.03, er=(-0.5, -1, 0.3))
mu = [hp(HANG_SY, shup=0.0), pull_chest(), transition(), support_top()]
reg("pull_mu", mu, PULL_PROPS, [SIDE_V, ("3/4 front", 40, 12), FRONT_V], durs=[0.8, 0.6, 0.9], rdurs=[1.0, 0.8, 1.2])
mus = [hp(HANG_SY, shup=0.0, legs=0), hp(by := BY - 0.02, sx=-0.08, ta=100, neck=-8, legs=4, shup=-0.03, er=(-0.5, -1, 0.3)), transition(), support_top()]
reg("pull_mu_strict", mus, PULL_PROPS, [SIDE_V, ("3/4 front", 40, 12), FRONT_V], durs=[2.0, 1.4, 1.8], rdurs=[2.0, 1.4, 2.0])

# low-bar transition drill: bar at chest height, feet on the floor help at the start
LB = 1.32
def low_start():
    # standing behind the bar line, leaning back with straight arms, feet on the floor ahead of the athlete
    S = V(-0.50, 1.14, 0)
    q = pose_from_shoulder(S, 118, shup=0.02, er=V(-1, -0.2, 0.4), el=V(-1, -0.2, 0.4))
    q["hr"] = V(0, LB - 0.0, 0.26); q["hl"] = V(0, LB - 0.0, -0.26)
    q.update(fr=V(-0.1, ANKLE_H, 0.1), fl=V(-0.1, ANKLE_H, -0.1), flr=1, fll=1, kr=V(1, 0.2, 0.1), kl=V(1, 0.2, 0.1))
    return q
def low_mid():
    q = pose_from_shoulder(V(-0.12, LB + 0.0, 0), 108, neck=-8, er=V(-0.8, -1, 0.3), el=V(-0.8, -1, 0.3))
    q["hr"] = V(0, LB + 0.0, 0.26); q["hl"] = V(0, LB + 0.0, -0.26)
    legs_tuck(q, kx=0.30, ky=-0.05)
    return q
def low_over():
    q = transition(by=LB)
    legs_tuck(q, kx=0.15, ky=-0.2)
    return q
def low_top():
    q = support_top(by=LB, sx=0.08)
    return q
reg("pull_mu_trans", [low_start(), low_mid(), low_over(), low_top()], [bar(0, LB, 0.7)], [SIDE_V, ("3/4 front", 40, 12), FRONT_V],
    durs=[0.8, 0.6, 0.9], rdurs=[1.0, 0.8, 1.2])

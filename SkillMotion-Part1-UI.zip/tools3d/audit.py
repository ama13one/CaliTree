"""Animation quality audit for every exercise in demo3d.bin.

Usage (project root):
    python3 tools3d/audit.py            # summary table + worst offenders
    python3 tools3d/audit.py -v         # per-exercise detail
    python3 tools3d/audit.py --strict   # exit code 1 if any hard limit is exceeded (CI gate)

The audit looks at exactly the frames the phone renders (baked joint positions), plus the
playback schedule (Start -> Movement -> End -> back), so a pass here means a pass on screen.

Checks (all distances in metres, angles in degrees):
  reach    IK target out of reach in ANY frame (not only key poses) -> limb stretched / contact lost
  floor    capsule surface below the floor plane (y = 0)
  clip     two non-neighbouring body capsules overlapping (arm through torso, leg through leg ...)
  pop      single-frame jump of a joint relative to its neighbours (launch / flip / pole snap)
  seam     loop seam (last frame != first frame) and reversal seam
  knee     knee hyper-extension or twisted hinge ; elbow over-flexion
  hip/sh   hip and shoulder range of motion
  slide    contact point (hand / foot) that should stay planted but drifts
  balance  centre-of-mass ground projection outside the support polygon (floor-supported frames)
"""
import math
import os
import sys
import itertools
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import motion  # noqa: E402
from rig import JI, JN, solve, lerp_pose  # noqa: E402

# ----------------------------------------------------------------------------- limits
LIM = dict(
    reach=0.012,        # IK stretch tolerated in any frame (m)
    floor=0.020,        # capsule below floor (m)
    clip=0.020,         # capsule overlap between non-neighbours (m)
    pop=2.2,            # frame-to-frame jump / neighbour mean (ratio) ...
    pop_abs=0.035,      # ... and absolute (m/frame) before it counts
    seam=0.015,         # loop seam (m)
    knee_twist=80.0,    # knee hinge axis vs the pelvis' lateral axis, bends > 30 deg (deg). >90 = bending backwards
    elbow_min=18.0,     # smallest interior elbow angle (deg) ; 180 = straight
    knee_min=14.0,
    hip_ext=40.0,       # thigh behind the pelvis' coronal plane (deg)
    hip_flex=150.0,     # angle between thigh and trunk-down axis (deg)
    sh_back=65.0,       # arm behind the shoulder's coronal plane (deg)
    slide=0.025,        # planted contact drift (m)
    balance=0.05,       # COM outside support polygon (m)
)

from body import SEG, HEAD_R, PAIRS, ALLOW, seg_dist, interior  # noqa: E402

MASS = [  # (joint a, joint b, mass fraction, position along a->b)
    ("pelvis", "spine", 0.14, 0.5), ("spine", "chest", 0.30, 0.5), ("chest", "head", 0.08, 1.0),
    ("shR", "elR", 0.027, 0.5), ("elR", "haR", 0.022, 0.5), ("shL", "elL", 0.027, 0.5), ("elL", "haL", 0.022, 0.5),
    ("hipR", "knR", 0.10, 0.5), ("knR", "toR", 0.061, 0.5), ("hipL", "knL", 0.10, 0.5), ("knL", "toL", 0.061, 0.5),
]


def jt(J, n):
    return J[:, JI[n]]


def poses_of(e):
    """The final baked pose list of an exercise (what produced e["frames"])."""
    return e["poses"]


def reach_errors(e):
    """Worst IK stretch (m) of a PLANTED hand / foot (a contact that must not lift off). A free target that is out
    of reach is harmless: the limb simply ends up fully straight."""
    import refine
    worst = 0.0
    st = {}
    flags = refine.planted_flags(e["keys"], e["key_idx"], len(e["poses"]))
    for q, fl in zip(poses_of(e), flags):
        info = {}
        solve(q, st, info)
        for eff, limb in refine.LIMB.items():
            if fl[eff]:
                worst = max(worst, float(info["err"][limb]))
    return worst


def analyse(e):
    J = e["frames"]
    N = len(J)
    res = {}
    # ---- reach
    res["reach"] = reach_errors(e)
    # ---- floor
    worst = 0.0
    for name, (a, b, r) in SEG.items():
        for n in (a, b):
            worst = max(worst, float((r - jt(J, n)[:, 1]).max()))
    worst = max(worst, float((HEAD_R - jt(J, "head")[:, 1]).max()))
    res["floor"] = worst
    # ---- clipping
    worst, wpair = 0.0, None
    P = {k: (jt(J, a), jt(J, b), r) for k, (a, b, r) in SEG.items()}
    for (a, b) in PAIRS:
        d = seg_dist(P[a][0], P[a][1], P[b][0], P[b][1])
        pen = (P[a][2] + P[b][2] - d).max() - ALLOW[(a, b)]
        if pen > worst:
            worst, wpair = float(pen), (a, b)
    # head ball against arms / legs
    head = jt(J, "head")
    for k, (p0, p1, r) in P.items():
        if k in ("neck", "clavR", "clavL", "abdomen", "pelvis", "pelR", "pelL"):
            continue
        d = seg_dist(p0, p1, head, head)
        pen = (r + HEAD_R - d).max() - 0.02
        if pen > worst:
            worst, wpair = float(pen), (k, "head")
    res["clip"], res["clip_pair"] = worst, wpair
    # ---- pops : per-frame displacement of each joint vs neighbours
    disp = np.linalg.norm(np.diff(J, axis=0), axis=-1)       # (N-1, 20)
    pop = 0.0
    if len(disp) > 4:
        for j in range(NJ_):
            d = disp[:, j]
            for i in range(1, len(d) - 1):
                nb = (d[i - 1] + d[i + 1]) / 2 + 1e-4
                if d[i] > LIM["pop_abs"] and d[i] / nb > LIM["pop"]:
                    pop = max(pop, float(d[i]))
    res["pop"] = pop
    res["vmax"] = float(disp.max()) if len(disp) else 0.0
    # ---- seams
    res["seam"] = float(np.linalg.norm(J[-1] - J[0], axis=-1).max()) if e["loop"] else 0.0
    # ---- joint limits
    hipR, hipL = jt(J, "hipR"), jt(J, "hipL")
    rr = hipR - hipL
    rr /= np.linalg.norm(rr, axis=-1, keepdims=True) + 1e-9
    pel, ch = jt(J, "pelvis"), jt(J, "chest")
    u = ch - pel
    u /= np.linalg.norm(u, axis=-1, keepdims=True) + 1e-9
    fwd = np.cross(u, rr)
    fwd /= np.linalg.norm(fwd, axis=-1, keepdims=True) + 1e-9
    kapex, eapex, kmin, emin = 0.0, 0.0, 180.0, 180.0
    for s_ in "RL":
        hp, kn, an = jt(J, "hip" + s_), jt(J, "kn" + s_), jt(J, "an" + s_)
        ki_ = interior(hp, kn, an)
        ax_ = an - hp
        ax_ /= np.linalg.norm(ax_, axis=-1, keepdims=True) + 1e-9
        hh = np.cross(kn - hp, an - kn)
        hh /= np.linalg.norm(hh, axis=-1, keepdims=True) + 1e-9
        ang = np.degrees(np.arccos(np.clip(-(hh * rr).sum(-1), -1, 1)))      # 0 = textbook flexion axis
        bent = ki_ < 150
        if bent.any():
            kapex = max(kapex, float(ang[bent].max()))
        kmin = min(kmin, float(ki_.min()))
        sh, el, wr = jt(J, "sh" + s_), jt(J, "el" + s_), jt(J, "wr" + s_)
        ei_ = interior(sh, el, wr)
        emin = min(emin, float(ei_.min()))
    res["knee_twist"], res["knee_min"], res["elbow_min"] = kapex, kmin, emin
    hext, hfl, sback = 0.0, 0.0, 0.0
    for s_ in "RL":
        t = jt(J, "kn" + s_) - jt(J, "hip" + s_)
        t = t / (np.linalg.norm(t, axis=-1, keepdims=True) + 1e-9)
        tu, tf = (t * u).sum(-1), (t * fwd).sum(-1)
        hext = max(hext, float(np.degrees(np.arcsin(np.clip(-tf, 0, 1))).max()))
        hfl = max(hfl, float(np.degrees(np.arccos(np.clip(-tu, -1, 1))).max()))
        a_ = jt(J, "el" + s_) - jt(J, "sh" + s_)
        a_ = a_ / (np.linalg.norm(a_, axis=-1, keepdims=True) + 1e-9)
        af = (a_ * fwd).sum(-1)
        sback = max(sback, float(np.degrees(np.arcsin(np.clip(-af, 0, 1))).max()))
    res["hip_ext"], res["hip_flex"], res["sh_back"] = hext, hfl, sback
    # ---- sliding of planted points
    ki = e["key_idx"]
    slide = 0.0
    for i in range(len(ki) - 1):
        a, b = ki[i], ki[i + 1]
        for n in ("wrR", "wrL", "anR", "anL", "toR", "toL"):
            p = jt(J, n)
            if np.linalg.norm(p[a] - p[b]) < 0.02:
                slide = max(slide, float(np.linalg.norm(p[a:b + 1] - p[a], axis=-1).max()))
    res["slide"] = slide
    # ---- balance (floor-supported frames only)
    res["balance"] = balance(e, J)
    return res


NJ_ = len(JN)


def com(J):
    c = np.zeros((len(J), 3))
    for a, b, m, f in MASS:
        c += m * (jt(J, a) + (jt(J, b) - jt(J, a)) * f)
    return c / sum(m for _, _, m, _ in MASS)


def hull_dist(pts, p):
    """Distance from p (2D) to the convex hull of pts (0 if inside)."""
    pts = np.unique(np.round(pts, 4), axis=0)
    if len(pts) == 1:
        return float(np.linalg.norm(p - pts[0]))
    if len(pts) == 2:
        a, b = pts
        t = np.clip(np.dot(p - a, b - a) / (np.dot(b - a, b - a) + 1e-12), 0, 1)
        return float(np.linalg.norm(p - (a + (b - a) * t)))
    hull = convex_hull(pts)
    inside = True
    best = 1e9
    for i in range(len(hull)):
        a, b = hull[i], hull[(i + 1) % len(hull)]
        cr = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
        if cr < 0:
            inside = False
        t = np.clip(np.dot(p - a, b - a) / (np.dot(b - a, b - a) + 1e-12), 0, 1)
        best = min(best, float(np.linalg.norm(p - (a + (b - a) * t))))
    return 0.0 if inside else best


def convex_hull(P):
    P = sorted(map(tuple, P))
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in P:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(P):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return np.array(lo[:-1] + up[:-1])


# nordic: feet are held under a pad; dragon: supported on a bench -> support is not the floor polygon
DYNAMIC = ("explosive", "clap", "jump", "kickup", "_mu", "wiper", "ttb", "swing", "kip", "free", "transition", "nordic", "dragon")


def balance(e, J):
    """Max distance (m) the COM sits outside the support polygon, over frames with >=2 low contacts.
    Exempt: ballistic / swinging exercises, and anything that leans on a wall or hangs from a bar,
    rings or pole (its support is not the floor polygon)."""
    if any(k in e["id"] for k in DYNAMIC):
        return 0.0
    kinds = {p[0] for p in e["props"]}
    if kinds & {1, 2, 4, 5, 6, 9, 7, 8}:
        return 0.0
    C = com(J)
    worst = 0.0
    low = (("toR", 0.08), ("toL", 0.08), ("anR", 0.11), ("anL", 0.11), ("haR", 0.08), ("haL", 0.08),
           ("wrR", 0.08), ("wrL", 0.08), ("knR", 0.09), ("knL", 0.09),
           ("pelvis", 0.14), ("spine", 0.15), ("chest", 0.16), ("head", 0.13))
    for fi in range(len(J)):
        pts = []
        for n, lim in low:
            p = J[fi, JI[n]]
            if p[1] < lim:
                pts.append((p[0], p[2]))
        for p in e["props"]:
            if p[0] == 3:   # box top as support for hands/feet
                x0, y0, z0, x1, y1, z1 = p[1:]
                for n in ("toR", "toL", "haR", "haL", "anR", "anL", "wrR", "wrL"):
                    q = J[fi, JI[n]]
                    if abs(q[1] - y1) < 0.08 and x0 - 0.05 <= q[0] <= x1 + 0.05:
                        pts.append((q[0], q[2]))
        if len(pts) >= 2:
            worst = max(worst, hull_dist(np.array(pts), np.array([C[fi, 0], C[fi, 2]])))
    return worst


def run(verbose=False):
    rows = {}
    for id_, e in motion.EX.items():
        rows[id_] = analyse(e)
    return rows


FLAGS = [  # (key, limit key, direction) : value above limit is a failure
    ("reach", "reach"), ("floor", "floor"), ("clip", "clip"), ("pop", None), ("seam", "seam"),
    ("knee_twist", "knee_twist"), ("hip_ext", "hip_ext"), ("hip_flex", "hip_flex"),
    ("sh_back", "sh_back"), ("slide", "slide"), ("balance", "balance"),
]


def failures(r):
    out = []
    for k, lk in FLAGS:
        if k == "pop":
            if r["pop"] > 0:
                out.append(k)
        elif r[k] > LIM[lk]:
            out.append(k)
    if r["elbow_min"] < LIM["elbow_min"] - 0.5:
        out.append("elbow_min")
    if r["knee_min"] < LIM["knee_min"] - 0.5:
        out.append("knee_min")
    return out


def load_all():
    import importlib
    for m in ("ex_push", "ex_pull", "ex_legs", "ex_core", "ex_hs", "ex_levers", "ex_planche_flag", "ex_rings"):
        importlib.import_module(m)


def main():
    load_all()
    rows = run()
    verbose = "-v" in sys.argv
    tot = {}
    bad_ex = 0
    for id_, r in rows.items():
        f = failures(r)
        if f:
            bad_ex += 1
        for k in f:
            tot[k] = tot.get(k, 0) + 1
        if verbose and f:
            print("%-22s %s" % (id_, "  ".join("%s=%.3f" % (k, r[k]) for k in f)),
                  ("clip:%s" % (r["clip_pair"],) if "clip" in f else ""))
    print("\nexercises: %d   with at least one failure: %d" % (len(rows), bad_ex))
    for k in sorted(tot, key=lambda x: -tot[x]):
        print("  %-12s %d" % (k, tot[k]))
    if "--strict" in sys.argv and bad_ex:
        sys.exit(1)


if __name__ == "__main__":
    main()

from h import *
from ex_pull import hp, legs_to, legs_tuck, BY, HANG_SY, PULL_PROPS

LV = [("Side", 90, 8), ("3/4 front", 50, 18), ("Front", 0, 8)]
LV_TOP = [("Side", 90, 14), ("3/4 front", 50, 22), ("Top", 0, 78)]
HV = [("Side", 90, 6), ("3/4 front", 40, 12), ("Front", 0, 6)]

# ---------------- Plank (forearms): kneeling plank -> full plank ----------------
def plank():
    Fy = 0.25
    th = th_for(Fy, 0.37)
    q = sup(0.0, Fy, th, 0.0, 0.04, 0.12, er=(0, -1, 0.1))
    S = shoulder_of(q)
    q["hr"] = V(S[0] + 0.27, 0.04, 0.12); q["hl"] = V(S[0] + 0.27, 0.04, -0.12)
    q["er"] = V(0, -1, 0.1); q["el"] = V(0, -1, 0.1); q["hwr"] = q["hwl"] = 1.0
    return q
pk = plank()
S0 = shoulder_of(pk)
thk = math.degrees(math.asin((0.37 - 0.06) / (THIGH + TORSO)))
dk = V(math.cos(math.radians(thk)), math.sin(math.radians(thk)), 0)
K = V(S0[0] - (THIGH + TORSO) * dk[0], 0.06, 0)
kneel = P(p=K + THIGH * dk, ta=thk, hr=pk["hr"], hl=pk["hl"], er=V(0, -1, 0.1), el=V(0, -1, 0.1), hwr=1, hwl=1,
          kr=V(0, -1, 0.1), kl=V(0, -1, 0.1), fr=K + V(-0.40, 0.03, 0.10), fl=K + V(-0.40, 0.03, -0.10),
          pfr=75, pfl=75, flr=0, fll=0, fvr=V(0, -1, 0), fvl=V(0, -1, 0))
kneel["p"] = kneel["p"] + V(0, 0, 0)
reg("core_plank", [kneel, pk], [], [SIDE_V, ("3/4 front", 50, 18), TOP], hold=True, durs=[1.4])

# ---------------- Dead bug ----------------
def deadbug(ext):
    q = lying_back()
    knee = q["p"] + V(0, THIGH, 0)
    ank = knee + V(SHIN * 0.998, 0, 0)
    q.update(fr=ank + V(0, 0, 0.09), fl=ank + V(0, 0, -0.09), pfr=0, pfl=0, flr=0, fll=0, kr=V(1, 0.3, 0.1), kl=V(1, 0.3, 0.1))
    S = shoulder_of(q)
    up = V(0, ARM * 0.98, 0)
    q.update(hr=S + V(0, 0, 0.19) + up, hl=S + V(0, 0, -0.19) + up, er=V(0, 0, 1), el=V(0, 0, 1))
    if ext:      # right arm back overhead + left leg out long and low, lower back stays down
        q["hr"] = V(S[0] - ARM * 0.97, 0.12, 0.19); q["er"] = V(0, 0.3, 1)
        t = q["p"] + LEG * 0.998 * V(math.cos(math.radians(14)), math.sin(math.radians(14)), 0)
        q["fl"] = t + V(0, 0, -0.09); q["pfl"] = 30.0; q["kl"] = V(0, 1, 0); q["fll"] = 0.0
    return q
reg("core_deadbug", [deadbug(False), deadbug(True)], [], LV_TOP, durs=[2.0], rdurs=[2.0])

# ---------------- Side plank (+ top-leg raise) ----------------
def side_plank(sag=False, arm="up"):
    F = V(0.0, 0.155, 0.0)
    Sy = 0.54
    th = math.degrees(math.asin((Sy - F[1]) / (LEG + TORSO)))
    d = V(math.cos(math.radians(th)), math.sin(math.radians(th)), 0)
    Sx = (LEG + TORSO) * d[0]
    if sag:
        thk = math.degrees(math.asin((Sy - 0.12) / TORSO))
        p = V(Sx - TORSO * math.cos(math.radians(thk)), 0.12, 0)
        th_use = thk
        dl = V(1, 0, 0)
    else:
        p = F + LEG * d
        th_use = th
        dl = d
    q = P(p=p, ta=th_use, roll=-90.0, kr=V(0, 0, 1), kl=V(0, 0, 1))
    base = p - LEG * 0.985 * dl
    q.update(fl=V(base[0], 0.10 if sag else base[1] - 0.05, 0.0), fr=V(base[0], 0.22 if sag else base[1] + 0.07, 0.0),
             flr=0, fll=0, pfl=0, pfr=0)
    if sag:
        q["fl"] = V(base[0] + 0.05, 0.10, 0.0); q["fr"] = V(base[0] + 0.05, 0.22, 0.0)
    J, _ = solve(q)
    shL, shR = J[JI["shL"]], J[JI["shR"]]
    q["hl"] = V(shL[0], 0.04, 0.27); q["el"] = V(0, -1, 0.0); q["hwl"] = 1.0; q["hdl"] = V(0, 0, 1)
    if arm == "up":
        q["hr"] = shR + V(0, ARM * 0.97, 0.0); q["er"] = V(-1, 0, 0.3)
    return q
sp0 = side_plank(sag=True); sp1 = side_plank()
reg("core_side", [sp0, sp1], [], [("Side", 90, 8), ("3/4 front", 50, 18), ("Top", 0, 78)], hold=True, durs=[1.5])
def side_leg(a):
    q = side_plank()
    th = q["ta"]
    t = math.radians(180 + th - a)       # legs run toward -x; abduct = rotate the top leg upward
    J, _ = solve(q)
    q["fr"] = J[JI["hipR"]] + LEG * 0.985 * V(math.cos(t), math.sin(t), 0)
    q["pfr"] = 30.0; q["kr"] = V(0, 0, 1)
    return q
sl0 = side_plank(); sl1 = side_leg(35)
reg("core_side_lift", [sl0, sl1], [], [("Side", 90, 8), ("3/4 front", 50, 18), ("Top", 0, 78)], durs=[1.6], rdurs=[1.8])

# ---------------- Hollow body, leg raise (lying) ----------------
def hollow(on):
    q = lying_back(shx=0.0)
    if on:
        q = P(p=V(TORSO * 0.97, 0.12, 0), ta=166.0, flex=16.0, neck=10.0)
        set_leg_dir(q, 9, z=0.07, pf=60)
    else:
        set_leg_dir(q, 0.5, z=0.07, pf=40)
    S = shoulder_of(q)
    u = V(math.cos(math.radians(q["ta"])), math.sin(math.radians(q["ta"])), 0)
    q.update(hr=S + V(0, 0, 0.14) + u * 0.56, hl=S + V(0, 0, -0.14) + u * 0.56, er=V(0, 0, 1), el=V(0, 0, 1))
    return q
reg("core_hollow", [hollow(False), hollow(True)], [], [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.6])
def legraise(a):
    q = lying_back()
    set_leg_dir(q, a, z=0.07, pf=55)
    S = shoulder_of(q)
    q["hr"] = V(q["p"][0] - 0.08, 0.04, 0.12); q["hl"] = V(q["p"][0] - 0.08, 0.04, -0.12)   # hands under the hips
    q["er"] = q["el"] = V(0, 0.3, 1); q["hwr"] = q["hwl"] = 1.0
    return q
reg("core_legraise", [legraise(7), legraise(88)], [], [SIDE_V, ("3/4 front", 50, 18), FRONT_V], durs=[1.8], rdurs=[2.2])

# ---------------- L-sit family (hands beside hips) ----------------
def lsit(lean=8, up=0.07, legs=3, tuck=False, one=False, sx=0.0, spread=0.07, tuck_k=(0.30, 0.30)):
    Sy = 0.04 + ARM * 0.985 + up
    ta = 90 + lean
    q = pose_from_shoulder(V(sx, Sy, 0), ta, shup=-up, er=V(-1, 0.2, 0.4), el=V(-1, 0.2, 0.4), neck=-4)
    q.update(hr=V(0.0, 0.04, 0.24), hl=V(0.0, 0.04, -0.24), hwr=1, hwl=1)
    p = q["p"]
    if tuck:
        knee = p + V(*tuck_k, 0)
        ank = p + V(0.18, 0.0, 0)
        q.update(fr=ank + V(0, 0, 0.10), fl=ank + V(0, 0, -0.10), pfr=55, pfl=55, flr=0, fll=0, kr=V(0, 1, 0.2), kl=V(0, 1, 0.2))
    else:
        set_leg_dir(q, legs, z=spread, pf=62, knee=(0, 1, 0.05))
        if one:
            ank = p + V(0.18, 0.0, 0)
            q["fl"] = ank + V(0, 0, -0.10); q["kl"] = V(0, 1, 0.2); q["pfl"] = 55.0
    return q
floor_start = P(p=V(0.0, 0.12, 0), ta=88, hr=V(0.0, 0.04, 0.24), hl=V(0.0, 0.04, -0.24), hwr=1, hwl=1, er=V(-1, 0.2, 0.4), el=V(-1, 0.2, 0.4))
set_leg_dir(floor_start, -5, z=0.07, pf=40)
floor_start["fr"][1] = ANKLE_H; floor_start["fl"][1] = ANKLE_H
floor_start["p"] = V(0.0, 0.07, 0)
LS_PROPS = []
reg("core_tuck_lsit", [floor_start, lsit(tuck=True)], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.5])
reg("core_lsit_one", [lsit(tuck=True), lsit(one=True, tuck=False, legs=3)], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.4])
reg("core_lsit", [floor_start, lsit()], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.5])
reg("core_lsit_high", [lsit(), lsit(lean=4, up=0.10, legs=22, sx=0.07)], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.5])
reg("core_vsit", [lsit(lean=4, up=0.10, legs=22, sx=0.07), lsit(lean=20, up=0.12, legs=48, sx=0.0)], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.6])
def manna():
    q = pose_from_shoulder(V(0.20, 0.04 + 0.55 + 0.12, 0), 60, shup=-0.12, neck=-5, shfw=0.06,
                           er=V(-1, 0.4, 0.4), el=V(-1, 0.4, 0.4))
    q.update(hr=V(0.0, 0.04, 0.24), hl=V(0.0, 0.04, -0.24), hwr=1, hwl=1)
    set_leg_dir(q, 18, z=0.07, pf=62, knee=(0, 1, 0.05))
    return q
reg("core_manna", [lsit(lean=20, up=0.12, legs=48), manna()], LS_PROPS, [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.8])

# ---------------- hanging core ----------------
def hk(kx, ky, ta=96, flex=18, shup=-0.03):
    q = hp(HANG_SY + 0.02, ta=ta, shup=shup, flex=flex)
    legs_tuck(q, kx=kx, ky=ky)
    return q
hang0 = hp(HANG_SY + 0.02, shup=-0.03)
reg("core_hang_knee", [hang0, hk(0.30, 0.22)], PULL_PROPS, HV, durs=[1.5], rdurs=[2.0])
def hlr(a, ta, flex):
    q = hp(HANG_SY + 0.02, ta=ta, shup=-0.03, flex=flex)
    legs_to(q, a, pf=62, knee=(0, 1, 0.05))
    return q
reg("core_hang_leg", [hang0, hlr(94, 98, 14)], PULL_PROPS, HV, durs=[1.5], rdurs=[2.0])
def ttb():
    q = pose_from_shoulder(V(-0.14, BY - 0.60, 0), 132, shup=-0.03, neck=4, flex=10, er=V(-0.3, -1, 0.35), el=V(-0.3, -1, 0.35))
    q["hr"] = V(0, BY - 0.075, 0.28); q["hl"] = V(0, BY - 0.075, -0.28)
    p = q["p"]
    ank = V(0.10, BY - 0.24, 0)
    q.update(fr=ank + V(0, 0, 0.07), fl=ank + V(0, 0, -0.07), pfr=55, pfl=55, flr=0, fll=0, kr=V(1, 0, 0.1), kl=V(1, 0, 0.1))
    return q
reg("core_ttb", [hang0, ttb()], PULL_PROPS, HV, durs=[1.2], rdurs=[2.0])
def wiper(side):
    q = pose_from_shoulder(V(-0.14, BY - 0.60, 0), 132, shup=-0.03, flex=10, er=V(-0.3, -1, 0.35), el=V(-0.3, -1, 0.35))
    q["hr"] = V(0, BY - 0.075, 0.28); q["hl"] = V(0, BY - 0.075, -0.28)
    p = q["p"]
    a = math.radians(side)
    t = p + LEG * 0.975 * V(0.10, math.cos(a), math.sin(a)) / np.linalg.norm(V(0.10, math.cos(a), math.sin(a)))
    q.update(fr=t + V(0, 0, 0.05), fl=t + V(0, 0, -0.05), pfr=55, pfl=55, flr=0, fll=0, kr=V(1, 0, 0.1), kl=V(1, 0, 0.1))
    return q
reg("core_wiper", [wiper(-48), wiper(0), wiper(48)], PULL_PROPS, [("Rear", 180, 6), ("Front", 0, 6), ("Side", 90, 6)], durs=[1.4, 1.4], rdurs=[1.4, 1.4])

# ---------------- dragon flag (bench) ----------------
BENCH = box(-1.15, 0.0, -0.22, 0.10, 0.45, 0.22)
def dragon(phi, tuck=False):
    S = V(-0.55, 0.45 + 0.10, 0)
    d = V(math.cos(math.radians(phi)), math.sin(math.radians(phi)), 0)
    ta = 180 + phi
    p = S + TORSO * d
    q = P(p=p, ta=ta, neck=min(100.0, phi + 8.0), kr=V(-1, 0, 0.1), kl=V(-1, 0, 0.1))
    q.update(hr=V(-0.95, 0.47, 0.20), hl=V(-0.95, 0.47, -0.20), hwr=0, hwl=0, er=V(0, -1, 0.5), el=V(0, -1, 0.5))
    if tuck:
        f = q["p"] * 0 + V(-math.sin(math.radians(phi)), math.cos(math.radians(phi)), 0)
        ank = p + 0.16 * d - 0.20 * f
        q.update(fr=ank + V(0, 0, 0.07), fl=ank + V(0, 0, -0.07), pfr=50, pfl=50, flr=0, fll=0, kr=f, kl=f)
    else:
        t = p + LEG * 0.998 * d
        q.update(fr=t + V(0, 0, 0.06), fl=t + V(0, 0, -0.06), pfr=60, pfl=60, flr=0, fll=0)
    return q
lie = dragon(5)
lie["p"] = V(-0.55 + TORSO, 0.45 + 0.12, 0)
reg("core_dragon_full", [dragon(88), dragon(22)], [BENCH], [SIDE_V, ("3/4 rear", 140, 16), FRONT_V], durs=[2.4], rdurs=[2.4])
reg("core_dragon_neg", [dragon(88), dragon(88), dragon(18)], [BENCH], [SIDE_V, ("3/4 rear", 140, 16), FRONT_V], durs=[1.0, 5.0], rdurs=[1.0, 1.5])
reg("core_dragon_tuck", [dragon(86, True), dragon(40, True)], [BENCH], [SIDE_V, ("3/4 rear", 140, 16), FRONT_V], durs=[2.2], rdurs=[2.2])

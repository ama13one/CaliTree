from h import *
from ex_core import lsit, floor_start

HV = [("Side", 90, 8), ("3/4 front", 50, 16), ("Front", 0, 8)]
HVB = [("Side", 90, 8), ("3/4 rear", 130, 16), ("Rear", 180, 8)]
MATH = 0.10

def with_arms_bent(q, S_target=None):
    return q

# ---------------- wrist prep: quadruped, rock the shoulders past the hands ----------------
def quad(rock):
    hx = 0.55
    Sx = hx + rock
    th = math.degrees(math.asin(0.0)) 
    S = V(Sx, 0.52, 0)
    # hips above the knees, thighs vertical, torso horizontal-ish
    K = V(Sx - 0.50 + 0.0, 0.05, 0)
    p = V(K[0], K[1] + THIGH * 0.998, 0)
    ta = math.degrees(math.atan2(S[1] - p[1], S[0] - p[0]))
    q = P(p=p, ta=ta, hr=V(hx, 0.04, 0.19), hl=V(hx, 0.04, -0.19), hwr=1, hwl=1, er=V(-1, 0.3, 0.3), el=V(-1, 0.3, 0.3),
          kr=V(0, -1, 0.1), kl=V(0, -1, 0.1), fr=K + V(-0.38, 0.03, 0.10), fl=K + V(-0.38, 0.03, -0.10), pfr=75, pfl=75, flr=0, fll=0,
          fvr=V(0, -1, 0), fvl=V(0, -1, 0), neck=-10)
    return q
reg("hs_wrist", [quad(0.0), quad(0.14), quad(-0.10)], [], [SIDE_V, ("3/4 front", 50, 22), TOP], durs=[1.4, 2.0], rdurs=[1.4, 2.0])

# ---------------- pike push-up ----------------
def pike(Sy, Sx, ax=-0.82, ay=0.10, elbows=True, er=(-1, 0.3, 0.5)):
    S = V(Sx, Sy, 0)
    q = pose_pa(S, V(ax, ay, 0), er=V(*er), neck=-20)
    q.update(hr=V(0.0, 0.04, 0.24), hl=V(0.0, 0.04, -0.24), hwr=1, hwl=1)
    q.update(fr=V(ax, ay, 0.10), fl=V(ax, ay, -0.10), flr=0, fll=0, kr=V(-1, 0, 0.1), kl=V(-1, 0, 0.1))
    fit_toes(q, 0.03)
    return q
reg("hs_pike", [pike(0.60, -0.03), pike(0.30, 0.12)], [], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.8], rdurs=[1.6])

# ---------------- wall helpers ----------------
WX = -0.06          # chest-to-wall: wall behind the hands, toes touch it
def cw_lam(hx, Wx=WX):
    return math.degrees(math.asin(((Wx + 0.12) - hx) / (LEG + TORSO)))
def cw(hx=0.28, Wx=WX, **kw):
    return hs_pose(hx=hx, lam=cw_lam(hx, Wx), **kw)
def cw_low(hx, Sy, dx=0.12, Wx=WX, hy=0.04, strad=0.0):
    """Lowered handstand (head toward the floor ahead of the hands), toes still on the wall."""
    Sx = hx + dx
    ax = Wx + 0.12
    ay = Sy + math.sqrt((LEG * 0.995 + TORSO) ** 2 - (Sx - ax) ** 2) - 0.02
    q = pose_pa(V(Sx, Sy, 0), V(ax, ay, 0), er=V(1, 0.1, 0.55), neck=-8, shup=0.02)
    q.update(hr=V(hx, hy, 0.22), hl=V(hx, hy, -0.22), hwr=1, hwl=1, fr=V(ax, ay, 0.07), fl=V(ax, ay, -0.07),
             pfr=65, pfl=65, flr=0, fll=0, kr=V(-1, 0, 0.1), kl=V(-1, 0, 0.1))
    return q
WALL = wall(WX)
MAT = box(0.0, 0, -0.30, 0.55, 0.10, 0.30)

# ---- wall walk: straight body, toes walk up the wall while the hands walk back toward it
def walk_pose(beta, pf, hy=0.04):
    L = (LEG + TORSO) * 0.998
    Ax = WX + 0.12
    Sy = 0.60
    Ay = Sy + L * math.sin(math.radians(beta))
    Sx = Ax + L * math.cos(math.radians(beta))
    d = V(-math.cos(math.radians(beta)), -math.sin(math.radians(beta)), 0)      # shoulder -> feet
    S = V(Sx, Sy, 0)
    q = pose_pa(S, V(Ax, Ay, 0), er=V(-1, 0.3, 0.4), neck=-10, shup=0.03)
    q.update(hr=V(Sx - 0.02, hy, 0.22), hl=V(Sx - 0.02, hy, -0.22), hwr=1, hwl=1, fr=V(Ax, Ay, 0.10), fl=V(Ax, Ay, -0.10),
             pfr=pf, pfl=pf, flr=0, fll=0, kr=V(-1, 0.0, 0.1), kl=V(-1, 0.0, 0.1))
    return q
w0, w1, w2, w3 = walk_pose(-13, 20), walk_pose(30, 40), walk_pose(62, 55), walk_pose(83, 65)
reg("hs_wall_walk", [w0, w1, w2, w3], [WALL], [SIDE_V, ("3/4 front", 50, 16), TOP], durs=[1.8, 1.8, 1.6], rdurs=[1.6, 1.6, 1.6])
reg("hs_wall_hold", [w2, w3], [WALL], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], hold=True, durs=[1.8])

# ---- compression lift (seated pike)
reg("hs_compress", [floor_start, lsit(lean=-14, up=0.12, legs=26, sx=0.10)], [], [SIDE_V, ("3/4 front", 50, 18), FRONT_V], hold=True, durs=[1.8])

# ---- elevated pike push-up (feet on a 45 cm box)
def epike(Sy, Sx):
    A = V(-0.85, 0.45 + 0.20, 0)
    q = pose_pa(V(Sx, Sy, 0), A, er=V(-1, 0.3, 0.5), neck=-20)
    q.update(hr=V(0.0, 0.04, 0.24), hl=V(0.0, 0.04, -0.24), hwr=1, hwl=1, fr=V(A[0], A[1], 0.10), fl=V(A[0], A[1], -0.10),
             flr=0, fll=0, kr=V(-1, 0, 0.1), kl=V(-1, 0, 0.1))
    fit_toes(q, 0.47)
    return q
reg("hs_elev_pike", [epike(0.62, -0.04), epike(0.34, 0.14)], [box(-1.15, 0, -0.30, -0.70, 0.45, 0.30)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.9], rdurs=[1.7])

# ---- wall HSPU negative / full / deficit
reg("hs_hspu_neg", [cw(0.05, hx=None) if False else cw(0.30), cw(0.30), cw_low(0.30, 0.44)], [WALL, box(0.18, 0, -0.30, 0.70, 0.10, 0.30)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.0, 4.0], rdurs=[1.0, 1.4])
reg("hs_hspu_wall", [cw(0.30), cw_low(0.30, 0.44)], [WALL, box(0.18, 0, -0.30, 0.70, 0.10, 0.30)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[2.4], rdurs=[2.0])
def defi(low):
    q = cw(0.30, hy=0.24) if not low else cw_low(0.30, 0.34, hy=0.24)
    return q
reg("hs_hspu_def", [defi(False), defi(True)], [WALL, pbars(0.10, 0.50, 0.20, 0.22)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[2.4], rdurs=[2.0])

# ---- heel pulls: toes leave the wall, balance on the fingers
reg("hs_heel_pulls", [cw(0.30), hs_pose(hx=0.30, lam=0.0), hs_pose(hx=0.30, lam=0.0)], [WALL], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.4, 1.2], rdurs=[1.2, 1.4])

# ---- kick-up (back to wall: wall in front of the athlete)
KW = 0.86
def ku_stand():
    q = stand(0.10)
    reach_arms(q, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
    return q
def ku_fold():
    S = V(0.50, 0.62, 0)
    p = V(0.05, 0.80, 0)
    q = P(p=p, ta=math.degrees(math.atan2(S[1] - p[1], S[0] - p[0])), hr=V(0.55, 0.04, 0.22), hl=V(0.55, 0.04, -0.22), hwr=1, hwl=1,
          er=V(-1, 0.3, 0.5), el=V(-1, 0.3, 0.5), neck=-20, kr=V(1, 0, 0.1), kl=V(1, 0.4, 0.1))
    q.update(fr=V(0.10, ANKLE_H, 0.10), flr=1, fl=p + LEG * 0.95 * V(-0.82, -0.57, 0) + V(0, 0, -0.10), pfl=40, fll=0)
    return q
def ku_kick():
    q = ku_fold()
    q["p"] = V(0.14, 1.02, 0)
    q["ta"] = 300.0
    q["fl"] = q["p"] + LEG * 0.99 * V(0.34, 0.94, 0) + V(0, 0, -0.07)
    q["fr"] = V(0.10, 0.28, 0.10); q["flr"] = 0; q["pfr"] = 55
    return q
def ku_top():
    hx = 0.50
    lam = math.degrees(math.asin((KW - 0.03 - hx) / (LEG + TORSO)))
    return hs_pose(hx=hx, lam=lam)
reg("hs_kickup", [ku_stand(), ku_fold(), ku_kick(), ku_top()], [wall(KW)], [SIDE_V, ("3/4 rear", 130, 16), FRONT_V], durs=[1.1, 0.7, 0.8], rdurs=[1.0, 0.9, 1.2])
reg("hs_free", [ku_fold(), ku_kick(), hs_pose(hx=0.50, lam=0.0)], [], [SIDE_V, ("3/4 rear", 130, 16), FRONT_V], hold=True, durs=[0.8, 0.9], rdurs=[0.9, 1.1])

# ---- weight shifts / walk
def shift(sz, hx=0.0, hl_x=None, lift_l=0.0, lift_r=0.0):
    return hs_pose(hx=hx, lam=0.0, sz=sz, lift_l=lift_l, lift_r=lift_r)
reg("hs_shift", [shift(0.11, lift_l=0.05), shift(0.0), shift(-0.11, lift_r=0.05)], [], [REAR_V, ("3/4 rear", 130, 16), SIDE_V], durs=[1.4, 1.4], rdurs=[1.4, 1.4])
def step_pose(sz, lift_l=0.0, lift_r=0.0, lx=0.0, rx=0.0, sx=0.0):
    q = hs_pose(hx=0.0, lam=0.0, sz=sz, sx=sx, lift_l=lift_l, lift_r=lift_r)
    q["hl"] = V(lx, 0.04 + lift_l, -0.20); q["hr"] = V(rx, 0.04 + lift_r, 0.20)
    return q
reg("hs_walk", [step_pose(0.0), step_pose(0.11, lift_l=0.06), step_pose(0.11, lift_l=0.10, lx=0.22, sx=0.04),
                step_pose(-0.02, lx=0.22, sx=0.12), step_pose(-0.11, lx=0.22, lift_r=0.06, sx=0.12)],
    [], [SIDE_V, REAR_V, ("3/4 rear", 130, 16)], durs=[1.0, 0.9, 0.9, 0.9], rdurs=[0.9, 0.9, 0.9, 1.0])

# ---- straddle press and pike press (freestanding)
def st_fold():
    q = pose_pa(V(0.30, 0.56, 0), V(-0.40, 0.10, 0), er=V(-1, 0.3, 0.5), neck=-15)
    q.update(hr=V(0.30, 0.04, 0.24), hl=V(0.30, 0.04, -0.24), hwr=1, hwl=1, flr=1, fll=1, pfr=0, pfl=0)
    q["fr"] = V(-0.24, 0.08, 0.28); q["fl"] = V(-0.24, 0.08, -0.28)
    return q
def st_mid():
    q = hs_pose(hx=0.30, lam=-10, Sy=0.64, strad=62, sx=0.33, shup=0.04)
    q["p"] = V(0.12, 1.00, 0); q["ta"] = 300.0
    t = q["p"] + LEG * 0.99
    q["fr"] = q["p"] + LEG * 0.99 * V(-0.45, 0.35, 0.82) / np.linalg.norm(V(-0.45, 0.35, 0.82))
    q["fl"] = q["p"] + LEG * 0.99 * V(-0.45, 0.35, -0.82) / np.linalg.norm(V(-0.45, 0.35, -0.82))
    return q
reg("hs_straddle_press", [st_fold(), st_mid(), hs_pose(hx=0.30, lam=0.0, strad=32, sx=0.30), hs_pose(hx=0.30, lam=0.0, sx=0.30)],
    [], [SIDE_V, ("3/4 rear", 130, 16), REAR_V], durs=[1.4, 1.2, 1.0], rdurs=[1.2, 1.2, 1.4])
def pp_fold():
    q = pose_pa(V(0.28, 0.50, 0), V(-0.26, 0.10, 0), er=V(-1, 0.3, 0.5), neck=-15)
    q.update(hr=V(0.28, 0.04, 0.22), hl=V(0.28, 0.04, -0.22), hwr=1, hwl=1, fr=V(-0.26, 0.08, 0.08), fl=V(-0.26, 0.08, -0.08), flr=0, fll=0)
    return fit_toes(q, 0.012)
def pp_lean():
    q = pose_pa(V(0.34, 0.60, 0), V(-0.22, 0.30, 0), er=V(-1, 0.3, 0.5), neck=-12)
    q.update(hr=V(0.28, 0.04, 0.22), hl=V(0.28, 0.04, -0.22), hwr=1, hwl=1, fr=V(-0.22, 0.30, 0.08), fl=V(-0.22, 0.30, -0.08), pfr=45, pfl=45, flr=0, fll=0)
    return fit_toes(q, 0.03)
def pp_mid():
    q = pose_pa(V(0.34, 0.62, 0), V(0.05, 1.00, 0), er=V(-1, 0.3, 0.5), neck=-12)
    q.update(hr=V(0.28, 0.04, 0.22), hl=V(0.28, 0.04, -0.22), hwr=1, hwl=1, fr=V(0.05, 1.00, 0.08), fl=V(0.05, 1.00, -0.08), pfr=55, pfl=55, flr=0, fll=0)
    return q
def pp_heels():
    q = pose_pa(V(0.30, 0.55, 0), V(-0.25, 0.15, 0), er=V(-1, 0.3, 0.5), neck=-14)
    q.update(hr=V(0.28, 0.04, 0.22), hl=V(0.28, 0.04, -0.22), hwr=1, hwl=1, fr=V(-0.25, 0.15, 0.08), fl=V(-0.25, 0.15, -0.08), pfr=30, pfl=30, flr=0, fll=0)
    return fit_toes(q, 0.03)
reg("hs_pike_press", [pp_fold(), pp_heels(), pp_lean(), pp_mid(), hs_pose(hx=0.28, lam=0.0, sx=0.30)], [], [SIDE_V, ("3/4 rear", 130, 16), FRONT_V], durs=[0.8, 0.8, 1.4, 1.4], rdurs=[1.4, 1.4, 0.8, 0.8])

# ---- freestanding HSPU, one-arm handstand, 90-degree push-up
reg("hs_hspu_free", [hs_pose(hx=0.0, lam=0.0), hs_pose(hx=0.0, lam=0.0, Sy=0.40, sx=0.03, er=(1, 0.1, 0.55))], [], [SIDE_V, ("3/4 rear", 130, 16), REAR_V], durs=[2.4], rdurs=[2.0])
def oa(strad=0.0, wide=False):
    q = hs_pose(hx=0.0, lam=0.0, sz=-0.07, strad=strad, hz=0.06)
    q["hl"] = None
    J, _ = solve({**q, "hl": V(0, 0.8, -0.2)})
    shL = J[JI["shL"]]
    q["hl"] = shL + V(0, -0.03, -0.54); q["el"] = V(0, 0, -1)
    q["hwl"] = 0.0
    return q
reg("hs_oa", [hs_pose(hx=0.0, lam=0.0, strad=0), oa(strad=0), oa(strad=48)], [], [REAR_V, ("3/4 rear", 130, 16), SIDE_V], hold=True, durs=[1.3, 1.3], rdurs=[1.3, 1.3])
def n90(low):
    if not low:
        return hs_pose(hx=0.0, lam=0.0, hy=0.29)
    S = V(0.12, 0.50, 0)
    p = S + V(-TORSO * 0.98, 0.04, 0)
    q = P(p=p, ta=3.0, hr=V(0.0, 0.29, 0.22), hl=V(0.0, 0.29, -0.22), hwr=1, hwl=1, er=V(-1, 0.1, 0.5), el=V(-1, 0.1, 0.5), neck=-20)
    t = p + LEG * 0.995 * V(-0.999, -0.02, 0)
    q.update(fr=t + V(0, 0, 0.06), fl=t + V(0, 0, -0.06), pfr=65, pfl=65, flr=0, fll=0, kr=V(0, -1, 0.1), kl=V(0, -1, 0.1))
    return q
reg("hs_90", [n90(False), n90(False), n90(True)], [pbars(-0.25, 0.25, 0.25, 0.22)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[0.1, 2.0], rdurs=[0.1, 2.0])

# ---- wall-assisted straddle press (back to the wall at the start, belly to the wall at the end)
PW = -0.10
def pw_fold():
    q = pose_pa(V(0.32, 0.56, 0), V(-0.04, 0.10, 0), er=V(-1, 0.3, 0.5), neck=-15)
    q.update(hr=V(0.32, 0.04, 0.24), hl=V(0.32, 0.04, -0.24), hwr=1, hwl=1, flr=1, fll=1, pfr=0, pfl=0)
    q["fr"] = V(-0.02, 0.08, 0.22); q["fl"] = V(-0.02, 0.08, -0.22)
    return q
def pw_mid():
    q = hs_pose(hx=0.32, lam=-10, Sy=0.62, strad=0, sx=0.34, shup=0.04)
    q["p"] = V(0.12, 1.02, 0); q["ta"] = 300.0
    for k, sgn in (("fr", 1), ("fl", -1)):
        d = V(-0.30, 0.42, sgn * 0.85); q[k] = q["p"] + LEG * 0.99 * d / np.linalg.norm(d)
    return q
def pw_top(strad):
    hx = 0.32
    lam = math.degrees(math.asin(((PW + 0.12) - hx) / (LEG + TORSO)))
    return hs_pose(hx=hx, lam=lam, strad=strad)
reg("hs_press_wall", [pw_fold(), pw_mid(), pw_top(34), pw_top(0)], [wall(PW)], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], durs=[1.4, 1.2, 1.0], rdurs=[1.2, 1.2, 1.4])

"""Render the frame where an exercise is worst for a given metric, from 3 cameras.
python3 tools3d/worst.py out.png metric id1 id2 ..."""
import sys, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(__file__))
import motion, preview, audit
from rig import JI

def worst_frame(e, metric):
    J = e["frames"]
    if metric == "clip":
        P = {k: (audit.jt(J, a), audit.jt(J, b), r) for k, (a, b, r) in audit.SEG.items()}
        best = np.zeros(len(J))
        for (a, b) in audit.PAIRS:
            d = audit.seg_dist(P[a][0], P[a][1], P[b][0], P[b][1])
            best = np.maximum(best, P[a][2] + P[b][2] - d - audit.ALLOW[(a, b)])
        return int(best.argmax())
    if metric == "floor":
        w = np.zeros(len(J))
        for name, (a, b, r) in audit.SEG.items():
            for n in (a, b):
                w = np.maximum(w, r - audit.jt(J, n)[:, 1])
        return int(w.argmax())
    if metric == "pop":
        d = np.linalg.norm(np.diff(J, axis=0), axis=-1).max(1)
        return int(d.argmax()) + 1
    return len(J) // 2

def main():
    fname, metric, ids = sys.argv[1], sys.argv[2], sys.argv[3:]
    audit.load_all()
    views = [("Side", 90, 8), ("Front", 0, 8), ("3/4", 50, 16)]
    fig, axs = plt.subplots(len(ids), 3, figsize=(8, len(ids) * 2.6))
    axs = np.atleast_2d(axs)
    for r, id_ in enumerate(ids):
        e = motion.EX[id_]; k = worst_frame(e, metric)
        allp = e["frames"].reshape(-1, 3); c = (allp.max(0) + allp.min(0)) / 2
        ext = np.abs(allp - c).max() * 1.05 + 0.1
        for ax, (n, az, el) in zip(axs[r], views):
            rr, uu, _ = preview.cam_basis(az, el)
            ax.set_xlim(np.dot(c, rr) - ext, np.dot(c, rr) + ext); ax.set_ylim(np.dot(c, uu) - ext, np.dot(c, uu) + ext)
            ax.set_aspect("equal"); ax.axis("off")
            preview.draw_props(ax, e["props"], az, el)
            g = preview.project(np.array([[-3, 0, 0], [3, 0, 0]]), az, el)[0]
            ax.plot(g[:, 0], g[:, 1], color="#94a3b8", lw=1)
            preview.draw_pose(ax, e["frames"][k], az, el, "#1d4ed8", lw=3)
            ax.set_title("%s f%d %s" % (id_, k, n), fontsize=7)
    plt.tight_layout(); plt.savefig(fname, dpi=70); plt.close(fig)
main()

"""Registry + baking of exercise motions.

Baking pipeline (v2, see tools3d/README.md "Animation quality"):
  1. unwrap   angle parameters take the SHORT way round between keys (ta=300 after ta=-21 is a 39 deg turn,
              not a 321 deg spin)
  2. spline   monotone cubic Hermite through the key poses (no overshoot, so planted hands/feet stay planted);
              speed is continuous through intermediate keys, zero at the very start / end of the move
  3. solve    IK with temporal pole continuity (elbows / knees never snap to the other side)
  4. refine   contact aware correction: planted hands/feet stay exactly planted, nothing sinks into the
              floor, limbs keep clear of each other, joints stay inside anatomical limits  (refine.py)
"""
import glob
import hashlib
import math
import os
import pickle
import numpy as np
from rig import solve, lerp_pose, JI, NJ

EX = {}
SIDE, FRONT, REAR, LEFT = 90, 0, 180, 270


def smooth(t):
    return t * t * (3 - 2 * t)


# prop helpers: (kind, six floats)
def bar(x, y, hw=0.6): return (1, x, y, hw, 0, 0, 0)
def wall(x): return (2, x, 0, 0, 0, 0, 0)
def box(x0, y0, z0, x1, y1, z1): return (3, x0, y0, z0, x1, y1, z1)
def rings(x, y, top=2.6, hs=0.26): return (4, x, y, top, hs, 0, 0)
def pole(x, z=0.0, h=2.4): return (5, x, z, h, 0, 0, 0)
def pbars(x0, x1, y, hs=0.28): return (6, x0, x1, y, hs, 0, 0)


def cam(name, az, el=12): return (name, az, el)


STEPS = 16
ANGLES = ("ta", "roll", "yaw", "lean")      # full-circle angle parameters (degrees)


def unwrap_keys(keys):
    """Copy of keys where every angle parameter moves by the short arc between consecutive keys.
    Differences of 180 deg or less are left exactly as authored."""
    out = [{k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in keys[0].items()}]
    for q in keys[1:]:
        n = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in q.items()}
        for a in ANGLES:
            d = n[a] - out[-1][a]
            while d > 180.0:
                n[a] -= 360.0
                d = n[a] - out[-1][a]
            while d < -180.0:
                n[a] += 360.0
                d = n[a] - out[-1][a]
        out.append(n)
    return out


def _flat(q, names):
    return np.concatenate([np.atleast_1d(np.asarray(q[k], float)) for k in names])


def _unflat(v, names, like):
    q, i = {}, 0
    for k in names:
        n = np.size(like[k])
        q[k] = v[i:i + n].copy() if isinstance(like[k], np.ndarray) else float(v[i])
        i += n
    return q


def pchip_tangents(V, T):
    """Fritsch-Carlson tangents (value per second) for key values V[k, :] and segment durations T[k].
    End tangents are zero (ease in / ease out of the whole move)."""
    n = len(V)
    m = np.zeros_like(V)
    if n < 3:
        return m
    d = [(V[k + 1] - V[k]) / max(T[k], 1e-6) for k in range(n - 1)]
    for k in range(1, n - 1):
        a, b = d[k - 1], d[k]
        w1, w2 = 2 * T[k] + T[k - 1], T[k] + 2 * T[k - 1]
        same = (a * b) > 1e-12
        with np.errstate(divide="ignore", invalid="ignore"):
            hm = (w1 + w2) / (w1 / np.where(same, a, 1.0) + w2 / np.where(same, b, 1.0))
        m[k] = np.where(same, hm, 0.0)
    return m


def hermite(v0, v1, m0, m1, T, s):
    s2, s3 = s * s, s * s * s
    return ((2 * s3 - 3 * s2 + 1) * v0 + (s3 - 2 * s2 + s) * T * m0 +
            (-2 * s3 + 3 * s2) * v1 + (s3 - s2) * T * m1)


ROOT_OF = {"hr": "shR", "hl": "shL", "fr": "hipR", "fl": "hipL"}


def _slerp_offset(o0, o1, w, fwd):
    """Offset vector from the limb root: direction slerped along the short arc (through `fwd` when the two
    offsets are nearly opposite), length interpolated linearly."""
    l0, l1 = np.linalg.norm(o0), np.linalg.norm(o1)
    d0, d1 = o0 / l0, o1 / l1
    ax = np.cross(d0, d1)
    sn = np.linalg.norm(ax)
    cs = float(np.dot(d0, d1))
    ang = math.atan2(sn, cs)
    if sn < 0.2:                                  # (nearly) opposite: pick the arc that passes in front of the body
        mid_axis = np.cross(d0, fwd)
        ax = mid_axis if np.linalg.norm(mid_axis) > 1e-6 else np.array([0.0, 0.0, 1.0])
        ax = ax / np.linalg.norm(ax)
        ang = math.acos(max(-1.0, min(1.0, cs)))
    else:
        ax = ax / sn
    k = ax
    t = ang * w
    d = d0 * math.cos(t) + np.cross(k, d0) * math.sin(t) + k * np.dot(k, d0) * (1 - math.cos(t))
    return d * (l0 + (l1 - l0) * w)


def arc_targets(out, steps):
    """Free hand / foot targets that would travel on a straight chord THROUGH the shoulder / hip (the limb
    would have to turn inside out, so the knee / elbow flips) are re-routed on an arc around that joint."""
    from rig import solve as _solve
    nseg = (len(out) - 1) // steps
    J = [_solve(q)[0] for q in out]
    for i in range(nseg):
        k0, k1 = i * steps, (i + 1) * steps
        for e, root in ROOT_OF.items():
            v0, v1 = out[k0][e], out[k1][e]
            if np.linalg.norm(v1 - v0) < 0.12:
                continue
            o0, o1 = v0 - J[k0][JI[root]], v1 - J[k1][JI[root]]
            if min(np.linalg.norm(o0), np.linalg.norm(o1)) < 0.05:
                continue
            # does the chord (in root-relative coordinates) pass close to the root, with a big turn?
            c = o1 - o0
            t = float(np.clip(-np.dot(o0, c) / (np.dot(c, c) + 1e-12), 0, 1))
            near = float(np.linalg.norm(o0 + c * t))
            turn = math.degrees(math.acos(max(-1, min(1, float(np.dot(o0, o1) / (np.linalg.norm(o0) * np.linalg.norm(o1)))))))
            if near > 0.30 or turn < 50:
                continue
            for f in range(k0 + 1, k1):
                v = out[f][e]
                w = float(np.clip(np.dot(v - v0, v1 - v0) / (np.dot(v1 - v0, v1 - v0) + 1e-12), 0, 1))
                Jf = J[f]
                u = Jf[JI["chest"]] - Jf[JI["pelvis"]]
                rr = Jf[JI["hipR"]] - Jf[JI["hipL"]]
                fwd = np.cross(u, rr)
                fwd = fwd / (np.linalg.norm(fwd) + 1e-9)
                out[f][e] = Jf[JI[root]] + _slerp_offset(o0, o1, w, fwd)
    return out


def sanitize_keys(keys):
    """Key poses whose free hand / foot target sits on top of the shoulder / hip (limb folded to a point) get a
    target at the minimum fold distance in the anatomical direction. Planted targets are never touched."""
    import refine
    flags = []
    for i, q in enumerate(keys):
        fl = {}
        for e in refine.EFFECTORS:
            nb = [keys[j][e] for j in (i - 1, i + 1) if 0 <= j < len(keys)]
            fl[e] = any(float(np.linalg.norm(q[e] - x)) < 0.02 for x in nb)
        flags.append(fl)
    return [refine.project_free_targets(q, flags[i], {}) for i, q in enumerate(keys)]


def pose_frames(keys, steps, durs=None, rdurs=None):
    """Interpolated pose list: `steps` frames per segment plus the final key."""
    nseg = len(keys) - 1
    names = list(keys[0].keys())
    uk = unwrap_keys(keys)
    Vk = np.array([_flat(q, names) for q in uk])
    if durs is None:
        durs = [1.0] * nseg
    if rdurs is None:
        rdurs = durs
    T = np.array([(float(a) + float(b)) / 2 for a, b in zip(durs, rdurs)])
    M = pchip_tangents(Vk, T)
    out = []
    for i in range(nseg):
        for s in range(steps):
            v = hermite(Vk[i], Vk[i + 1], M[i], M[i + 1], T[i], s / steps)
            out.append(_unflat(v, names, keys[0]))
    out.append(_unflat(Vk[-1], names, keys[0]))
    return arc_targets(out, steps)


_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".cache")


def _code_hash():
    h = hashlib.sha1()
    for f in ("rig.py", "refine.py", "body.py", "motion.py"):
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), f), "rb") as fh:
            h.update(fh.read())
    return h.hexdigest()


_CODE = None


def _refined(id, keys, poses, key_idx, props, durs, rdurs, steps):
    """refine.refine with an on-disk cache keyed by the exercise data + the code that bakes it
    (delete tools3d/.cache or set CALITREE_NOCACHE=1 to force a full re-bake)."""
    global _CODE
    import refine
    if os.environ.get("CALITREE_NOCACHE"):
        return refine.refine(poses, keys, key_idx, list(props))
    if _CODE is None:
        _CODE = _code_hash()
    h = hashlib.sha1(_CODE.encode())
    h.update(repr((id, steps, list(durs), list(rdurs), [p for p in props])).encode())
    for q in keys:
        for k in sorted(q):
            h.update(np.asarray(q[k], float).round(6).tobytes())
    path = os.path.join(_CACHE_DIR, id + "_" + h.hexdigest()[:16] + ".pkl")
    if os.path.exists(path):
        with open(path, "rb") as fh:
            return pickle.load(fh)
    out = refine.refine(poses, keys, key_idx, list(props))
    os.makedirs(_CACHE_DIR, exist_ok=True)
    for old in glob.glob(os.path.join(_CACHE_DIR, id + "_*.pkl")):
        os.remove(old)
    with open(path, "wb") as fh:
        pickle.dump(out, fh)
    return out


def reg(id, keys, props=(), views=((("Side", 90, 10)),), hold=False, loop=False, durs=None, steps=STEPS, rdurs=None):
    nseg = len(keys) - 1
    durs = list(durs) if durs else [1.0] * nseg
    if len(durs) == 1 and nseg > 1:
        durs = durs * nseg
    assert len(durs) == nseg, (id, len(durs), nseg)
    rdurs = list(rdurs) if rdurs else list(durs)
    if len(rdurs) == 1 and nseg > 1:
        rdurs = rdurs * nseg
    assert len(rdurs) == nseg, (id, "rdurs")
    ikeys = sanitize_keys(keys) if not os.environ.get("CALITREE_NOREFINE") else keys
    poses = pose_frames(ikeys, steps, durs, rdurs)
    key_idx = [i * steps for i in range(nseg + 1)]
    if not os.environ.get("CALITREE_NOREFINE"):
        poses = _refined(id, keys, poses, key_idx, props, durs, rdurs, steps)
    warns = []
    J = []
    st = {}
    for fi, q in enumerate(poses):
        j, w = solve(q, st)
        J.append(j)
        if fi in key_idx:
            warns += ["key%d %s" % (key_idx.index(fi), x) for x in w]
    J = np.array(J)
    EX[id] = dict(id=id, keys=keys, props=list(props), views=list(views), hold=hold, loop=loop,
                  durs=durs, rdurs=rdurs, frames=J, poses=poses, key_idx=key_idx, warns=warns, steps=steps,
                  miny=float(J[:, [JI["toR"], JI["toL"], JI["haR"], JI["haL"], JI["anR"], JI["anL"]], 1].min()))

"""Contact-sheet preview of the baked demonstrations (orthographic, onion-skin of key poses).
python3 tools3d/preview.py [ids...]  -> tools3d/out/*.png"""
import math, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rig import JI, solve, NJ

BONES = [("pelvis", "spine"), ("spine", "chest"), ("chest", "head"),
         ("chest", "shR"), ("shR", "elR"), ("elR", "wrR"), ("wrR", "haR"),
         ("chest", "shL"), ("shL", "elL"), ("elL", "wrL"), ("wrL", "haL"),
         ("pelvis", "hipR"), ("hipR", "knR"), ("knR", "anR"), ("anR", "toR"),
         ("pelvis", "hipL"), ("hipL", "knL"), ("knL", "anL"), ("anL", "toL")]


def cam_basis(az, el):
    a, e = math.radians(az), math.radians(el)
    pos = np.array([math.cos(e) * math.cos(a), math.sin(e), math.cos(e) * math.sin(a)])
    fwd = -pos
    right = np.cross(fwd, [0, 1, 0]); right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    return right, up, pos


def project(J, az, el):
    r, u, pos = cam_basis(az, el)
    return np.stack([J @ r, J @ u], 1), J @ pos


def draw_pose(ax, J, az, el, col, alpha=1.0, lw=3.0):
    xy, d = project(J, az, el)
    for a, b in BONES:
        i, j = JI[a], JI[b]
        # near limbs darker: right side is +z
        ax.plot([xy[i, 0], xy[j, 0]], [xy[i, 1], xy[j, 1]], color=col, alpha=alpha, lw=lw, solid_capstyle="round")
    h = xy[JI["head"]]
    ax.add_patch(plt.Circle(h, 0.10, color=col, alpha=alpha))


def draw_props(ax, props, az, el):
    r, u, pos = cam_basis(az, el)
    pr = lambda p: (np.dot(p, r), np.dot(p, u))
    for p in props:
        k = p[0]; a = p[1:]
        if k == 1:   # bar x y halfw
            A = pr(np.array([a[0], a[1], -a[2]])); B = pr(np.array([a[0], a[1], a[2]]))
            ax.plot([A[0], B[0]], [A[1], B[1]], color="#b45309", lw=3)
        elif k == 2:  # wall x
            for z in (-0.8, 0.8):
                A = pr(np.array([a[0], 0, z])); B = pr(np.array([a[0], 2.3, z]))
                ax.plot([A[0], B[0]], [A[1], B[1]], color="#94a3b8", lw=1)
            A = pr(np.array([a[0], 0, -0.8])); B = pr(np.array([a[0], 0, 0.8])); ax.plot([A[0], B[0]], [A[1], B[1]], color="#94a3b8", lw=1)
        elif k == 3:  # box x0 y0 z0 x1 y1 z1
            x0, y0, z0, x1, y1, z1 = a
            pts = [np.array([x, y, z]) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
            for i in range(8):
                for j in range(i + 1, 8):
                    if sum(abs(pts[i][c] - pts[j][c]) > 1e-9 for c in range(3)) == 1:
                        A, B = pr(pts[i]), pr(pts[j]); ax.plot([A[0], B[0]], [A[1], B[1]], color="#64748b", lw=1.2)
        elif k == 4:  # rings x yring ytop halfspacing
            for z in (-a[3], a[3]):
                A = pr(np.array([a[0], a[1], z])); B = pr(np.array([a[0], a[2], z]))
                ax.plot([A[0], B[0]], [A[1], B[1]], color="#b45309", lw=1)
                ax.add_patch(plt.Circle(A, 0.045, fill=False, color="#b45309", lw=2))
        elif k == 5:  # pole x z height
            A = pr(np.array([a[0], 0, a[1]])); B = pr(np.array([a[0], a[2], a[1]]))
            ax.plot([A[0], B[0]], [A[1], B[1]], color="#b45309", lw=4)
        elif k == 9:  # rings following the hands (drawn in draw_pose)
            pass
        elif k == 6:  # parallel bars x0 x1 y halfspacing
            for z in (-a[3], a[3]):
                A = pr(np.array([a[0], a[2], z])); B = pr(np.array([a[1], a[2], z]))
                ax.plot([A[0], B[0]], [A[1], B[1]], color="#b45309", lw=3)


def sheet(items, fname, cols=4):
    rows = math.ceil(len(items) / cols)
    fig, axs = plt.subplots(rows, cols, figsize=(cols * 3.4, rows * 3.4))
    axs = np.atleast_1d(axs).ravel()
    for ax in axs:
        ax.axis("off")
    for ax, it in zip(axs, items):
        ex, az, el, label = it
        fr = ex["frames"]
        allp = fr.reshape(-1, 3)
        c = (allp.max(0) + allp.min(0)) / 2
        ext = np.abs(allp - c).max() * 1.15 + 0.1
        r, u, _ = cam_basis(az, el)
        ax.set_xlim(np.dot(c, r) - ext, np.dot(c, r) + ext)
        ax.set_ylim(np.dot(c, u) - ext, np.dot(c, u) + ext)
        ax.set_aspect("equal")
        ax.axhline(0, color="#cbd5e1", lw=0) 
        # floor line in this view
        fl = [np.array([-2, 0, 0]), np.array([2, 0, 0]), np.array([0, 0, -2]), np.array([0, 0, 2])]
        draw_props(ax, ex["props"], az, el)
        ki = ex["key_idx"]
        n = len(ki)
        cols_ = plt.cm.viridis(np.linspace(0.05, 0.85, n))
        for i, k in enumerate(ki):
            draw_pose(ax, fr[k], az, el, cols_[i], alpha=0.35 + 0.65 * (i == 0 or i == n - 1), lw=2.2 if 0 < i < n - 1 else 3.2)
        # floor plane projected: draw ground line
        g0, g1 = project(np.array([[-3, 0, 0], [3, 0, 0]]), az, el)[0], None
        ax.plot(g0[:, 0], g0[:, 1], color="#94a3b8", lw=1)
        ax.set_title("%s  [%s]" % (ex["id"], label), fontsize=8)
    plt.tight_layout()
    os.makedirs(os.path.dirname(fname), exist_ok=True)
    plt.savefig(fname, dpi=70)
    plt.close(fig)

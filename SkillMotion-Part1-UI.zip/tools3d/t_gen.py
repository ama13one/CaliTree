import sys, importlib; sys.path.insert(0,'.')
import motion, preview
mods=sys.argv[2].split(",")
for m in mods: importlib.import_module(m)
prefix=sys.argv[1]
ids=[i for i in motion.EX if i.startswith(tuple(prefix.split(",")))]
for i in ids:
    e=motion.EX[i]
    if e["warns"] or e["miny"]<-0.03: print(i,e["warns"],"miny=%.3f"%e["miny"])
items=[]
for i in ids:
    e=motion.EX[i]; v=e["views"][0]; items.append((e,v[1],v[2],v[0]))
n=int(sys.argv[3]) if len(sys.argv)>3 else 12
for k in range(0,len(items),n):
    preview.sheet(items[k:k+n],"out/%s_%d.png"%(sys.argv[1].split(",")[0],k//n),cols=4)
print(len(ids),"exercises")

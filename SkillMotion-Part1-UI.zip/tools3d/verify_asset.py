"""Parses demo3d.bin exactly like Demo3D.kt does and checks it against the registered motions.
python3 tools3d/verify_asset.py [other.bin]   -> compares structure with a second file (e.g. the previous release)"""
import os, struct, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import motion, audit
from skills_dump import load

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def parse(path):
    b = open(path, "rb").read(); o = 0
    def rd(f):
        nonlocal o
        n = struct.calcsize(f); v = struct.unpack_from(f, b, o); o += n; return v
    magic, n = rd(">ii"); assert magic == 0x44334431, "bad magic"
    out = {}
    for _ in range(n):
        (ln,) = rd(">H"); name = b[o:o + ln].decode(); o += ln
        (flags,) = rd(">B"); c = rd(">ffff"); (npr,) = rd(">B")
        props = [rd(">B6f") for _ in range(npr)]
        (nv,) = rd(">B"); views = []
        for _ in range(nv):
            (l2,) = rd(">H"); views.append(b[o:o + l2].decode()); o += l2; rd(">ff")
        (nk,) = rd(">B"); keys = [rd(">H")[0] for _ in range(nk)]
        durs = [rd(">f")[0] for _ in range(nk - 1)]; rdurs = [rd(">f")[0] for _ in range(nk - 1)]
        (nf,) = rd(">H"); fr = np.frombuffer(b, ">i2", nf * 20 * 3, o).reshape(nf, 20, 3) / 1000.0; o += nf * 20 * 3 * 2
        out[name] = dict(flags=flags, props=props, views=views, keys=keys, durs=durs, rdurs=rdurs, frames=fr)
    assert o == len(b), "trailing bytes: %d" % (len(b) - o)
    return out


if __name__ == "__main__":
    audit.load_all()
    new = parse(os.path.join(ROOT, "app/src/main/assets/demo3d.bin"))
    ids = [s["id"] for s in load()]
    assert set(new) == set(ids), "exercise id mismatch"
    for i in ids:
        e = motion.EX[i]; p = new[i]
        assert p["keys"] == e["key_idx"] and len(p["frames"]) == len(e["frames"]), i
        assert np.abs(p["frames"] - e["frames"]).max() < 0.0006, i
        assert not np.isnan(p["frames"]).any() and np.abs(p["frames"]).max() < 4.5, i
        assert p["keys"][-1] == len(p["frames"]) - 1, i
    print("OK: %d exercises parsed, frames match the registered motions (mm quantisation)" % len(ids))
    if len(sys.argv) > 1:
        old = parse(sys.argv[1])
        assert set(old) == set(new)
        for i in ids:
            for k in ("flags", "props", "views", "keys", "durs", "rdurs"):
                assert old[i][k] == new[i][k], (i, k)
        print("OK: identical structure to", sys.argv[1], "(ids, flags, props, cameras, key frames, durations); only the frames changed")

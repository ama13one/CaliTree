from h import *

AH = ANKLE_H
SQ_V = [("Side", 90, 8), ("3/4 front", 40, 14), ("Front", 0, 8)]


def squat_pose(px, py, ta, stance=0.17, arms=(0.50, 0.0), foot_out=0, neck=0.0, flex=0.0, ax=0.0):
    q = P(p=V(px, py, 0), ta=ta, neck=neck, flex=flex, kr=V(1, 0, 0.35), kl=V(1, 0, 0.35))
    stand_on(q, ax, AH, stance, -stance)
    if arms is not None:
        reach_arms(q, off=(arms[0], arms[1], 0), z=0.15, er=(0, -1, 0.2))
    return q


# ---- bodyweight squat: feet shoulder width, sit back, heels flat, chest up
st = squat_pose(0, HIP_Y, 90, arms=(0.0, -0.45))
reach_arms(st, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
bt = squat_pose(-0.30, 0.36, 52, arms=(0.52, 0.02))
reg("legs_squat", [st, bt], [], SQ_V, durs=[1.8], rdurs=[1.6])

# ---- jump squat (loop): squat -> explode -> land into the next squat
air = squat_pose(0, HIP_Y + 0.42, 90, stance=0.10, arms=None)
air.update(fr=V(0, AH + 0.42 + 0.0, 0.10), fl=V(0, AH + 0.42, -0.10), pfr=55, pfl=55, flr=0, fll=0)
reach_arms(air, off=(0.08, 0.50, 0), z=0.22, er=(-1, 0, 0.5))
sqj = squat_pose(-0.26, 0.46, 62, arms=None)
sqj["hr"] = V(-0.45, 0.62, 0.24); sqj["hl"] = V(-0.45, 0.62, -0.24)       # arms swung back
sqj["er"] = sqj["el"] = V(-1, 0.3, 0.4)
land = squat_pose(-0.22, 0.52, 66, arms=None)
land["hr"] = V(0.15, 0.80, 0.24); land["hl"] = V(0.15, 0.80, -0.24)
reg("legs_jump", [sqj, air, land, sqj], [], SQ_V, loop=True, durs=[0.35, 0.45, 0.35])

# ---- calf raise on a step (heels hanging off the back edge)
def calf(pf, ay, one=False):
    q = P(p=V(0.08, ay + LEG * 0.999, 0), ta=90, kr=V(1, 0, 0.1), kl=V(1, 0, 0.1))
    q.update(fr=V(0.08, ay, 0.10), fl=V(0.08, ay, -0.10), pfr=pf, pfl=pf, flr=0, fll=0)
    reach_arms(q, off=(0.02, -0.52, 0), z=0.25, er=(-1, -0.2, 0.5))
    return q
def calf_keys(one=False):
    low = calf(-10, 0.15 + 0.17)
    high = calf(55, 0.15 + 0.24 * math.sin(math.radians(55)) + 0.0)
    if one:
        for q in (low, high):
            q["fl"] = q["fr"] + V(0, 0.10, -0.20)
            q["fr"] = q["fr"] + V(0, 0, -0.10)
            q["pfl"] = 65.0; q["fll"] = 0.0
            q["kl"] = V(-1, 0.2, 0.1)
            S = shoulder_of(q)
            q["hr"] = S + V(0.40, -0.18, 0.19); q["er"] = V(-1, -0.3, 0.5)    # fingertips on the wall
    return low, high
lo, hi = calf_keys()
step = box(-0.05, 0, -0.45, 0.75, 0.15, 0.45)
reg("legs_calf", [lo, hi], [step], [SIDE_V, REAR_V], hold=True, durs=[1.5], rdurs=[2.2])
lo, hi = calf_keys(True)
reg("legs_calf_single", [lo, hi], [step, wall(0.55)], [SIDE_V, REAR_V], hold=True, durs=[1.5], rdurs=[2.2])

# ---- glute bridge (lying, head toward -x, shoulder blades on the floor)
def bridge(alpha, one=False, shx=0.0):
    a = math.radians(alpha)
    S = V(shx, 0.11, 0)
    p = S + TORSO * V(math.cos(a), math.sin(a), 0) if alpha > 0.5 else V(shx + TORSO, 0.11, 0)
    ta = 180 + alpha
    q = P(p=p, ta=ta, kr=V(0, 1, 0.1), kl=V(0, 1, 0.1), neck=-4)
    q["hr"] = V(shx + 0.55, 0.045, 0.26); q["hl"] = V(shx + 0.55, 0.045, -0.26)
    q["hwr"] = q["hwl"] = 1.0
    q["er"] = q["el"] = V(0, 1, 0.5)
    fx = shx + 0.86
    q.update(fr=V(fx, AH, 0.12), fl=V(fx, AH, -0.12), flr=1, fll=1)
    if one:
        # free (left) leg: straight, continuing the line shoulder-hip-knee
        d = V(math.cos(a), math.sin(a), 0)
        q["fl"] = p + V(0, 0, -0.09) + LEG * 0.998 * d
        q["fll"] = 0.0; q["pfl"] = 30.0
        q["kl"] = V(0, 1, 0)
    return q
reg("legs_bridge", [bridge(0.0), bridge(24)], [], [SIDE_V, ("3/4 front", 40, 22), TOP], hold=True, durs=[1.5], rdurs=[2.0])
reg("legs_bridge_single", [bridge(0.0, True), bridge(24, True)], [], [SIDE_V, ("3/4 front", 40, 22), FRONT_V], hold=True, durs=[1.5], rdurs=[2.0])

# ---- reverse lunge (right leg forward)
lun0 = stand(0.0)
reach_arms(lun0, off=(0, 0, 0), z=0.0)
for q in (lun0,):
    q["hr"] = V(0.0, 0.98, 0.24); q["hl"] = V(0.0, 0.98, -0.24)    # hands on hips
    q["er"] = q["el"] = V(-0.3, 0.2, 1.0)
lun1 = P(p=V(-0.34, 0.50, 0), ta=88, kr=V(1, 0, 0.1), kl=V(0, -1, 0.1),
         hr=V(-0.34, 0.97, 0.24), hl=V(-0.34, 0.97, -0.24), er=V(-0.3, 0.2, 1.0), el=V(-0.3, 0.2, 1.0))
lun1.update(fr=V(0.0, AH, 0.10), flr=1, fl=V(-0.92, 0.25, -0.10), pfl=50, fll=0, fvl=V(0, -1, 0))
fit_toes(lun1, 0.02, "l")
reg("legs_lunge", [lun0, lun1], [], SQ_V, durs=[1.8], rdurs=[1.6])

# ---- Bulgarian split squat: back foot on a 45 cm bench
bench = box(-0.95, 0, -0.25, -0.50, 0.45, 0.25)
def bulg(py, px, ta):
    q = P(p=V(px, py, 0), ta=ta, kr=V(1, 0, 0.1), kl=V(0, -1, 0.1))
    q.update(fr=V(0.25, AH, 0.12), flr=1, fl=V(-0.60, 0.45 + 0.07, -0.12), pfl=55, fll=0, fvl=V(0, -1, 0))
    fit_toes(q, 0.45, "l")
    q["hr"] = V(px, py + 0.52, 0.24); q["hl"] = V(px, py + 0.52, -0.24)
    q["er"] = q["el"] = V(-0.3, 0.2, 1.0)
    return q
reg("legs_bulgarian", [bulg(0.86, 0.12, 88), bulg(0.50, -0.12, 82)], [bench], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[1.9], rdurs=[1.7])

# ---- single-leg squat family (pistol): right leg works, left leg held out in front
def pistol(px, py, ta, arms=(0.5, 0.0), free_h=0.0, hold=None, box_top=None):
    q = P(p=V(px, py, 0), ta=ta, kr=V(1, 0, 0.1), kl=V(0, 1, 0.0))
    q.update(fr=V(0.0, AH, 0.04), flr=1)
    q["fl"] = V(px + LEG * 0.998, py + free_h, -0.07)
    q["fll"] = 0.0; q["pfl"] = 20.0
    reach_arms(q, off=(arms[0], arms[1], 0), z=0.14, er=(0, -1, 0.2))
    return q
pst = pistol(0.0, HIP_Y, 90, arms=(0.05, -0.50))
reach_arms(pst, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
pst["fl"] = V(0.45, 0.55, -0.07)                       # free leg lifted in front
pbot = pistol(-0.34, 0.27, 40, arms=(0.52, 0.0), free_h=0.0)
pbot["fl"] = V(-0.34 + 0.80, 0.29, -0.07)
reg("legs_pistol", [pst, pbot], [], [SIDE_V, FRONT_V, ("3/4 front", 40, 14)], durs=[2.4], rdurs=[2.0])

# box pistol: sit back onto a 45 cm box, free leg extended
bx = box(-0.80, 0, -0.30, -0.28, 0.45, 0.30)
bp = pistol(-0.34, 0.50, 55, arms=(0.52, 0.0), free_h=0.0)
bp["fl"] = V(-0.34 + 0.80, 0.52, -0.07)
reg("legs_box_pistol", [pst, bp], [bx], [SIDE_V, FRONT_V, ("3/4 front", 40, 14)], durs=[2.2], rdurs=[2.0])

# assisted pistol: both hands hold a post at chest height, leaning back slightly
post = pole(0.36, 0.0, 2.2)
def pa(px, py, ta):
    q = pistol(px, py, ta, arms=(0.0, 0.0))
    q["hr"] = V(0.33, 1.02, 0.05); q["hl"] = V(0.33, 1.02, -0.05)
    q["er"] = q["el"] = V(-0.2, -1, 0.4)
    q["hwr"] = q["hwl"] = 0.0
    return q
pa0 = pa(0.0, HIP_Y, 88)
pa0["fl"] = V(0.45, 0.60, -0.07)
pa1 = pa(-0.34, 0.27, 72)
pa1["fl"] = V(-0.34 + 0.80, 0.30, -0.07)
reg("legs_pistol_assist", [pa0, pa1], [post], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[2.4], rdurs=[2.0])

# ---- shrimp squat: free foot held behind with the same-side hand, rear knee lowers to the floor
def shrimp(px, py, ta, ankle, fwd_arm=True):
    q = P(p=V(px, py, 0), ta=ta, kr=V(1, 0, 0.1), kl=V(0, -1, 0.0))
    q.update(fr=V(0.0, AH, 0.04), flr=1)
    q["fl"] = V(*ankle); q["fll"] = 0.0; q["pfl"] = 45.0; q["fvl"] = V(0, -1, 0)
    q["hl"] = V(*ankle) + V(-0.03, 0.04, 0)           # left hand holds the left foot
    q["hr"] = V(px + 0.45, py + 0.35, 0.20)            # right arm forward for balance
    q["er"] = V(0, -1, 0.2); q["el"] = V(-1, 0.2, 0.6)
    return q
sh0 = shrimp(0.0, HIP_Y, 90, (-0.22, 0.86, -0.09))
sh1 = shrimp(-0.20, 0.34, 72, (-0.40, 0.40, -0.09))
reg("legs_shrimp", [sh0, sh1], [], [SIDE_V, ("3/4 rear", 130, 14), FRONT_V], durs=[2.4], rdurs=[2.0])
sa0 = shrimp(0.0, HIP_Y, 90, (-0.22, 0.86, -0.09))
sa1 = shrimp(-0.18, 0.36, 72, (-0.36, 0.44, -0.09))
reg("legs_shrimp_assist", [sa0, sa1], [box(-0.55, 0, -0.2, -0.25, 0.06, 0.2)], [SIDE_V, ("3/4 rear", 130, 14), FRONT_V], durs=[2.4], rdurs=[2.0])

# ---- dragon squat: free leg crosses behind the standing leg and sweeps back while the torso leans forward
def dragon(px, py, ta, ank, lean):
    q = P(p=V(px, py, 0), ta=ta, kr=V(1, 0, 0.1), kl=V(1, -0.5, -0.3))
    q.update(fr=V(0.0, AH, 0.05), flr=1)
    q["fl"] = V(*ank); q["fll"] = 0.0; q["pfl"] = 40.0
    reach_arms(q, off=lean, z=0.16, er=(0, -1, 0.2))
    return q
dr0 = dragon(0.0, HIP_Y, 90, (-0.10, 0.28, 0.14), (0.25, -0.3, 0))
dr0["fl"] = V(-0.12, 0.30, 0.10)
dr1 = dragon(-0.28, 0.38, 55, (-0.78, 0.22, 0.20), (0.50, -0.05, 0))
reg("legs_dragon", [dr0, dr1], [], [("3/4 rear", 140, 14), SIDE_V, REAR_V], durs=[2.6], rdurs=[2.2])

# ---- nordic curl: knees fixed on a pad, feet anchored, body falls forward as one straight line
def nordic(th, hands):
    K = V(0.0, 0.06, 0)
    d = V(math.cos(math.radians(th)), math.sin(math.radians(th)), 0)
    q = P(p=K + THIGH * d, ta=th, kr=V(0, -1, 0.1), kl=V(0, -1, 0.1))
    q.update(fr=K + V(-0.40, 0.03, 0.10), fl=K + V(-0.40, 0.03, -0.10), pfr=75, pfl=75, flr=0, fll=0, fvr=V(0, -1, 0), fvl=V(0, -1, 0))
    S = shoulder_of(q)
    if hands == "chest":
        q["hr"] = S + V(0.30, -0.12, 0.12); q["hl"] = S + V(0.30, -0.12, -0.12)
        q["er"] = q["el"] = V(-0.2, -1, 0.6)
    else:
        q["hr"] = V(S[0] + 0.14, 0.04, 0.24); q["hl"] = V(S[0] + 0.14, 0.04, -0.24)
        q["hwr"] = q["hwl"] = 1.0; q["er"] = q["el"] = V(-1, 0.3, 0.5)
    return q
n0, n1, n2 = nordic(88, "chest"), nordic(48, "chest"), nordic(11, "floor")
pad = box(-0.25, 0, -0.35, 0.30, 0.04, 0.35)
anchor = box(-0.62, 0, -0.30, -0.50, 0.30, 0.30)
reg("legs_nordic", [n0, n1, n2], [pad, anchor], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[2.0, 1.2], rdurs=[1.6, 1.4])
reg("legs_nordic_neg", [n0, n1, n2], [pad, anchor], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], durs=[3.0, 2.2], rdurs=[1.2, 1.2])

# ---- box jump (loop): crouch, jump, land on the box, stand tall, step down
BX = 0.50
boxp = box(0.35, 0, -0.45, 0.95, BX, 0.45)
cr = squat_pose(-0.26, 0.46, 62, arms=None)
cr["hr"] = V(-0.45, 0.62, 0.24); cr["hl"] = V(-0.45, 0.62, -0.24); cr["er"] = cr["el"] = V(-1, 0.3, 0.4)
cr.update(fr=V(-0.15, AH, 0.12), fl=V(-0.15, AH, -0.12))
cr["p"] = V(-0.38, 0.46, 0)
jair = P(p=V(0.20, 1.10, 0), ta=95, kr=V(1, 0.5, 0.2), kl=V(1, 0.5, 0.2))
jair.update(fr=V(0.30, 0.85, 0.12), fl=V(0.30, 0.85, -0.12), pfr=30, pfl=30, flr=0, fll=0)
reach_arms(jair, off=(0.45, 0.10, 0), z=0.2, er=(0, -1, 0.3))
land = squat_pose(0.52, BX + 0.46, 62, arms=None)
land.update(fr=V(0.68, BX + AH, 0.12), fl=V(0.68, BX + AH, -0.12))
land["p"] = V(0.52, BX + 0.50, 0)
land["hr"] = V(0.95, BX + 0.85, 0.24); land["hl"] = V(0.95, BX + 0.85, -0.24); land["er"] = land["el"] = V(-0.3, -1, 0.4)
topst = stand(0.68)
topst.update(fr=V(0.68, BX + AH, 0.10), fl=V(0.68, BX + AH, -0.10), p=V(0.68, BX + HIP_Y, 0))
reach_arms(topst, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
down = stand(0.68)
down.update(p=V(0.62, 0.86, 0), ta=88, fr=V(0.70, BX + AH, 0.10), fl=V(1.00, 0.19, -0.10), flr=1, fll=0, pfl=35, kr=V(1, 0, 0.1), kl=V(1, 0, 0.1))
reach_arms(down, off=(0.10, -0.45, 0), z=0.24, er=(-1, -0.2, 0.5))
st2 = stand(0.0)
reach_arms(st2, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
floor_end = stand(1.15)
reach_arms(floor_end, off=(0.05, -0.50, 0), z=0.24, er=(-1, -0.2, 0.5))
reg("legs_boxjump", [st2, cr, jair, land, topst, down, floor_end], [boxp], [SIDE_V, ("3/4 front", 40, 14), FRONT_V], loop=True,
    durs=[0.9, 0.45, 0.35, 0.5, 0.9, 0.9])
#print('lunge debug', [round(float(x),3) for x in solve(lun1)[0][JI['toL']]], [round(float(x),3) for x in solve(lun1)[0][JI['anL']]], lun1['pfl'])

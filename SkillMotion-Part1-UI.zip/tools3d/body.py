"""Body geometry shared by audit.py (measuring) and refine.py (correcting).
Capsule radii are exactly the ones Demo3D.kt draws, so 'no overlap here' = 'no overlap on the phone'."""
import itertools
import numpy as np
from rig import JI

# (joint a, joint b, radius)
SEG = {
    "pelvis": ("pelvis", "spine", 0.105), "abdomen": ("spine", "chest", 0.118), "neck": ("chest", "head", 0.045),
    "clavR": ("chest", "shR", 0.058), "clavL": ("chest", "shL", 0.058),
    "pelR": ("pelvis", "hipR", 0.078), "pelL": ("pelvis", "hipL", 0.078),
    "uaR": ("shR", "elR", 0.050), "faR": ("elR", "wrR", 0.040), "haR": ("wrR", "haR", 0.034),
    "uaL": ("shL", "elL", 0.050), "faL": ("elL", "wrL", 0.040), "haL": ("wrL", "haL", 0.034),
    "thR": ("hipR", "knR", 0.078), "shnR": ("knR", "anR", 0.058), "ftR": ("anR", "toR", 0.044),
    "thL": ("hipL", "knL", 0.078), "shnL": ("knL", "anL", 0.058), "ftL": ("anL", "toL", 0.044),
}
HEAD_R = 0.105
SEG_NAMES = list(SEG)

NEIGH = set()


def _nb(*names):
    for a, b in itertools.combinations(names, 2):
        NEIGH.add(frozenset((a, b)))


_nb("pelvis", "abdomen", "neck", "clavR", "clavL", "pelR", "pelL")
for _s in "RL":
    _nb("ua" + _s, "fa" + _s, "ha" + _s)
    _nb("th" + _s, "shn" + _s, "ft" + _s)
    _nb("clav" + _s, "ua" + _s)
    _nb("pel" + _s, "th" + _s)
    _nb("abdomen", "ua" + _s)          # the shoulder joint sits on the torso surface
    _nb("neck", "ua" + _s)
    _nb("pelvis", "th" + _s)
_nb("thR", "thL")                      # both thighs start at the pelvis
_nb("pelR", "thL")
_nb("pelL", "thR")
PAIRS = [(a, b) for a, b in itertools.combinations(SEG, 2) if frozenset((a, b)) not in NEIGH]

# soft-tissue allowance (m): thigh against belly in a pike / tuck, calf against thigh in deep flexion
ALLOW = {}
for _a, _b in PAIRS:
    pa = _a[:-1] if _a[-1] in "RL" else _a
    pb = _b[:-1] if _b[-1] in "RL" else _b
    k = 0.0
    if {pa, pb} & {"th", "pel"} and {pa, pb} & {"abdomen", "pelvis"}:
        k = 0.02
    if {pa, pb} == {"th", "shn"} or pa == pb == "shn":
        k = 0.015
    ALLOW[(_a, _b)] = k
HEAD_ALLOW = 0.02
HEAD_PAIRS = [k for k in SEG if k not in ("neck", "clavR", "clavL", "abdomen", "pelvis", "pelR", "pelL")]

# ---- vectorised single-frame tables
_JA = np.array([JI[SEG[k][0]] for k in SEG_NAMES]); _JB = np.array([JI[SEG[k][1]] for k in SEG_NAMES])
_R = np.array([SEG[k][2] for k in SEG_NAMES])
_IX = {k: i for i, k in enumerate(SEG_NAMES)}
_PA = np.array([_IX[a] for a, b in PAIRS]); _PB = np.array([_IX[b] for a, b in PAIRS])
_PALLOW = np.array([ALLOW[p] for p in PAIRS])
_PRAD = _R[_PA] + _R[_PB]
_HP = np.array([_IX[k] for k in HEAD_PAIRS])


def seg_dist(p0, p1, q0, q1):
    """Minimum distance between segments p0p1 and q0q1; arrays (...,3)."""
    d1, d2, r = p1 - p0, q1 - q0, p0 - q0
    a = (d1 * d1).sum(-1); e = (d2 * d2).sum(-1); f = (d2 * r).sum(-1)
    c = (d1 * r).sum(-1); b = (d1 * d2).sum(-1)
    den = a * e - b * b
    s = np.where(den > 1e-12, np.clip((b * f - c * e) / np.where(den > 1e-12, den, 1), 0, 1), 0.0)
    t = (b * s + f) / np.where(e > 1e-12, e, 1)
    t_c = np.clip(t, 0, 1)
    s = np.clip((b * t_c - c) / np.where(a > 1e-12, a, 1), 0, 1)
    cp, cq = p0 + d1 * s[..., None], q0 + d2 * t_c[..., None]
    return np.linalg.norm(cp - cq, axis=-1)


def interior(a, b, c):
    """Interior angle at b (deg) for points a-b-c; arrays (N,3)."""
    u, v = a - b, c - b
    cs = (u * v).sum(-1) / (np.linalg.norm(u, axis=-1) * np.linalg.norm(v, axis=-1) + 1e-9)
    return np.degrees(np.arccos(np.clip(cs, -1, 1)))


def penetrations(J):
    """Overlap (m, soft-tissue allowance already removed, may be negative) of every PAIRS entry for one
    frame J[20,3], followed by the head-ball overlaps."""
    P0, P1 = J[_JA], J[_JB]
    d = seg_dist(P0[_PA], P1[_PA], P0[_PB], P1[_PB])
    pen = _PRAD - d - _PALLOW
    h = J[JI["head"]]
    dh = seg_dist(P0[_HP], P1[_HP], h[None], h[None])
    penh = _R[_HP] + HEAD_R - dh - HEAD_ALLOW
    return np.concatenate([pen, penh])


_FA = np.concatenate([_JA, _JB, [JI["head"]]])
_FR = np.concatenate([_R, _R, [HEAD_R]])


def floor_pen(J):
    """Depth (m) every capsule end sinks below the floor (y=0). Positive = below."""
    return _FR - J[_FA, 1]

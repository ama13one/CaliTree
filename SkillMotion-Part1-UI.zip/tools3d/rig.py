"""3D skeleton + IK engine for the CaliTree exercise demonstrations.

World axes: +x = the way the athlete faces, +y = up, +z = the athlete's RIGHT side (when standing).
Units: metres. Floor is y = 0.

A *pose* is a handful of numbers (pelvis position, torso direction, spine flexion, hand and foot
targets ...). `solve(pose)` turns it into 20 joint positions with analytic 2-bone IK for arms and
legs. Everything the app draws is produced by this file (positions are baked, see build3d.py),
so what you see in tools3d/preview.py is exactly what the phone renders.
"""
import math
import numpy as np

# ---- body dimensions (a 1.77 m athlete) ----
THIGH, SHIN, FOOT, ANKLE_H = 0.41, 0.40, 0.24, 0.08
TOE_R = 0.044                  # radius of the shoe capsule drawn by Demo3D.kt
LUM, THOR, NECKH = 0.22, 0.31, 0.24
SH_HALF, HIP_HALF = 0.19, 0.095
UA, FA, HAND = 0.30, 0.27, 0.09
LEG = THIGH + SHIN
ARM = UA + FA
TORSO = LUM + THOR
HIP_Y = ANKLE_H + LEG          # standing hip height
SH_Y = HIP_Y + TORSO           # standing shoulder height

JN = ["pelvis", "spine", "chest", "head",
      "shR", "elR", "wrR", "haR", "shL", "elL", "wrL", "haL",
      "hipR", "knR", "anR", "toR", "hipL", "knL", "anL", "toL"]
JI = {n: i for i, n in enumerate(JN)}
NJ = len(JN)


def V(*a):
    return np.array(a, float)


def nrm(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-9 else v


def rot(v, axis, deg):
    a = nrm(axis)
    t = math.radians(deg)
    c, s = math.cos(t), math.sin(t)
    return v * c + np.cross(a, v) * s + a * np.dot(a, v) * (1 - c)


Y = V(0, 1, 0)
DEFAULT = dict(
    p=V(0, HIP_Y, 0), ta=90.0, roll=0.0, yaw=0.0, flex=0.0, neck=0.0, shup=0.0, shfw=0.0,
    hr=V(0, SH_Y - ARM, SH_HALF + 0.07), hl=V(0, SH_Y - ARM, -SH_HALF - 0.07),
    fr=V(0, ANKLE_H, 0.10), fl=V(0, ANKLE_H, -0.10),
    er=V(-1, -0.2, 0.6), el=V(-1, -0.2, 0.6),          # elbow pole (world, z = outward)
    kr=V(1, 0, 0.12), kl=V(1, 0, 0.12),                # knee pole (world, z = outward)
    pfr=0.0, pfl=0.0, flr=0.0, fll=0.0,                # plantar-flexion deg, flat-foot weight
    hdr=V(1, 0, 0), hdl=V(1, 0, 0), hwr=0.0, hwl=0.0,   # hand direction + weight
    lean=0.0,                                           # lateral tilt of the whole trunk (deg, + = toward right)
    fvr=V(0, 0, 0), fvl=V(0, 0, 0),                     # optional 'front of the shin' direction (0 = automatic)
    swer=0.0, swel=0.0, swkr=0.0, swkl=0.0)             # swivel (deg) of elbow / knee bend about the limb axis (set by refine.py)


def P(**kw):
    q = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in DEFAULT.items()}
    for k, v in kw.items():
        if k not in q:
            raise KeyError(k)
        q[k] = np.array(v, float) if isinstance(DEFAULT[k], np.ndarray) else float(v)
    return q


def lerp_pose(a, b, t):
    o = {}
    for k in a:
        o[k] = a[k] + (b[k] - a[k]) * t
    return o


def frame(ta, roll, yaw, lean=0.0):
    t = math.radians(ta)
    u = V(math.cos(t), math.sin(t), 0)
    f = V(math.sin(t), -math.cos(t), 0)
    f = rot(f, u, roll)
    if lean:
        u = rot(u, f, lean)
    u = rot(u, Y, yaw)
    f = rot(f, Y, yaw)
    r = np.cross(f, u)
    return nrm(u), nrm(f), nrm(r)


def limb(A, T, l1, l2, pole, swivel=0.0, prev=None):
    """Analytic two-bone IK. `prev` = bend direction of the previous frame: when the pole is (nearly) parallel
    to the limb its projection vanishes and would snap to an arbitrary side, so the bend direction is blended
    towards the previous frame's instead. Returns (mid joint, end joint, reach error, bend direction)."""
    d0 = T - A
    dist = np.linalg.norm(d0)
    u = d0 / dist if dist > 1e-9 else V(0, -1, 0)
    d = min(dist, l1 + l2 - 1e-4)
    d = max(d, abs(l1 - l2) + 1e-4)
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, l1 * l1 - a * a))
    pp = pole - np.dot(pole, u) * u
    n = np.linalg.norm(pp)
    pv = None
    if prev is not None:
        pv = prev - np.dot(prev, u) * u
        if np.linalg.norm(pv) < 1e-3:
            pv = None
        else:
            pv = pv / np.linalg.norm(pv)
    if n < 0.12 and pv is not None:
        w = n / 0.12
        pp = (pp / n * w if n > 1e-9 else 0 * pp) + pv * (1 - w)
        if np.linalg.norm(pp) < 1e-6:
            pp = pv
    elif n < 1e-6:
        pp = np.cross(u, V(0, 0, 1))
        if np.linalg.norm(pp) < 1e-6:
            pp = np.cross(u, V(1, 0, 0))
    pp = nrm(pp)
    if swivel:
        pp = rot(pp, u, swivel)
    return A + a * u + h * pp, A + d * u, dist - (l1 + l2), pp


FOOT_RATE = 18.0        # max change (deg / frame) of the foot's heading about the shin
KNEE_RATE = 12.0        # max swivel change of the knee-facing direction (deg / frame)
KNEE_PHI_MAX = 55.0     # knee hinge may deviate this far (deg) from the pelvis' lateral axis (hip rotation range)


def knee_pole(pole, hip, target, r, st=None, key="", down=None, fwd=None):
    """Anatomical knee pole. The author's pole is kept whenever the resulting knee hinge stays within
    KNEE_PHI_MAX of the pelvis' lateral axis; otherwise (or when the pole is parallel to the leg and
    therefore meaningless) the nearest allowed bend direction is used. `st` carries the chosen side from
    frame to frame so the knee can never snap across."""
    l = nrm(target - hip)
    if down is not None:
        # the knee faces where the pelvis' forward direction ends up after the HIP FLEXION rotation (about the
        # lateral axis r) that carries the neutral leg (straight down) to the leg's direction. Abduction rotates
        # about the forward axis and leaves it unchanged. This stays continuous for straddled legs and for legs
        # folded onto the trunk, where cross(r, l) and "shortest rotation" forms both degenerate.
        alpha = math.degrees(math.atan2(float(np.dot(l, fwd)), float(np.dot(l, down))))
        b_nat = rot(fwd, r, alpha)
        b_nat = b_nat - np.dot(b_nat, l) * l
    else:
        b_nat = np.cross(r, l)
    if np.linalg.norm(b_nat) < 1e-6:
        return pole
    b_nat = nrm(b_nat)                      # anterior bend direction
    b_a = pole - np.dot(pole, l) * l
    if np.linalg.norm(b_a) < 0.06:
        return b_nat
    b_a = nrm(b_a)
    phi = math.degrees(math.atan2(np.dot(np.cross(b_nat, b_a), l), np.dot(b_nat, b_a)))
    prev = None if st is None else st.get(key)
    if abs(phi) <= KNEE_PHI_MAX:
        tgt = phi
    else:
        sgn = 1.0 if phi >= 0 else -1.0
        if prev is not None and abs(phi) > 130.0 and abs(prev) > 1e-6:
            sgn = 1.0 if prev > 0 else -1.0
        tgt = sgn * KNEE_PHI_MAX
    cur = tgt
    if prev is not None:
        # an authored pole that sweeps all the way round must not whip the knee: limit the swivel speed
        cur = prev + max(-KNEE_RATE, min(KNEE_RATE, tgt - prev))
    if st is not None:
        st[key] = cur
    if abs(cur - phi) < 1e-6:
        return b_a
    return rot(b_nat, l, cur)


def solve(q, st=None, info=None):
    """Returns (joints[NJ,3], warnings list). `st` (optional dict) keeps the knee-side memory between frames;
    `info` (optional dict) receives info['err'][limb] = how far the IK target is out of reach (m, > 0 = short)."""
    warn = []
    if info is not None:
        info["err"] = {}
    u, f, r = frame(q["ta"], q["roll"], q["yaw"], q["lean"])
    a = nrm(np.cross(u, f))
    ul, ut = rot(u, a, -q["flex"] / 2), rot(u, a, q["flex"] / 2)
    fp, ft = rot(f, a, -q["flex"] / 2), rot(f, a, q["flex"] / 2)
    Pp = q["p"]
    M = Pp + LUM * ul
    S = M + THOR * ut
    head = S + NECKH * rot(ut, a, q["neck"])
    off = ut * q["shup"] + ft * q["shfw"]
    sR, sL = S + r * SH_HALF + off, S - r * SH_HALF + off
    hR, hL = Pp + r * HIP_HALF, Pp - r * HIP_HALF
    flat = rot(nrm(V(1, -(ANKLE_H - TOE_R) / FOOT, 0)), Y, q["yaw"])      # sole flat on the floor
    J = np.zeros((NJ, 3))
    J[0], J[1], J[2], J[3] = Pp, M, S, head
    for side, sg in (("R", 1), ("L", -1)):
        k = side.lower()
        sh = sR if sg > 0 else sL
        hp = hR if sg > 0 else hL
        pole = q["e" + k] * V(1, 1, sg)
        el, wr, e, bpp = limb(sh, q["h" + k], UA, FA, pole, q["swe" + k], None if st is None else st.get("bA" + k))
        if st is not None:
            st["bA" + k] = bpp
        if info is not None:
            info["err"]["arm" + side] = e
        if e > 0.015:
            warn.append("arm%s short by %.3f" % (side, e))
        fdir = nrm(wr - el)
        hd = nrm(fdir * (1 - q["hw" + k]) + nrm(q["hd" + k]) * q["hw" + k])
        base = JI["sh" + side]
        J[base], J[base + 1], J[base + 2], J[base + 3] = sh, el, wr, wr + HAND * hd
        kpole = knee_pole(q["k" + k] * V(1, 1, sg), hp, q["f" + k], r, st, "k" + k, -u, fp)
        kn, an, e, bpp = limb(hp, q["f" + k], THIGH, SHIN, kpole, q["swk" + k], None if st is None else st.get("bK" + k))
        if st is not None:
            st["bK" + k] = bpp
        if info is not None:
            info["err"]["leg" + side] = e
        if e > 0.015:
            warn.append("leg%s short by %.3f" % (side, e))
        s = nrm(kn - an)
        fa = q["fv" + k]
        raw = fa if np.linalg.norm(fa) > 0 else fp
        raw = raw - np.dot(raw, s) * s
        rn = np.linalg.norm(raw)
        fperp = None
        if st is not None and ("fP" + k) in st:
            # parallel transport: carry last frame's foot direction along with the shin's rotation, so the foot
            # never flips when the shin sweeps past the pelvis' forward axis
            s0, f0 = st["sP" + k], st["fP" + k]
            ax = np.cross(s0, s)
            axn = np.linalg.norm(ax)
            f1 = f0
            if axn > 1e-8:
                f1 = rot(f0, ax / axn, math.degrees(math.atan2(axn, float(np.dot(s0, s)))))
            f1 = f1 - np.dot(f1, s) * s
            if np.linalg.norm(f1) > 1e-6:
                f1 = f1 / np.linalg.norm(f1)
                fperp = f1
                if rn >= 0.35:
                    # steer towards the authored rule, but never faster than FOOT_RATE deg per frame: a hard
                    # switch (shin sweeping past the pelvis' forward axis) would flip the foot by 180 deg
                    rh = raw / rn
                    ang = math.degrees(math.atan2(float(np.dot(np.cross(f1, rh), s)), float(np.dot(f1, rh))))
                    step = max(-FOOT_RATE, min(FOOT_RATE, ang))
                    fperp = nrm(rot(f1, s, step))
        if fperp is None:
            fperp = nrm(raw) if rn > 1e-9 else fp
        if st is not None:
            st["fP" + k] = fperp
            st["sP" + k] = s
        al = math.radians(q["pf" + k])
        auto = nrm(math.cos(al) * fperp + math.sin(al) * (-s))
        fd = nrm(auto * (1 - q["fl" + k]) + flat * q["fl" + k])
        base = JI["hip" + side]
        J[base], J[base + 1], J[base + 2], J[base + 3] = hp, kn, an, an + FOOT * fd
    return J, warn


# ---------------- authoring helpers ----------------
def sym(x, y, z):
    """Right and left points mirrored about z = 0."""
    return V(x, y, z), V(x, y, -z)


def line_pose(foot, ang, **kw):
    """Straight body (ankle-hip-shoulder collinear) rising from `foot` at `ang` deg above +x."""
    t = math.radians(ang)
    d = V(math.cos(t), math.sin(t), 0)
    hip = foot + LEG * d
    return P(p=hip, ta=ang, **kw)


def shoulder_of(q):
    J, _ = solve(q)
    return (J[JI["shR"]] + J[JI["shL"]]) / 2

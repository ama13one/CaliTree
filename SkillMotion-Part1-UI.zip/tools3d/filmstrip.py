"""Filmstrip of IN-BETWEEN frames (the contact sheets in preview.py only show key poses).
python3 tools3d/filmstrip.py out.png id1 id2 ...   (rows = exercises, columns = frames over one full move)"""
import math, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(__file__))
import motion, preview, audit
from rig import JI


def strip(ids, fname, ncol=9, view=None):
    audit.load_all()
    fig, axs = plt.subplots(len(ids), ncol, figsize=(ncol * 1.9, len(ids) * 2.1))
    axs = np.atleast_2d(axs)
    for r, id_ in enumerate(ids):
        e = motion.EX[id_]
        v = view or e["views"][0]
        az, el = v[1], v[2]
        fr = e["frames"]
        allp = fr.reshape(-1, 3)
        c = (allp.max(0) + allp.min(0)) / 2
        ext = np.abs(allp - c).max() * 1.1 + 0.1
        rr, uu, _ = preview.cam_basis(az, el)
        idx = np.linspace(0, len(fr) - 1, ncol).round().astype(int)
        for k, ax in zip(idx, axs[r]):
            ax.set_xlim(np.dot(c, rr) - ext, np.dot(c, rr) + ext)
            ax.set_ylim(np.dot(c, uu) - ext, np.dot(c, uu) + ext)
            ax.set_aspect("equal"); ax.axis("off")
            preview.draw_props(ax, e["props"], az, el)
            g = preview.project(np.array([[-3, 0, 0], [3, 0, 0]]), az, el)[0]
            ax.plot(g[:, 0], g[:, 1], color="#94a3b8", lw=1)
            preview.draw_pose(ax, fr[k], az, el, "#1d4ed8" if k in e["key_idx"] else "#334155", lw=2.6)
            ax.set_title(("K" if k in e["key_idx"] else "") + str(k), fontsize=6)
        axs[r][0].text(0.0, 1.0, id_, transform=axs[r][0].transAxes, fontsize=7, va="bottom")
    plt.tight_layout()
    os.makedirs(os.path.dirname(fname) or ".", exist_ok=True)
    plt.savefig(fname, dpi=75); plt.close(fig)

if __name__ == "__main__":
    strip(sys.argv[2:], sys.argv[1])

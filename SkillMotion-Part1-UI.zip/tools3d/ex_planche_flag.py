from h import *
from ex_pull import hp, legs_to, legs_tuck, BY, HANG_SY, PULL_PROPS
from ex_levers import legs_abs, tuck

PV = [("Side", 90, 8), ("3/4 front", 50, 16), ("Front", 0, 8)]

# ---------------- planche (hands on the floor, head toward +x, chest down) ----------------
def planche(kind, s, spread=0.0, Sy=None, ta=-2.0, lowered=False, flex=6.0, hz=0.24):
    Sy = 0.04 + math.sqrt((ARM * 0.985) ** 2 - s ** 2) if Sy is None else Sy
    q = pose_from_shoulder(V(s, Sy, 0), ta, neck=-18, flex=flex, shup=0.04, er=V(-1, 0.4, 0.3), el=V(-1, 0.4, 0.3))
    q.update(hr=V(0, 0.04, hz), hl=V(0, 0.04, -hz), hwr=1, hwl=1)
    if kind in ("tuck", "adv"):
        tuck(q, kind, V(0, -1, 0))
    elif kind == "one":
        tuck(q, "adv", V(0, -1, 0))
        t = q["p"] + LEG * 0.995 * V(-1, 0, 0)
        q["fr"] = t + V(0, 0, 0.07); q["pfr"] = 60.0; q["kr"] = V(0, -1, 0)
    elif kind == "straddle":
        legs_abs(q, "straddle", spread=spread, horiz_dir=(-1, 0))
    elif kind == "straight":
        legs_abs(q, "straight", horiz_dir=(-1, 0))
    return q

# lean: push-up body line, shoulders far past the hands
t0, _, _ = pushup_keys(hand_dx=-0.03, hz=0.24)
t1, _, _ = pushup_keys(hand_dx=-0.24, hz=0.24, flex=8.0)
reg("pl_lean", [t0, t1], [], PV, hold=True, durs=[1.8])

# frog stand: squat -> knees on the upper arms -> feet lift
def frog(lean):
    if not lean:
        p = V(-0.20, 0.34, 0)
        q = P(p=p, ta=25.0, neck=-20, hr=V(0.30, 0.04, 0.26), hl=V(0.30, 0.04, -0.26), hwr=1, hwl=1,
              er=V(-0.4, 0.8, 0.9), el=V(-0.4, 0.8, 0.9), kr=V(1, 0, 0.9), kl=V(1, 0, 0.9))
        q.update(fr=V(-0.15, ANKLE_H, 0.24), fl=V(-0.15, ANKLE_H, -0.24), flr=1, fll=1)
        return q
    S = V(0.40, 0.50, 0)
    p = S + V(-0.50, 0.04, 0)
    q = P(p=p, ta=-4.0, neck=-22, flex=8.0, hr=V(0.28, 0.04, 0.26), hl=V(0.28, 0.04, -0.26), hwr=1, hwl=1,
          er=V(-0.5, 0.9, 0.9), el=V(-0.5, 0.9, 0.9), kr=V(0.6, -0.2, 1), kl=V(0.6, -0.2, 1))
    ank = p + V(-0.12, -0.08, 0)
    q.update(fr=ank + V(0, 0, 0.09), fl=ank + V(0, 0, -0.09), pfr=60, pfl=60, flr=0, fll=0)
    return q
reg("pl_frog", [frog(False), frog(True)], [], [SIDE_V, ("3/4 front", 50, 16), FRONT_V], hold=True, durs=[1.8])

# pseudo planche push-up: hands beside the hips, fingers back
def pseudo(S_y):
    Fy = 0.25
    th = th_for(Fy, S_y)
    d = V(math.cos(math.radians(th)), math.sin(math.radians(th)), 0)
    q = line_pose(V(0, Fy, 0), th, flex=6.0, er=V(-1, 0.2, 0.3), el=V(-1, 0.2, 0.3))
    S = shoulder_of(q)
    hx = S[0] - 0.46
    q.update(hr=V(hx, 0.04, 0.24), hl=V(hx, 0.04, -0.24), hwr=1, hwl=1, hdr=V(-1, 0, 0.5), hdl=V(-1, 0, -0.5),
             fr=V(0, Fy, 0.10), fl=V(0, Fy, -0.10))
    q["pfr"] = q["pfl"] = 0
    return fit_toes(q, 0.02)
reg("pl_pseudo", [pseudo(0.30), pseudo(0.20)], [], PV, durs=[1.8], rdurs=[1.6])

reg("pl_tuck", [t1, planche("tuck", 0.20, ta=-4)], [], PV, hold=True, durs=[1.8])
reg("pl_adv_tuck", [planche("tuck", 0.20, ta=-4), planche("adv", 0.25, ta=-3)], [], PV, hold=True, durs=[1.6])
reg("pl_tuck_pp", [planche("tuck", 0.20, ta=-4), planche("tuck", 0.22, Sy=0.24, ta=-22)], [], PV, durs=[1.8], rdurs=[1.8])
reg("pl_oneleg", [planche("adv", 0.25, ta=-3), planche("one", 0.28, ta=-2)], [], PV, hold=True, durs=[1.6])
reg("pl_straddle", [planche("one", 0.28, ta=-2), planche("straddle", 0.30, spread=40, ta=-1)], [], [SIDE_V, ("3/4 front", 50, 16), ("Top", 0, 78)], hold=True, durs=[1.6])
reg("pl_full", [planche("straddle", 0.30, spread=40, ta=-1), planche("straight", 0.34, ta=0)], [], PV, hold=True, durs=[1.8])
reg("pl_pp", [planche("straight", 0.34, ta=0), planche("straight", 0.26, Sy=0.26, ta=0)], [], PV, durs=[2.0], rdurs=[2.0])

# ---------------- flags (pole at x=0,z=0; body horizontal toward +z, chest toward +x) ----------------
POLE = pole(0.0, 0.0, 2.5)
FV = [("Front", 0, 6), ("3/4 front", 45, 12), ("Side", 90, 6)]
def flag(kind, Sy=1.62, Sz=0.55, spread=0.0, top_y=None):
    top_y = Sy + 0.34 if top_y is None else top_y
    q = P(p=V(0, Sy, Sz + TORSO), ta=180.0, yaw=-90.0, roll=90.0, neck=-6, shup=-0.04, er=V(0, 0, 1), el=V(0, 0, 1))
    S = V(0, Sy, Sz)
    q["hr"] = V(0.0, top_y, 0.03); q["hl"] = V(0.0, Sy - 0.22, 0.03)   # top hand pulls, bottom hand pushes
    q["er"] = V(1, 0.2, 0.0); q["el"] = V(0.2, -1, 0)
    q["hdr"] = V(0, 1, 0); q["hdl"] = V(0, -1, 0); q["hwr"] = q["hwl"] = 1.0
    p = q["p"]
    head = V(0, 0, -1); f = V(1, 0, 0)
    if kind == "straight":
        t = p + LEG * 0.995 * V(0, 0, 1)
        q.update(fr=t + V(0, 0.06, 0), fl=t + V(0, -0.06, 0), pfr=60, pfl=60, flr=0, fll=0, kr=f, kl=f)
    elif kind == "straddle":
        a = math.radians(spread)
        q["fr"] = p + LEG * 0.995 * V(0, math.sin(a), math.cos(a)); q["fl"] = p + LEG * 0.995 * V(0, -math.sin(a), math.cos(a))
        q.update(pfr=60, pfl=60, flr=0, fll=0, kr=f, kl=f)
    elif kind == "tuck":
        k = p + THIGH * (head * math.cos(math.radians(50)) + f * math.sin(math.radians(50)))
        ank = k + SHIN * 0.98 * (-head * 0.55 - f * 0.83)
        q.update(fr=ank + V(0, 0.06, 0), fl=ank + V(0, -0.06, 0), pfr=55, pfl=55, flr=0, fll=0, kr=f, kl=f)
    elif kind == "adv":
        k = p + THIGH * f
        ank = k + SHIN * 0.99 * (-head)
        q.update(fr=ank + V(0, 0.06, 0), fl=ank + V(0, -0.06, 0), pfr=55, pfl=55, flr=0, fll=0, kr=f, kl=f)
    return q
reg("fg_full", [flag("tuck"), flag("straight")], [POLE], FV, hold=True, durs=[2.0])
reg("fg_tuck", [flag("tuck", Sy=1.50, Sz=0.55), flag("tuck")], [POLE], FV, hold=True, durs=[1.6])
reg("fg_adv_tuck", [flag("tuck"), flag("adv")], [POLE], FV, hold=True, durs=[1.6])
reg("fg_straddle", [flag("adv"), flag("straddle", spread=40)], [POLE], FV, hold=True, durs=[1.6])

# clutch flag: body angled out toward the floor, feet still on the ground
def clutch():
    Sy, Sz = 1.30, 0.38
    foot_y = 0.12
    phi = math.degrees(math.asin((Sy - foot_y) / (LEG + TORSO)))
    u = V(0, math.sin(math.radians(phi)), -math.cos(math.radians(phi)))
    S = V(0.0, Sy, Sz)
    q = P(p=S - TORSO * u, ta=180.0 - phi, yaw=-90.0, roll=90.0, neck=-6, shup=-0.04)
    q["hr"] = V(0.0, Sy + 0.34, 0.03); q["hl"] = V(0.0, Sy - 0.22, 0.03)
    q["er"] = V(1, 0.2, 0); q["el"] = V(0.2, -1, 0); q["hdr"] = V(0, 1, 0); q["hdl"] = V(0, -1, 0); q["hwr"] = q["hwl"] = 1.0
    J, _ = solve(q)
    shR, shL = J[JI["shR"]], J[JI["shL"]]
    q["hr"] = V(0.0, shR[1] + 0.05, 0.03); q["hl"] = V(0.0, shL[1] - 0.02, 0.03)
    zf = Sz + (LEG + TORSO) * math.cos(math.radians(phi)) * 0.965
    q.update(fr=V(0.0, foot_y, zf), fl=V(0.0, foot_y, zf), flr=1, fll=1, kr=V(1, 0, 0), kl=V(1, 0, 0))
    q["fr"] = V(0.0, 0.08, zf + 0.02); q["fl"] = V(0.0, 0.08, zf + 0.02 + 0.0)
    q["fr"] = V(0.0, 0.08, zf); q["fl"] = V(0.12, 0.08, zf)
    return q
reg("fg_clutch", [flag("tuck", Sy=1.50), clutch()], [POLE], FV, hold=True, durs=[1.8])

# pole grip & hang: hands high/low on a vertical pole, switch hands
PX = 0.22
def pole_hang(top_right=True):
    Sy = 1.74
    q = pose_from_shoulder(V(0.0, Sy, 0), 90, shup=0.03, er=V(-0.3, -1, 0.3), el=V(-0.3, -1, 0.3))
    hi, lo = V(PX, 2.28, 0.05), V(PX, 1.78, -0.05)
    q["hr"], q["hl"] = (hi, lo) if top_right else (lo.copy() * V(1, 1, -1), hi.copy() * V(1, 1, -1))
    q["hdr"] = q["hdl"] = V(0, 1, 0); q["hwr"] = q["hwl"] = 1.0
    legs_to(q, 6, pf=60)
    return q
reg("fg_pole", [pole_hang(True), pole_hang(False)], [pole(PX, 0.0, 2.6)], [("3/4 front", 40, 10), SIDE_V, FRONT_V], hold=True, durs=[1.4], rdurs=[1.4])

# hanging oblique knee raise
def oblique(up):
    q = hp(HANG_SY + 0.05, ta=96 if up else 90, shup=-0.03, flex=18 if up else 0, lean=-8 if up else 0)
    if up:
        legs_tuck(q, kx=0.28, ky=0.22)
        for k in ("fr", "fl"):
            q[k] = q[k] + V(0, 0, -0.26)
    return q
reg("fg_oblique", [oblique(False), oblique(True)], PULL_PROPS, [("Front", 0, 6), ("3/4 front", 40, 12), SIDE_V], durs=[1.5], rdurs=[2.0])

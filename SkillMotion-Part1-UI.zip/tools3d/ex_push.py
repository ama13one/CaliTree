from h import *

TH = LEG + TORSO

# ---- Wall push-up: standing body line leaning on a wall, palms on the wall at shoulder height
wx = 0.95
def wall_key(th, hy=1.36):
    q = line_pose(V(0, ANKLE_H, 0), th, **HS(wx - 0.03, hy, 0.24), **FS(0, ANKLE_H, 0.10),
                  er=V(-1, 0.1, 0.5), el=V(-1, 0.1, 0.5), hwr=1, hwl=1, hdr=V(0, 1, 0), hdl=V(0, 1, 0),
                  flr=1, fll=1)
    return q
reg("push_wall", [wall_key(73), wall_key(55)], [wall(wx)], [SIDE_V, TQ, TOP])

# ---- Incline push-up: hands on a 50 cm surface
def incline(boxh=0.50):
    Fy = 0.25
    hy = boxh + 0.03
    th_up = th_for(Fy, hy + ARM * 0.985 * 0.97)
    S = shoulder_of(line_pose(V(0, Fy, 0), th_up))
    hx = S[0] - 0.03
    top = sup(0, Fy, th_up, hx, hy, 0.25)
    bot = sup(0, Fy, th_for(Fy, boxh + 0.24), hx, hy, 0.25)
    return top, bot, hx
t, b, hx = incline()
reg("push_incline", [t, b], [box(hx - 0.3, 0, -0.5, hx + 0.25, 0.50, 0.5)], [SIDE_V, TQ, FRONT_V])

# ---- Push-up
t, b, hx = pushup_keys()
reg("push_pushup", [t, b], [], [SIDE_V, FRONT_V, TQ])

# ---- Diamond push-up: hands together under the chest, thumbs and index fingers form a diamond
def diamond():
    Fy = 0.25
    t, b, hx = pushup_keys(hz=0.055, er=(-1, 0.2, 0.12), dnS=0.23, hand_dx=-0.10)
    for q in (t, b):
        q["hdr"] = V(1, 0, -0.55); q["hdl"] = V(1, 0, 0.55)
    return t, b
t, b = diamond()
reg("push_diamond", [t, b], [], [FRONT_V, SIDE_V, TOP])

# ---- Decline push-up: feet on a 30 cm box
Fy = 0.25 + 0.30
t, b, hx = pushup_keys(Fy=Fy, dnS=0.22)
reg("push_decline", [t, b], [box(-0.45, 0, -0.3, 0.12, 0.30, 0.3)], [SIDE_V, TQ, FRONT_V])

# ---- Archer push-up: wide hands, weight shifts over one hand, other arm stays straight
def archer():
    Fy, hz = 0.25, 0.60
    th = th_for(Fy, 0.46)
    top = sup(0, Fy, th, 0.0, 0.05, hz, feet_z=0.24)
    S = shoulder_of(top)
    hx = S[0] - 0.03
    top = sup(0, Fy, th, hx, 0.05, hz, feet_z=0.24)
    # shift to the left hand (z<0): rotate the body so the chest lands over the left hand
    b = sup(0, Fy, th_for(Fy, 0.20), hx, 0.05, hz, feet_z=0.24, yaw=9.0)
    J, _ = solve(b)
    # the right (extended) arm: straighten by keeping the hand where it is and letting IK stay as reachable
    return top, b
t, b = archer()
reg("push_archer", [t, b], [], [FRONT_V, TQ, SIDE_V])

# ---- Explosive / clap push-up
t, b, hx = pushup_keys()
Fy = 0.25
air = sup(0, Fy, th_for(Fy, 0.05 + 0.15 + ARM * 0.985 + 0.0), hx, 0.05 + 0.15, 0.25)
reg("push_explosive", [t, b, air], [], [SIDE_V, FRONT_V, TQ], durs=[0.9, 0.35])
airc = dict(air)
Sa = shoulder_of(air)
airc.update(hr=V(Sa[0] + 0.16, Sa[1] - 0.22, 0.04), hl=V(Sa[0] + 0.16, Sa[1] - 0.22, -0.04),
            hdr=V(0, 1, -0.2), hdl=V(0, 1, 0.2), hwr=1, hwl=1, er=V(-1, 0, 0.6), el=V(-1, 0, 0.6))
reg("push_clap", [t, b, airc], [], [SIDE_V, FRONT_V, TQ], durs=[0.9, 0.35])

# ---- One-arm push-up (floor and elevated)
def one_arm(boxh=0.0):
    Fy = 0.25 + 0.0
    hy = boxh + 0.05
    th_up = th_for(Fy, hy + math.sqrt((ARM*0.985)**2 - 0.05**2 - (0.21-0.04)**2))
    feet = 0.30
    mk = lambda th: sup(0, Fy, th, 0, hy, 0.04, feet_z=feet)
    S = shoulder_of(mk(th_up))
    hx = S[0] - 0.05
    def key(th, hxx):
        q = sup(0, Fy, th, hxx, hy, 0.04, feet_z=feet)
        dd = V(math.cos(math.radians(q["ta"])), math.sin(math.radians(q["ta"])), 0)
        q["hl"] = q["p"] + dd * 0.14 + V(0, 0.10, -0.07)   # free hand on the lower back
        q["hdl"] = V(1, 0, 0); q["hwl"] = 0.0
        q["el"] = V(-0.6, 0.7, 1.0)
        q["p"] = q["p"] + V(0, 0, 0.0)
        return q
    return key(th_up, hx), key(th_for(Fy, boxh + 0.23), hx), hx
t, b, hx = one_arm()
reg("push_oa", [t, b], [], [FRONT_V, TQ, SIDE_V], durs=[1.5])
t, b, hx = one_arm(0.40)
reg("push_oa_elev", [t, b], [box(hx - 0.3, 0, -0.2, hx + 0.25, 0.40, 0.28)], [FRONT_V, TQ, SIDE_V], durs=[1.4])

# ---- Parallel bar dip family
BY = 1.08
def dip(Sx_top=0.02, Sx_bot=0.20, Sy_top=None, Sy_bot=None, lean_top=84, lean_bot=68, legs="behind"):
    hx = 0.0
    wy = BY + 0.035
    Sy_top = wy + ARM * 0.985 if Sy_top is None else Sy_top
    Sy_bot = wy + 0.26 if Sy_bot is None else Sy_bot
    def key(sx, sy, ta, shup):
        q = pose_from_shoulder(V(sx, sy, 0), ta, shup=shup)
        q.update(HS(hx, wy, 0.28), hwr=1, hwl=1, er=V(-1, 0.6, 0.35), el=V(-1, 0.6, 0.35))
        # legs: knees bent, shins back and crossed (feet together)
        hip = q["p"]
        f = hip + V(-0.42, -0.30, 0)
        q.update(fr=f + V(0, 0, 0.03), fl=f - V(0, 0, 0.03), kr=V(0.4, -1, 0.1), kl=V(0.4, -1, 0.1), pfr=40, pfl=40)
        return q
    return key(Sx_top, Sy_top, lean_top, -0.05), key(Sx_bot, Sy_bot, lean_bot, 0.0)
t, b = dip()
dips_props = [pbars(-0.55, 0.55, BY)]
reg("push_dip", [t, b], dips_props, [SIDE_V, FRONT_V, TQ])
reg("push_negdip", [t, b], dips_props, [SIDE_V, FRONT_V, TQ], durs=[4.5])
reg("push_wdip", [t, b], dips_props + [(7, 0, 0, 0, 0, 0, 0)], [SIDE_V, FRONT_V, TQ])

# ---- Korean dip: bar behind the back, hands behind the hips
def korean():
    bx, by = -0.10, 0.92
    def key(sy, sx, ta):
        q = pose_from_shoulder(V(sx, sy, 0), ta, shup=-0.03)
        q.update(hr=V(bx, by + 0.03, 0.23), hl=V(bx, by + 0.03, -0.23), hwr=1, hwl=1,
                 hdr=V(-0.3, 0, 1) , hdl=V(-0.3, 0, -1), er=V(-1, 0.8, 0.3), el=V(-1, 0.8, 0.3))
        hip = q["p"]
        f = hip + V(0.38, -0.34, 0)
        q.update(fr=f + V(0, 0, 0.06), fl=f - V(0, 0, 0.06), kr=V(1, 0.3, 0.1), kl=V(1, 0.3, 0.1), pfr=30, pfl=30)
        return q
    return key(by + 0.52, bx + 0.18, 86), key(by + 0.27, bx + 0.12, 86)
t, b = korean()
reg("push_korean", [t, b], [bar(-0.10, 0.92, 0.5)], [SIDE_V, TQB, REAR_V])

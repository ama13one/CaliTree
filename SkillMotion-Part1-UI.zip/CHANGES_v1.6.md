# CaliTree 1.6

- Added nine accent palettes: forest green, blue, red, purple, ocean, sunset, sunny yellow, silver-white, and warm orange.
- Added editable app name and display name in Profile settings.
- Motivational sentence is optional during onboarding and can be edited or cleared later.
- Added one-tap suggested weekly and monthly workout plans; duration, difficulty, and sessions remain customizable.
- Increased Android version to 1.6 and corrected the Compose UI graphics dependency coordinate.

All preferences and workout progress continue to be stored locally on the device.

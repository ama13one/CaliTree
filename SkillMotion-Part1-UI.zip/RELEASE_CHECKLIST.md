# Release checklist (v1.3)

No update-category checklist existed in the project, so this file records the categories addressed by this release.

- [x] 🌱 Skill Trees & Progression
- [x] 🎨 UI, Themes & Customization
- [x] 🏋️ Exercise & Skill System (3D exercise animations re-baked: no launches, no snapping, planted contacts, floor and limb overlap handled)
- [x] 📊 Progress Tracking & Statistics
- [x] 🌍 Languages & Accessibility
- [ ] ⚡ Performance & Optimization (none: asset size and playback code are unchanged)
- [x] 💻 Technical & Developer Improvements (animation audit, filmstrip viewer, asset verifier in tools3d/)

Not verified in this release: the APK was not built and the animations were not watched on a device (no Android SDK was
available where the asset was produced). Before publishing: build, then play at least the exercises listed under
"Known open items" in tools3d/README.md, plus one push, pull, leg, core, handstand, lever, planche/flag and rings exercise.

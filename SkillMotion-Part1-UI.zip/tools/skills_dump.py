"""Parse the Kotlin skill files into python dicts (id, tree, name, steps...)."""
import re, glob, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA = os.path.join(ROOT, "app/src/main/java/com/calitree/app/data")
STR = re.compile(r'"((?:[^"\\]|\\.)*)"')
def load():
    out = []
    for f in sorted(glob.glob(os.path.join(DATA, "Skills*.kt"))):
        t = open(f, encoding="utf-8").read()
        for m in re.finditer(r'sk\(\s*"([a-z_0-9]+)",\s*(\w+),\s*"((?:[^"\\]|\\.)*)",\s*(\d),\s*(\d+),', t):
            rest = t[m.end():]
            strs = []
            pos = 0
            while len(strs) < 7:
                s = STR.search(rest, pos)
                strs.append(s.group(1)); pos = s.end()
            pre, desc, req, vol, goal, steps, tip = strs
            out.append(dict(id=m.group(1), tree=m.group(2), name=m.group(3), d=int(m.group(4)),
                            pre=pre, desc=desc, req=req, goal=goal, steps=steps.split("|"), tip=tip))
    return out
if __name__ == "__main__":
    import sys
    sk = load(); print(len(sk))
    trees = sys.argv[1:]
    for s in sk:
        if not trees or s["tree"] in trees:
            print(s["id"], "|", s["name"], "|", " / ".join(s["steps"])[:260])

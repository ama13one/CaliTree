from lib import *

FL = floor()


def fwd(S):
    return (S[0] + 0.30, S[1] - 0.03)


def sq(hip, ta, foot=(0.5, 0.0), ff=None, hn=None, hf=None):
    S = shoulder(hip, ta)
    return P(hip, ta, hn or fwd(S), foot, hf=hf, ff=ff, eb=-1, kb=1)


# ======================= LEGS =======================
st = sq((0.5, LEG), 90)
bt = sq((0.33, 0.20), 62)
reg("legs_squat", [st, bt], [FL])

# reverse lunge
l0 = sq((0.5, LEG), 90, foot=(0.5, 0.0))
l1 = sq((0.52, 0.30), 88, foot=(0.58, 0.0), ff=(0.12, 0.03))
reg("legs_lunge", [l0, l1], [FL])

# bulgarian split squat (rear foot on bench)
b0 = sq((0.58, 0.46), 90, foot=(0.64, 0.0), ff=(0.14, 0.40))
b1 = sq((0.55, 0.28), 82, foot=(0.68, 0.0), ff=(0.14, 0.40))
reg("legs_bulgarian", [b0, b1], [FL, box(-0.05, 0, 0.2, 0.37)])

# shrimp squat (rear foot held)
def shrimp(extra=None):
    s0 = sq((0.5, LEG), 90, foot=(0.5, 0.0), ff=(0.2, 0.35), hf=(0.2, 0.35))
    s1 = sq((0.46, 0.21), 78, foot=(0.52, 0.0), ff=(0.15, 0.2), hf=(0.15, 0.2))
    return [s0, s1]


reg("legs_shrimp_assist", shrimp(), [FL, box(0.05, 0, 0.3, 0.05)])
reg("legs_shrimp", shrimp(), [FL])

# jump squat
j0 = P((0.5, LEG), 90, (0.52, 0.5), (0.5, 0.0), ff=(0.55, 0.0))
j1 = P((0.33, 0.22), 62, (0.12, 0.62), (0.5, 0.0))
j2 = P((0.55, 0.78), 90, (0.62, 1.2), (0.55, 0.30), ff=(0.62, 0.33), eb=-1, kb=1)
reg("legs_jump", [j0, j1, j2], [FL])

# box jump
c0 = P((0.2, LEG), 90, (0.22, 0.5), (0.2, 0.0))
c1 = P((0.12, 0.22), 62, (-0.15, 0.55), (0.2, 0.0))
c2 = P((0.55, 0.85), 90, (0.65, 1.25), (0.55, 0.45), ff=(0.62, 0.48))
c3 = P((0.95, 0.30 + LEG), 90, (0.97, 0.80), (0.95, 0.30), ff=(1.0, 0.30))
reg("legs_boxjump", [c0, c1, c2, c3], [FL, box(0.78, 0, 1.2, 0.30)])

# glute bridges
S0 = (0.10, 0.03)
foot = (0.62, 0.0)
g0 = lying(S0, 0.06, foot=foot)
g1 = lying(S0, 0.30, foot=foot)
reg("legs_bridge", [g0, g1], [FL])
up = lambda q: (q[0] + 0.47, q[1] + 0.14)
reg("legs_bridge_single", [mod(g0, ff=up), mod(g1, ff=up)], [FL])

# calf raises
k0 = P((0.5, LEG), 90, (0.52, 0.48), (0.5, 0.0), ff=(0.5, 0.0))
k1 = P((0.5, LEG + 0.1), 90, (0.52, 0.58), (0.5, 0.1), ff=(0.5, 0.1))
reg("legs_calf", [k0, k1], [FL])
k0s = mod(k0, ff=(0.3, 0.30))
k1s = mod(k1, ff=(0.3, 0.30))
reg("legs_calf_single", [k0s, k1s], [FL])


# pistol family
def pist(hip_bot, ta_bot=62):
    p0 = sq((0.55, LEG), 90, foot=(0.55, 0.0), ff=(0.98, 0.34))
    p1 = sq(hip_bot, ta_bot, foot=(0.55, 0.0), ff=(hip_bot[0] + 0.48, hip_bot[1] + 0.10))
    return p0, p1


p0, p1 = pist((0.36, 0.26))
reg("legs_box_pistol", [p0, p1], [FL, box(0.02, 0, 0.32, 0.21)])
p0, p1 = pist((0.38, 0.19))
hold = (0.78, 0.62)
reg("legs_pistol_assist", [mod(p0, hn=hold), mod(p1, hn=hold)], [FL, pole(0.78)])
p0, p1 = pist((0.38, 0.14))
reg("legs_pistol", [p0, p1], [FL])
d0 = sq((0.55, LEG), 90, foot=(0.55, 0.0), ff=(0.42, 0.28))
d1 = sq((0.45, 0.15), 55, foot=(0.55, 0.0), ff=(0.10, 0.12))
reg("legs_dragon", [d0, d1], [FL])


# nordic curl
def nordic(theta):
    K = (0.55, 0.03)
    d = dr(theta)
    hip = (K[0] + 0.25 * d[0], K[1] + 0.25 * d[1])
    S = shoulder(hip, theta)
    return P(hip, theta, (S[0] + 0.18, max(0.0, S[1] - 0.2)), (0.32, 0.06), eb=-1, kb=1)


n0 = nordic(90)
n1 = nordic(16)
n1 = mod(n1, hn=(n1[4] - 0.0, 0.0))
anchor = box(0.12, 0, 0.38, 0.10)
reg("legs_nordic_neg", [n0, n1], [FL, anchor])
reg("legs_nordic", [n0, n1, nordic(80)], [FL, anchor])


# ======================= CORE =======================
def plank_f(hip_dy, Fy=0.02, Sy=0.18):
    phi = math.degrees(math.asin((Sy - Fy) / BODY))
    d = dr(phi)
    F = (0.0, Fy)
    S = (BODY * d[0], BODY * d[1] + Fy)
    hip = (F[0] + LEG * d[0], F[1] + LEG * d[1] + hip_dy)
    ta = math.degrees(math.atan2(S[1] - hip[1], S[0] - hip[0]))
    el = (S[0], max(0.0, S[1] - UA))
    return P(hip, ta, (S[0] + 0.17, 0.0), F, eb=-1, kb=1)


reg("core_plank", [plank_f(0.09), plank_f(0.0)], [FL], hold=True)
reg("core_side", [plank_f(-0.08), plank_f(0.0)], [FL], hold=True)
s1 = plank_f(0.0)
reg("core_side_lift", [s1, mod(s1, ff=(0.15, 0.40))], [FL])

# lying core
SL = (0.15, 0.03)
tt = lambda hip: (hip[0] + 0.22, hip[1] + 0.25)
db0 = lying(SL, 0.03, hn=(0.17, 0.37), foot=(0.67, 0.28))
db1 = mod(db0, hn=(-0.19, 0.05), ff=(0.95, 0.05))
reg("core_deadbug", [db0, db1], [FL])

h0 = lying(SL, 0.03, hn=(-0.18, 0.03), foot=(0.95, 0.03))
hp = (0.45, 0.04)
S_h = shoulder(hp, 160)
h1 = P(hp, 160, (S_h[0] - 0.32, S_h[1] + 0.05), (hp[0] + 0.5 * math.cos(math.radians(14)), 0.04 + 0.5 * math.sin(math.radians(14))), eb=-1, kb=1)
reg("core_hollow", [h0, h1], [FL], hold=True)

r0 = lying(SL, 0.03, foot=(0.95, 0.03))
r1 = mod(r0, fn=(0.47, 0.52), ff=(0.47, 0.52))
reg("core_legraise", [r0, r1], [FL])

# support family (parallettes)
PAR = box(0.42, 0, 0.58, 0.12)
H = (0.5, 0.12)
sit0 = hang(H, (0.5, 0.36), 90, (0.5, 0.0), eb=-1)
tuck = sit_support(H, 90, fd=(0.15, -0.05), lean=-0.05)
reg("core_tuck_lsit", [sit0, tuck], [FL, PAR], hold=True)
one = sit_support(H, 90, fd=(0.5, 0.0), ffd=(0.15, -0.05), lean=-0.05)
reg("core_lsit_one", [tuck, one], [FL, PAR], hold=True)
L = sit_support(H, 90, fd=(0.5, 0.0), lean=-0.05)
reg("core_lsit", [tuck, L], [FL, PAR], hold=True)
high = sit_support(H, 94, fd=(0.46, 0.20), lean=-0.05)
reg("core_lsit_high", [L, high], [FL, PAR], hold=True)
V = sit_support(H, 102, fd=(0.30, 0.40), lean=-0.05)
reg("core_vsit", [high, V], [FL, PAR], hold=True)
Sm = (0.58, 0.45)
hm = (0.42, 0.68)
ta_m = math.degrees(math.atan2(Sm[1] - hm[1], Sm[0] - hm[0]))
hm = (Sm[0] - LT * math.cos(math.radians(ta_m)), Sm[1] - LT * math.sin(math.radians(ta_m)))
manna = P(hm, ta_m, H, (hm[0] + 0.5 * math.cos(math.radians(14)), hm[1] + 0.5 * math.sin(math.radians(14))), eb=-1, kb=1)
reg("core_manna", [V, manna], [FL, PAR], hold=True)

# dragon flag on a bench
BEN = box(-0.2, 0, 0.3, 0.25)
SB = (0.12, 0.28)
lie = P((0.42, 0.28), 180, (-0.02, 0.30), (0.92, 0.28), eb=-1, kb=1)
full = P((0.12, 0.58), 270, (-0.02, 0.30), (0.12, 1.08), eb=-1, kb=1)
tuck_d = P((0.14, 0.55), 268, (-0.02, 0.30), (0.30, 0.50), ff=(0.30, 0.50), eb=-1, kb=1)
negd = P((0.12 + 0.3 * math.cos(math.radians(35)) * -1 * -1 * 0 + 0.246, 0.452), 215, (-0.02, 0.30), (0.78, 0.74), eb=-1, kb=1)
reg("core_dragon_tuck", [lie, tuck_d], [FL, BEN])
reg("core_dragon_neg", [full, negd], [FL, BEN])
reg("core_dragon_full", [lie, full], [FL, BEN])

# hanging core
BARY = 1.15
Hh = (0.5, BARY)
lowh = hang(Hh, (0.5, BARY - ARM), 90, (0.02, -0.5))
reg("core_hang_knee", [lowh, hang(Hh, (0.5, BARY - ARM), 98, (0.10, -0.12))], [bar(0.5, BARY)])
hl = hang(Hh, (0.5, BARY - ARM), 108, (0.5, 0.0))
reg("core_hang_leg", [lowh, hl], [bar(0.5, BARY)])
ttb = hang(Hh, (0.5, BARY - ARM), 112, (0.0, 0.5))
reg("core_ttb", [lowh, ttb], [bar(0.5, BARY)])
w1 = hang(Hh, (0.5, BARY - ARM), 112, (0.12, 0.48), ffd=(-0.1, 0.49))
w2 = hang(Hh, (0.5, BARY - ARM), 112, (-0.1, 0.49), ffd=(0.12, 0.48))
reg("core_wiper", [w1, w2], [bar(0.5, BARY)])

# -*- coding: utf-8 -*-
"""Rewrites the user-facing strings of the Skills*.kt files with the Persian texts in tools/fa/.
Usage (from project root):  python3 tools/apply_fa.py
Ids, trees, difficulty, lanes and prerequisites are never touched."""
import glob, os, re, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "fa"))
import push, pull, legs, core, handstand, levers, planche_flag, rings

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA = os.path.join(ROOT, "app/src/main/java/com/calitree/app/data")
FA = {}
for m in (push, pull, legs, core, handstand, levers, planche_flag, rings):
    FA.update(m.T)

DIG = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
def fa(s):
    s = s.translate(DIG)
    assert '"' not in s and "\\" not in s and "$" not in s, s
    return s

HEAD = re.compile(r'sk\(\s*"([a-z_0-9]+)",\s*(\w+),\s*"((?:[^"\\]|\\.)*)",\s*(\d),\s*(\d+),')
STR = re.compile(r'"((?:[^"\\]|\\.)*)"')

total = 0
for f in sorted(glob.glob(os.path.join(DATA, "Skills*.kt"))):
    t = open(f, encoding="utf-8").read()
    out, pos = [], 0
    for m in HEAD.finditer(t):
        sid = m.group(1)
        name, desc, req, vol, goal, steps, tip = FA[sid]
        # header up to the name literal
        out.append(t[pos:m.start(3)])
        out.append(fa(name))
        out.append(t[m.end(3):m.end()])
        pos = m.end()
        # next 7 literals: pre (keep), desc, req, vol, goal, steps, tip
        vals = [None, desc, req, vol, goal, steps, tip]
        for v in vals:
            s = STR.search(t, pos)
            if v is None:
                out.append(t[pos:s.end()])
            else:
                out.append(t[pos:s.start(1)])
                out.append(fa(v))
                out.append(t[s.end(1):s.end()])
            pos = s.end()
        total += 1
    out.append(t[pos:])
    open(f, "w", encoding="utf-8").write("".join(out))
print("rewrote", total, "skills")

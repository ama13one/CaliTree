import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from lib import *


def draw_props(ax, props, xmin=-0.4, xmax=1.6):
    for k, a, b, c, d in props:
        if k == 0:
            ax.plot([xmin, xmax], [0, 0], color="#888", lw=1.5)
        elif k == 1:
            ax.plot([a - 0.13, a + 0.13], [b, b], color="#444", lw=3)
        elif k == 2:
            ax.plot([a, a], [0, 1.4], color="#444", lw=3)
        elif k == 3:
            ax.add_patch(plt.Rectangle((a, b), c - a, d - b, fc="#ddd", ec="#444"))
        elif k == 4:
            ax.add_patch(plt.Circle((a, b), 0.04, fc="none", ec="#444", lw=2))
            ax.plot([a, a], [b + 0.04, 1.5], color="#999", lw=1)
        elif k == 5:
            ax.plot([a, a], [0, 1.4], color="#444", lw=4)
        elif k == 6:
            ax.plot([a, c], [b, d], color="#444", lw=3)


COLORS = ["#1f77b4", "#2ca02c", "#d62728", "#ff7f0e"]


def draw_pose(ax, p, color, alpha=1.0):
    j = joints(p)
    ax.plot([j["fe"][0], j["fh"][0]], [j["fe"][1], j["fh"][1]], color=color, lw=1.5, alpha=alpha * 0.5)
    ax.plot([j["S"][0], j["fe"][0]], [j["S"][1], j["fe"][1]], color=color, lw=1.5, alpha=alpha * 0.5)
    ax.plot([j["hip"][0], j["fk"][0], j["ff"][0]], [j["hip"][1], j["fk"][1], j["ff"][1]], color=color, lw=1.5, alpha=alpha * 0.5)
    ax.plot([j["hip"][0], j["S"][0]], [j["hip"][1], j["S"][1]], color=color, lw=3, alpha=alpha)
    ax.plot([j["S"][0], j["ne"][0], j["nh"][0]], [j["S"][1], j["ne"][1], j["nh"][1]], color=color, lw=2.2, alpha=alpha)
    ax.plot([j["hip"][0], j["nk"][0], j["nf"][0]], [j["hip"][1], j["nk"][1], j["nf"][1]], color=color, lw=2.2, alpha=alpha)
    ax.add_patch(plt.Circle(j["head"], HEAD_R, fc=color, ec=color, alpha=alpha))


def sheet(ids, path, cols=5, title=""):
    rows = math.ceil(len(ids) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.6, rows * 2.1), dpi=65)
    axes = axes.flatten() if hasattr(axes, "flatten") else [axes]
    for ax in axes:
        ax.axis("off")
    for ax, sid in zip(axes, ids):
        m = MOTIONS[sid]
        ax.set_xlim(-0.4, 1.6)
        ax.set_ylim(m.view[0], m.view[1])
        ax.set_aspect("equal")
        draw_props(ax, m.props)
        n = len(m.poses)
        for i, p in enumerate(m.poses):
            draw_pose(ax, p, COLORS[min(i, 3)] if n > 1 else COLORS[0])
        ax.set_title(sid, fontsize=7, pad=1)
    fig.tight_layout(pad=0.3)
    fig.savefig(path)
    plt.close(fig)


def sheet2(ids, path, cols=4):
    """Larger, auto-cropped preview."""
    rows = math.ceil(len(ids) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.4, rows * 3.0), dpi=62)
    axes = axes.flatten() if hasattr(axes, "flatten") else [axes]
    for ax in axes:
        ax.axis("off")
    for ax, sid in zip(axes, ids):
        m = MOTIONS[sid]
        xs = []; ys = []
        for p in m.poses:
            j = joints(p)
            for k in ("hip", "S", "head", "nh", "fh", "nf", "ff", "ne", "nk"):
                xs.append(j[k][0]); ys.append(j[k][1])
        x0, x1 = min(xs) - 0.25, max(xs) + 0.25
        y0, y1 = min(ys + [0]) - 0.1, max(ys) + 0.15
        w = max(x1 - x0, (y1 - y0) * 1.3); h = w / 1.3
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        ax.set_xlim(cx - w / 2, cx + w / 2); ax.set_ylim(cy - h / 2, cy + h / 2)
        ax.set_aspect("equal")
        draw_props(ax, m.props)
        for i, p in enumerate(m.poses):
            draw_pose(ax, p, COLORS[min(i, 3)])
        ax.set_title(sid, fontsize=8, pad=1)
    fig.tight_layout(pad=0.3)
    fig.savefig(path)
    plt.close(fig)

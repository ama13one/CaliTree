"""Form tips (per movement family) and common mistakes (per exercise). Persian texts live in tools/fa/."""

FAMILY = {}
from fa.texts_fa import TIPS  # Persian form tips (tools/fa/texts_fa.py)

_fam_map = {
    "pushup": "push_wall push_incline push_pushup push_diamond push_decline push_archer push_explosive push_clap push_oa_elev push_oa pl_pseudo rg_pushup rg_fly",
    "dip": "push_negdip push_dip push_wdip push_korean rg_dip",
    "hang": "pull_hang pull_scap rg_false",
    "pull": "pull_neg pull_chin pull_pullup pull_lpullup pull_explosive pull_archer pull_weighted pull_ctb pull_oa_assist pull_oa_neg pull_oa rg_pullup rg_fg_pullup",
    "row": "pull_row_inc pull_row rg_row",
    "muscleup": "pull_mu_trans pull_mu pull_mu_strict rg_transition rg_mu rg_strict",
    "squat": "legs_squat legs_lunge legs_bulgarian",
    "single": "legs_box_pistol legs_pistol_assist legs_pistol legs_dragon legs_shrimp_assist legs_shrimp",
    "bridge": "legs_bridge legs_bridge_single legs_nordic_neg legs_nordic",
    "calf": "legs_calf legs_calf_single",
    "jump": "legs_jump legs_boxjump",
    "lying": "core_plank core_deadbug core_side core_hollow core_legraise core_side_lift",
    "hangcore": "core_hang_knee core_hang_leg core_ttb core_wiper fg_oblique",
    "support": "core_tuck_lsit core_lsit_one core_lsit core_lsit_high core_vsit core_manna rg_support rg_rto rg_lsit",
    "dragon": "core_dragon_tuck core_dragon_neg core_dragon_full",
    "pike": "hs_pike hs_elev_pike hs_compress",
    "handstand": "hs_wall_walk hs_wall_hold hs_heel_pulls hs_kickup hs_free hs_shift hs_walk hs_oa",
    "hspu": "hs_hspu_neg hs_hspu_wall hs_hspu_def hs_hspu_free hs_90",
    "press": "hs_press_wall hs_straddle_press hs_pike_press",
    "lever": "fl_tuck fl_adv_tuck fl_row fl_oneleg fl_straddle fl_full fl_pullup bl_skin bl_german bl_tuck bl_adv_tuck bl_oneleg bl_straddle bl_full",
    "planche": "pl_lean pl_frog pl_tuck pl_adv_tuck pl_tuck_pp pl_oneleg pl_straddle pl_full pl_pp",
    "flag": "fg_pole fg_clutch fg_tuck fg_adv_tuck fg_straddle fg_full",
    "prep": "hs_wrist",
}
for fam, ids in _fam_map.items():
    for i in ids.split():
        FAMILY[i] = fam

from fa.texts_fa import MISTAKES  # Persian common mistakes (tools/fa/texts_fa.py)

"""Authoring library for CaliTree exercise demonstrations.

A motion is a list of key poses (side view, figure faces +x, y is up).
A pose stores: hip, torso angle, head tilt, near/far hand targets, near/far foot targets,
and the bend direction of elbows/knees. Limbs are solved with 2-bone IK at runtime
(the Kotlin app uses exactly the same maths, see ui/DemoPlayer.kt).
"""
import math

LT = 0.30            # hip -> shoulder
UA, FA = 0.17, 0.17  # upper arm, forearm
TH, SH = 0.25, 0.25  # thigh, shin
LEG = TH + SH
ARM = UA + FA
BODY = LEG + LT      # ankle -> shoulder when straight
HEAD_R = 0.062
HEAD_D = 0.125

DEFAULT_VIEW = (-0.1, 1.3)


def dr(a):
    r = math.radians(a)
    return (math.cos(r), math.sin(r))


def shoulder(hip, ta):
    d = dr(ta)
    return (hip[0] + LT * d[0], hip[1] + LT * d[1])


def hip_of(S, ta):
    d = dr(ta)
    return (S[0] - LT * d[0], S[1] - LT * d[1])


def ik(A, T, l1, l2, sign):
    dx, dy = T[0] - A[0], T[1] - A[1]
    dist = math.hypot(dx, dy)
    if dist < 1e-6:
        return (A[0], A[1] - l1), (A[0], A[1] - l1 - l2)
    ux, uy = dx / dist, dy / dist
    d = min(dist, l1 + l2 - 1e-4)
    d = max(d, abs(l1 - l2) + 1e-4)
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, l1 * l1 - a * a))
    jx = A[0] + a * ux + sign * h * (-uy)
    jy = A[1] + a * uy + sign * h * ux
    return (jx, jy), (A[0] + d * ux, A[1] + d * uy)


def P(hip, ta, hn, fn, hf=None, ff=None, eb=-1, kb=1, hd=0):
    hf = hf or hn
    ff = ff or fn
    return [hip[0], hip[1], ta, hd, hn[0], hn[1], hf[0], hf[1],
            fn[0], fn[1], ff[0], ff[1], eb, kb]


def hip_of_pose(p):
    return (p[0], p[1])


def shoulder_of_pose(p):
    return shoulder((p[0], p[1]), p[2])


def mod(p, hn=None, hf=None, fn=None, ff=None, hd=None, eb=None, kb=None, hip=None, ta=None):
    q = list(p)

    def val(v):
        return v(q) if callable(v) else v

    if hip is not None:
        h = val(hip); q[0], q[1] = h
    if ta is not None:
        q[2] = val(ta)
    if hd is not None:
        q[3] = hd
    if hn is not None:
        h = val(hn); q[4], q[5] = h
    if hf is not None:
        h = val(hf); q[6], q[7] = h
    if fn is not None:
        h = val(fn); q[8], q[9] = h
    if ff is not None:
        h = val(ff); q[10], q[11] = h
    if eb is not None:
        q[12] = eb
    if kb is not None:
        q[13] = kb
    return q


def joints(p):
    hip = (p[0], p[1])
    S = shoulder(hip, p[2])
    hd = dr(p[2] + p[3])
    head = (S[0] + HEAD_D * hd[0], S[1] + HEAD_D * hd[1])
    ne, nh = ik(S, (p[4], p[5]), UA, FA, p[12])
    fe, fh = ik(S, (p[6], p[7]), UA, FA, p[12])
    nk, nf = ik(hip, (p[8], p[9]), TH, SH, p[13])
    fk, ff = ik(hip, (p[10], p[11]), TH, SH, p[13])
    return dict(hip=hip, S=S, head=head, ne=ne, nh=nh, fe=fe, fh=fh, nk=nk, nf=nf, fk=fk, ff=ff)


# ---------------- props ----------------
def floor(): return (0, 0, 0, 0, 0)
def bar(x, y): return (1, x, y, 0, 0)
def wall(x): return (2, x, 0, 0, 0)
def box(x0, y0, x1, y1): return (3, x0, y0, x1, y1)
def ring(x, y): return (4, x, y, 0, 0)
def pole(x): return (5, x, 0, 0, 0)
def seg(a, b, c, d): return (6, a, b, c, d)


class Motion:
    def __init__(self, poses, props, hold=False, view=DEFAULT_VIEW):
        self.poses = poses
        self.props = props
        self.hold = hold
        self.view = view


MOTIONS = {}


def reg(sid, poses, props, hold=False, view=DEFAULT_VIEW):
    MOTIONS[sid] = Motion(poses, props, hold, view)


# ---------------- pose builders ----------------
def phi_for_hand_y(Fy, hand_y):
    """Body angle so that straight arms (hanging down) reach hand_y."""
    return math.degrees(math.asin(max(-1, min(1, (hand_y + ARM - Fy) / BODY))))


def sup(F, phi_up, armdir, phi_dn, eb=-1, kb=1):
    """Straight body supported by feet F and hands. phi = direction foot->head (deg).
    Hands stay fixed; the body rotates about the feet (push-up like)."""
    d = dr(phi_up)
    S_up = (F[0] + BODY * d[0], F[1] + BODY * d[1])
    a = dr(armdir)
    H = (S_up[0] + ARM * a[0], S_up[1] + ARM * a[1])

    def body(phi):
        dd = dr(phi)
        hip = (F[0] + LEG * dd[0], F[1] + LEG * dd[1])
        return P(hip, phi, H, F, eb=eb, kb=kb)

    return body(phi_up), body(phi_dn)


def stand(x=0.5, hands=None, hd=0, bend=0.0):
    hip = (x, LEG)
    S = shoulder(hip, 90)
    hn = hands or (x + 0.03, S[1] - ARM + 0.02)
    return P(hip, 90, hn, (x, 0.0), ff=(x + 0.05, 0.0), eb=-1, kb=1, hd=hd)


def hang(H, S, ta, fd, ffd=None, eb=1, kb=1, hf=None, hd=0, hn=None, fa=None, ffa=None):
    hip = hip_of(S, ta)
    fn = (hip[0] + fd[0], hip[1] + fd[1])
    ffd = ffd or fd
    ff = (hip[0] + ffd[0], hip[1] + ffd[1])
    if fa is not None:
        fn = fa
        ff = ffa or fa
    hfv = hf(hip, S) if callable(hf) else hf
    return P(hip, ta, hn or H, fn, hf=hfv, ff=ff, eb=eb, kb=kb, hd=hd)


def inv(H, sy, th=90, lean=0.0, ffoot=None, eb=-1, kb=1, hd=0, hf=None, hn=None):
    """Inverted body: hands H on the floor, shoulders above at height sy,
    body line leaving the shoulder in direction th. ffoot: offset of far foot."""
    S = (H[0] + lean, H[1] + sy)
    d = dr(th)
    hip = (S[0] + LT * d[0], S[1] + LT * d[1])
    foot = (hip[0] + LEG * d[0], hip[1] + LEG * d[1])
    ff = (foot[0] + ffoot[0], foot[1] + ffoot[1]) if ffoot else None
    return P(hip, th + 180, hn or H, foot, hf=hf, ff=ff, eb=eb, kb=kb, hd=hd)


def lying(S, hip_h, hands_off=(-0.1, 0.0), foot=None, ff=None, kb=1, eb=-1, hd=0, hn=None, hf=None):
    """Lying on the back, head at -x. Shoulder S on floor, hip at height hip_h."""
    dy = S[1] - hip_h
    dx = math.sqrt(max(0.0, LT * LT - dy * dy))
    hip = (S[0] + dx, hip_h)
    ta = math.degrees(math.atan2(S[1] - hip[1], S[0] - hip[0]))
    hn = hn or (S[0] + 0.33, 0.02)
    foot = foot or (hip[0] + 0.25, 0.0)
    return P(hip, ta, hn, foot, hf=hf, ff=ff, eb=eb, kb=kb, hd=hd)


def sit_support(H, ta=90, fd=(0.5, 0.0), ffd=None, lean=0.0, kb=1, eb=-1, hd=0, hn=None, hf=None):
    """Arm support (L-sit family): straight arms down to hands H, torso above hips."""
    S = (H[0] + lean, H[1] + ARM)
    hip = hip_of(S, ta)
    fn = (hip[0] + fd[0], hip[1] + fd[1])
    ffd = ffd or fd
    ff = (hip[0] + ffd[0], hip[1] + ffd[1])
    return P(hip, ta, hn or H, fn, hf=hf, ff=ff, eb=eb, kb=kb, hd=hd)

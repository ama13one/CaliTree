from lib import *

FL = floor()
BARY = 1.15


# ======================= HANDSTAND =======================
# wall on the LEFT, hands walk toward it (chest to wall)
WX = 0.10


def hs_wall(sy=ARM - 0.005, hx=0.32, th=100, **kw):
    return inv((hx, 0.0), sy, th=th, **kw)


# wrist prep: quadruped rocking
q0 = P((0.2, 0.30), 8, (0.62, 0.0), (0.05, 0.03), eb=-1, kb=1)
S0 = shoulder((0.2, 0.30), 8)
q0 = P((0.2, 0.30), 8, (S0[0], 0.0), (0.0, 0.03), eb=-1, kb=1)
S1 = (S0[0] + 0.12, S0[1])
q1 = P((0.32, 0.30), 8, (S0[0], 0.0), (0.12, 0.03), eb=-1, kb=1)
reg("hs_wrist", [q0, q1], [FL], hold=True)

# pike push-up (feet fixed on the floor, hips high)
def pike_pose(Sy, ta, hd=0, feet_y=0.0, fx=0.12):
    H = (0.70, 0.0)
    S = (0.66, Sy)
    hip = hip_of(S, ta)
    return P(hip, ta, H, (fx, feet_y), eb=-1, kb=1, hd=hd)


pu = pike_pose(ARM - 0.005, -20)
pd = pike_pose(0.17, -32, hd=-25)
reg("hs_pike", [pu, pd], [FL])
pu2 = pike_pose(ARM - 0.005, -32, feet_y=0.27, fx=0.10)
pd2 = pike_pose(0.2, -42, hd=-25, feet_y=0.27, fx=0.10)
reg("hs_elev_pike", [pu2, pd2], [FL, box(-0.15, 0, 0.2, 0.24)])

# wall walk: feet on wall, walk up
u, d = sup((WX, 0.12), 180 - 18, 0, 180 - 18)
w0 = P(u[:2], u[2], u[4:6], (WX, 0.12), eb=-1, kb=1)
Fw = (0.0, 0.0)
# plank with feet on wall at left: head to the right
ph = phi_for_hand_y(0.12, 0.0)
S_p = (WX + BODY * math.cos(math.radians(ph)), 0.12 + BODY * math.sin(math.radians(ph)))
hipp = (WX + LEG * math.cos(math.radians(ph)), 0.12 + LEG * math.sin(math.radians(ph)))
w0 = P(hipp, ph, (S_p[0], 0.0), (WX, 0.12), eb=-1, kb=1)
w1 = hs_wall(th=100)
w1 = mod(w1, fn=(WX + 0.02, w1[9]), ff=(WX + 0.02, w1[9]))
reg("hs_wall_walk", [w0, w1], [FL, wall(WX)])
reg("hs_wall_hold", [w0, w1], [FL, wall(WX)], hold=True)

# heel pulls: heels leave the wall
f_on = hs_wall(th=97)
f_off = hs_wall(th=90, lean=0.02)
reg("hs_heel_pulls", [f_on, f_off], [FL, wall(WX)], hold=True)

# kick-up: lunge to handstand
kk0 = P((0.2, 0.45), -50, (0.55, 0.0), (0.3, 0.0), ff=(-0.2, 0.12), eb=-1, kb=1)
kk1 = inv((0.55, 0.0), 0.32, th=130, lean=-0.10, ffoot=(0.18, -0.1))
kk2 = hs_wall(hx=0.55, th=90)
reg("hs_kickup", [kk0, kk1, kk2], [FL])

# handstand variants
hs = inv((0.5, 0.0), ARM - 0.005, th=90)
hs_s = inv((0.5, 0.0), ARM - 0.005, th=92, ffoot=(0.14, -0.04))
reg("hs_free", [kk1, hs], [FL], hold=True)
w_a = inv((0.5, 0.0), ARM - 0.005, th=90, hf=(0.55, 0.0))
w_b = inv((0.5, 0.0), ARM - 0.005, th=90, hf=(0.62, 0.0), hn=(0.5, 0.0))
w_b2 = inv((0.5, 0.0), ARM - 0.005, th=84, hn=(0.5, 0.0), hf=(0.78, 0.0))
reg("hs_walk", [w_a, mod(w_b2, hf=(0.78, 0.12))], [FL])
sh0 = inv((0.5, 0.0), ARM - 0.005, th=90)
sh1 = inv((0.5, 0.0), ARM - 0.005, th=90, lean=0.03, hf=(0.62, 0.22), ffoot=(0.12, 0.0))
reg("hs_shift", [sh0, sh1], [FL])
sh2 = inv((0.5, 0.0), ARM - 0.005, th=96, lean=0.02, hf=(0.75, 0.28), ffoot=(0.22, -0.06))
reg("hs_oa", [sh0, sh2], [FL], hold=True)

# presses: fold -> hips over shoulders -> handstand
def press(split=0.0):
    a = P((0.30, 0.5), -60, (0.58, 0.0), (0.3, 0.0), ff=(0.3 + split, 0.0), eb=-1, kb=1)
    b = inv((0.55, 0.0), 0.30, th=122, ffoot=(split, 0.0), lean=-0.06)
    c = inv((0.55, 0.0), ARM - 0.005, th=92, ffoot=(split * 0.5, 0.0))
    return a, b, c


a, b, c = press(0.0)
reg("hs_pike_press", [a, b, c], [FL])
a, b, c = press(0.2)
reg("hs_straddle_press", [a, b, c], [FL])
a, b, c = press(0.1)
reg("hs_press_wall", [a, b, c], [FL, wall(0.15)])

# compression lift (seated pike): hands beside hips, legs straight lift off floor
H = (0.40, 0.0)
c0 = P((0.40, 0.04), 95, H, (0.90, 0.02), eb=-1, kb=1)
Sc = (0.40, ARM - 0.01)
hc = hip_of(Sc, 95)
c0 = P(hc, 95, H, (hc[0] + 0.5, 0.02), eb=-1, kb=1)
c1 = P(hc, 100, H, (hc[0] + 0.48, hc[1] + 0.12), eb=-1, kb=1)
reg("hs_compress", [c0, c1], [FL])

# HSPU family
top = inv((0.5, 0.0), ARM - 0.005, th=95)
bot = inv((0.5, 0.0), 0.15, th=95, hd=-20)
reg("hs_hspu_wall", [top, bot], [FL, wall(0.5 + 0.12 + 0.0)])
reg("hs_hspu_neg", [bot, top], [FL, wall(0.5 + 0.12)])
bot_d = inv((0.5, 0.0), 0.09, th=95, hd=-20)
reg("hs_hspu_def", [top, bot_d], [FL, wall(0.62), box(0.4, 0, 0.6, 0.0)])
top_f = inv((0.5, 0.0), ARM - 0.005, th=90)
bot_f = inv((0.5, 0.0), 0.15, th=90, hd=-20)
reg("hs_hspu_free", [top_f, bot_f], [FL])
# 90-degree push-up: from handstand to a low, almost horizontal body above the floor
S90 = (0.62, 0.30)
a90 = 8
h90 = hip_of(S90, 180 + a90)
f90 = (h90[0] - LEG * math.cos(math.radians(a90)), h90[1] + LEG * math.sin(math.radians(a90)))
n1 = P(h90, 180 + a90, (0.5, 0.0), f90, eb=-1, kb=1, hd=-10)
reg("hs_90", [top_f, n1], [FL])

# ======================= LEVERS =======================
Hh = (0.5, BARY)


def flev(ta_body, hip_off, fd, ffd=None, hd=0):
    """Front lever: body roughly horizontal, face toward the sky, head toward the bar side (left)."""
    S = (0.5 + 0.0, BARY - 0.30)
    hip = hip_of(S, ta_body)
    fn = (hip[0] + fd[0], hip[1] + fd[1])
    ffv = (hip[0] + (ffd or fd)[0], hip[1] + (ffd or fd)[1])
    return P(hip, ta_body, Hh, fn, ff=ffv, eb=1, kb=-1, hd=hd)


f_hang = hang(Hh, (0.5, BARY - ARM), 90, (0.02, -0.5))
# horizontal body: hip->shoulder points left (180)
tuckF = flev(180, 0, (0.12, 0.14))
advF = flev(180, 0, (0.22, 0.1))
oneF = flev(180, 0, (0.5, 0.0), (0.12, 0.14))
strF = flev(180, 0, (0.5, 0.0), (0.5, 0.0))
fullF = flev(180, 0, (0.5, 0.0))
reg("fl_tuck", [f_hang, tuckF], [bar(0.5, BARY)], hold=True)
reg("fl_adv_tuck", [tuckF, advF], [bar(0.5, BARY)], hold=True)
reg("fl_oneleg", [advF, oneF], [bar(0.5, BARY)], hold=True)
reg("fl_straddle", [oneF, mod(strF, ff=(strF[10] + 0.0, strF[11] - 0.06))], [bar(0.5, BARY)], hold=True)
reg("fl_full", [f_hang, fullF], [bar(0.5, BARY)], hold=True)
rowF = P((advF[0] - 0.0, advF[1]), 180, (0.5, 1.15), (advF[8], advF[9]), eb=1, kb=-1)
Sr = flev(180, 0, (0.22, 0.1))
topR = flev(165, 0, (0.22, 0.1))
topR = mod(topR, hip=(topR[0] + 0.0, topR[1] + 0.1))
reg("fl_row", [advF, mod(advF, hip=(advF[0] + 0.03, advF[1] + 0.14), ta=170)], [bar(0.5, BARY)])
reg("fl_pullup", [fullF, mod(fullF, hip=(fullF[0] + 0.05, fullF[1] + 0.22), ta=165, fn=(fullF[8] + 0.03, fullF[9] + 0.3), ff=(fullF[10] + 0.03, fullF[11] + 0.3))], [bar(0.5, BARY)])

# back lever: body horizontal, face down, behind the bar
def blev(fd, ffd=None, ta=0):
    S = (0.5, BARY - 0.28)
    hip = hip_of(S, ta)
    fn = (hip[0] + fd[0], hip[1] + fd[1])
    ffv = (hip[0] + (ffd or fd)[0], hip[1] + (ffd or fd)[1])
    return P(hip, ta, Hh, fn, ff=ffv, eb=-1, kb=1)


# german hang: hands overhead on bar, body hanging behind/below
g_hang = P((0.28, 0.62), 70, Hh, (0.28, 0.12), eb=-1, kb=1)
Sg = shoulder((0.28, 0.62), 70)
g_hang = P((0.38, 0.6), 62, Hh, (0.38, 0.1), eb=1, kb=-1)
bl_tuck = blev((-0.12, -0.13))
bl_adv = blev((-0.22, -0.09))
bl_one = blev((-0.5, 0.0), (-0.12, -0.13))
bl_str = blev((-0.5, 0.0), (-0.5, 0.0))
bl_full = blev((-0.5, 0.0))
reg("bl_german", [f_hang, g_hang], [bar(0.5, BARY)], hold=True)
skin1 = P((0.52, 0.78), 85, Hh, (0.62, 1.0), eb=1, kb=1)
skin2 = P((0.6, 1.0), 35, Hh, (0.5, 1.22), eb=1, kb=1)
reg("bl_skin", [f_hang, hang(Hh, (0.5, BARY - ARM), 90, (0.1, 0.3), eb=1), g_hang], [bar(0.5, BARY)])
reg("bl_tuck", [g_hang, bl_tuck], [bar(0.5, BARY)], hold=True)
reg("bl_adv_tuck", [bl_tuck, bl_adv], [bar(0.5, BARY)], hold=True)
reg("bl_oneleg", [bl_adv, bl_one], [bar(0.5, BARY)], hold=True)
reg("bl_straddle", [bl_one, mod(bl_str, ff=(bl_str[10], bl_str[11] - 0.06))], [bar(0.5, BARY)], hold=True)
reg("bl_full", [g_hang, bl_full], [bar(0.5, BARY)], hold=True)

# ======================= PLANCHE =======================
def planche(F_up, hip_lift, fd, ffd=None, lean=0.22, hy=0.0):
    """Hands on floor at (0.5,0), shoulders ahead of hands, body horizontal above floor."""
    H = (0.5, hy)
    S = (0.5 + lean, hy + ARM - 0.005)
    ta = 0
    hip = hip_of(S, 180 + 0)  # body extends left (-x)
    ta_ = 0
    hip = (S[0] - LT * math.cos(math.radians(180)), 0)
    return None


def pl(S_off, ta, fd, ffd=None, hy=0.0, sy=None):
    H = (0.55, hy)
    S = (0.55 + S_off, hy + (math.sqrt(max(0.01, ARM * ARM - S_off * S_off)) - 0.004 if sy is None else sy))
    hip = hip_of(S, ta)
    fn = (hip[0] + fd[0], hip[1] + fd[1])
    ffv = (hip[0] + (ffd or fd)[0], hip[1] + (ffd or fd)[1])
    return P(hip, ta, H, fn, ff=ffv, eb=-1, kb=1)


# body goes to the left; hip->shoulder angle ~ 0 deg (pointing right)
lean = pl(0.20, 18, (-0.5, -0.10))
lean_hi = pl(0.20, 10, (-0.5, -0.05))
reg("pl_lean", [pl(0.04, 24, (-0.5, -0.20)), lean], [FL], hold=True)
frog = P((0.30, 0.28), 10, (0.62, 0.0), (0.24, 0.22), eb=-1, kb=1)
crouch = P((0.28, 0.20), 30, (0.60, 0.02), (0.36, 0.0), eb=-1, kb=1)
reg("pl_frog", [crouch, frog], [FL], hold=True)
reg("pl_pseudo", [pl(0.06, 22, (-0.5, -0.18)), pl(0.22, 14, (-0.5, -0.12))], [FL])
tuckP = pl(0.22, 8, (-0.12, 0.12))
advP = pl(0.22, 6, (-0.25, 0.10))
oneP = pl(0.22, 4, (-0.5, 0.02), (-0.12, 0.12))
strP = pl(0.22, 2, (-0.5, 0.0), (-0.5, 0.0))
fullP = pl(0.22, 0, (-0.5, 0.0))
reg("pl_tuck", [pl(0.22, 16, (-0.12, -0.02)), tuckP], [FL], hold=True)
reg("pl_adv_tuck", [tuckP, advP], [FL], hold=True)
reg("pl_oneleg", [advP, oneP], [FL], hold=True)
reg("pl_straddle", [oneP, mod(strP, ff=(strP[10], strP[11] - 0.07))], [FL], hold=True)
reg("pl_full", [advP, fullP], [FL], hold=True)
tuck_lo = pl(0.20, 10, (-0.12, 0.10), sy=0.20)
reg("pl_tuck_pp", [tuckP, tuck_lo], [FL])
full_lo = pl(0.20, 2, (-0.5, 0.0), sy=0.20)
reg("pl_pp", [fullP, full_lo], [FL])

# ======================= HUMAN FLAG =======================
PX = 0.15


def flag(ta, fd, ffd=None, F=None):
    S = (PX + 0.10, 1.0)
    hip = hip_of(S, ta)
    fn = F or (hip[0] + fd[0], hip[1] + fd[1])
    ffv = F or (hip[0] + (ffd or fd)[0], hip[1] + (ffd or fd)[1])
    return P(hip, ta, (PX, 1.12), fn, hf=(PX, 0.86), ff=ffv, eb=1, kb=1)


pole_up = P((0.35, 0.5), 90, (PX, 1.1), (0.35, 0.0), hf=(PX, 0.86), eb=1, kb=1)
pole_lean = P((0.45, 0.52), 109, (PX, 1.1), (0.52, 0.0), hf=(PX, 0.86), eb=1, kb=1)
reg("fg_pole", [pole_up, pole_lean], [FL, pole(PX)], hold=True)
clutch = P((0.444, 0.388), 130.8, (PX, 0.74), (0.76, 0.0), hf=(PX, 0.50), eb=1, kb=1)
reg("fg_clutch", [pole_up, clutch], [FL, pole(PX)], hold=True)
fl_t = flag(180, (0.12, 0.12))
fl_a = flag(180, (0.25, 0.08))
fl_s = flag(180, (0.5, 0.0), (0.5, -0.08))
fl_f = flag(180, (0.5, 0.0))
fl_str = flag(180, (0.5, 0.05), (0.5, -0.12))
reg("fg_tuck", [clutch, fl_t], [FL, pole(PX)], hold=True)
reg("fg_adv_tuck", [fl_t, fl_a], [FL, pole(PX)], hold=True)
reg("fg_straddle", [fl_a, fl_str], [FL, pole(PX)], hold=True)
reg("fg_full", [fl_str, fl_f], [FL, pole(PX)], hold=True)

# hanging oblique knee raise (hang from a bar)
lowh = hang(Hh, (0.5, BARY - ARM), 90, (0.02, -0.5))
reg("fg_oblique", [lowh, hang(Hh, (0.5, BARY - ARM), 98, (0.10, -0.12))], [bar(0.5, BARY)])

# ======================= RINGS =======================
RB = 0.62


def rings_at(x, y):
    return [ring(x - 0.04, y), ring(x + 0.04, y)]


top = hang((0.5, RB), (0.5, RB + ARM - 0.005), 88, (0.05, -0.5), eb=-1)
reg("rg_support", [hang((0.5, RB), (0.5, RB + 0.2), 88, (0.05, -0.5), eb=-1), top], rings_at(0.5, RB), hold=True)
reg("rg_rto", [top, mod(top, hip=(top[0], top[1]))], rings_at(0.5, RB), hold=True)
bot = hang((0.5, RB), (0.51, RB + 0.19), 80, (-0.1, -0.47), eb=-1)
reg("rg_dip", [top, bot], rings_at(0.5, RB))
lsit = hang((0.5, RB), (0.5, RB + ARM - 0.005), 90, (0.5, 0.0), eb=-1)
reg("rg_lsit", [top, lsit], rings_at(0.5, RB), hold=True)

# ring push-up / fly
ph0 = phi_for_hand_y(0.02, 0.22)
u, d = sup((0.0, 0.02), ph0, -90, math.degrees(math.asin((0.22 + 0.13 - 0.02) / BODY)))
reg("rg_pushup", [u, d], [FL] + rings_at(u[4], 0.22))
fly_up = u
fly_dn = mod(d, hn=(d[4] + 0.10, d[5] - 0.0), hf=(d[4] + 0.10, d[5]))
reg("rg_fly", [mod(u, hn=(u[4], 0.22)), mod(d, hn=(d[4], 0.26), eb=-1)], [FL] + rings_at(u[4], 0.22))


def ring_row(bar_h):
    Hx = 0.6
    Fy = 0.02
    phi_s = math.degrees(math.asin((bar_h - ARM - Fy) / BODY))
    phi_p = math.degrees(math.asin((bar_h - 0.07 - Fy) / BODY))
    Fx = Hx - BODY * math.cos(math.radians(phi_s))
    a, b = sup((Fx, Fy), phi_s, 90, phi_p, eb=1)
    return a, b, [FL] + rings_at(a[4], bar_h)


a, b, pr = ring_row(0.55)
reg("rg_row", [a, b], pr)

# ring pull-ups (rings high)
RH = BARY
H = (0.5, RH)
lowR = hang(H, (0.5, RH - ARM), 90, (0.02, -0.5))
topR = hang(H, (0.43, 1.10), 100, (0.06, -0.5), hd=-20)
reg("rg_pullup", [lowR, topR], rings_at(0.5, RH))
reg("rg_false", [lowR, hang(H, (0.5, RH - ARM + 0.03), 90, (0.02, -0.5))], rings_at(0.5, RH), hold=True)
reg("rg_fg_pullup", [lowR, topR], rings_at(0.5, RH))

# ring muscle-up
MB = 0.95
MH = (0.5, MB)
mh = hang(MH, (0.5, MB - ARM), 90, (0.02, -0.5))
mp = hang(MH, (0.40, 0.99), 125, (0.22, -0.44), hd=-30)
mt = hang(MH, (0.50, MB + 0.17), 100, (0.10, -0.47), hd=-10)
ms = hang(MH, (0.50, MB + ARM - 0.005), 88, (0.04, -0.5), eb=1)
MV = (-0.4, 1.55)
reg("rg_mu", [mh, mp, mt, ms], rings_at(0.5, MB), view=MV)
reg("rg_strict", [mh, mp, mt, ms], rings_at(0.5, MB), view=MV)
LB = 0.62
LH = (0.5, LB)
t0 = hang(LH, (0.40, 0.60), 35, (0.0, 0), fa=(0.15, 0.0))
t1 = hang(LH, (0.5, 0.78), 70, (0.0, 0), fa=(0.32, 0.0))
t2 = hang(LH, (0.5, LB + ARM - 0.005), 90, (0.0, 0), fa=(0.5, 0.16))
reg("rg_transition", [t0, t1, t2], [FL] + rings_at(0.5, LB))

from lib import *

FL = floor()
BARY = 1.15


# ======================= PUSH =======================
def floor_push(Fy=0.02, hand_y=0.0, dn_y=0.15):
    up = phi_for_hand_y(Fy, hand_y)
    dn = math.degrees(math.asin((dn_y - Fy) / BODY))
    return sup((0.0, Fy), up, -90, dn)


def hand_x(p):
    return p[4]


# wall push-up
u, d = sup((0.0, 0.0), 72, 0, 56)
reg("push_wall", [u, d], [FL, wall(u[4] + 0.02)])

# incline
Fy = 0.02
hy = 0.28
u, d = sup((0.0, Fy), phi_for_hand_y(Fy, hy), -90, math.degrees(math.asin((hy + 0.15 - Fy) / BODY)))
reg("push_incline", [u, d], [FL, box(u[4] - 0.22, 0, u[4] + 0.2, hy)])

# push-up, diamond
u, d = floor_push()
reg("push_pushup", [u, d], [FL])
reg("push_diamond", [u, d], [FL])

# decline: feet on box
Fy = 0.28
u, d = sup((0.0, Fy), phi_for_hand_y(Fy, 0.0), -90, math.degrees(math.asin((0.16 - Fy) / BODY)))
reg("push_decline", [u, d], [FL, box(-0.25, 0, 0.12, Fy - 0.03)])

# archer: far arm reaches forward straight
u, d = floor_push()
fx = u[4] + 0.2
reg("push_archer", [mod(u, hf=(fx, 0.0)), mod(d, hf=(fx, 0.0))], [FL])

# explosive / clap
u, d = floor_push()
air, _ = sup((0.0, 0.02 + 0.16), phi_for_hand_y(0.02, 0.0) + 2, -90, 20)
reg("push_explosive", [u, d, air], [FL])
air2 = mod(air, hn=(air[4] + 0.1, air[5] + 0.12), hf=(air[4] + 0.1, air[5] + 0.12))
reg("push_clap", [u, d, air2], [FL])

# elevated one arm push-up (hand on box, far hand behind back)
hy = 0.28
u, d = sup((0.0, 0.02), phi_for_hand_y(0.02, hy), -90, math.degrees(math.asin((hy + 0.15 - 0.02) / BODY)))
back = lambda q: (q[0] - 0.02, q[1] + 0.02)
reg("push_oa_elev", [mod(u, hf=back), mod(d, hf=back)], [FL, box(u[4] - 0.22, 0, u[4] + 0.2, hy)])
u, d = floor_push()
reg("push_oa", [mod(u, hf=back), mod(d, hf=back)], [FL])


# dips
def dip_poses(Hx=0.5, Hy=0.62, deep=0.0):
    top = hang((Hx, Hy), (Hx, Hy + ARM - 0.005), 84, (-0.12, -0.48), eb=-1)
    bot = hang((Hx, Hy), (Hx + 0.01, Hy + 0.19 - deep), 80, (-0.15, -0.46), eb=-1)
    return top, bot


top, bot = dip_poses()
reg("push_negdip", [top, bot], [FL, bar(0.5, 0.62)])
reg("push_dip", [top, bot], [FL, bar(0.5, 0.62)])
reg("push_wdip", [top, bot], [FL, bar(0.5, 0.62), box(0.38, 0.12, 0.46, 0.2)])

# Korean dip: bar behind the back
top = hang((0.0, 0.62), (0.22, 0.89), 90, (0.08, -0.48), eb=-1)
bot = hang((0.0, 0.62), (0.2, 0.75), 86, (0.08, -0.47), eb=-1)
reg("push_korean", [top, bot], [FL, bar(0.0, 0.62)])


# ======================= PULL =======================
def hangs(Hx=0.5, by=BARY):
    H = (Hx, by)
    low = hang(H, (Hx, by - ARM), 90, (0.02, -0.5))
    return H, low


H, low = hangs()
act = hang(H, (0.5, BARY - ARM + 0.035), 90, (0.02, -0.5))
reg("pull_hang", [low, act], [bar(0.5, BARY)], hold=True)
reg("pull_scap", [low, hang(H, (0.5, BARY - ARM + 0.05), 90, (0.02, -0.5))], [bar(0.5, BARY)])

top = hang(H, (0.43, 1.10), 100, (0.06, -0.5), hd=-20)
reg("pull_neg", [top, low], [bar(0.5, BARY)])
reg("pull_chin", [low, top], [bar(0.5, BARY)])
reg("pull_pullup", [low, top], [bar(0.5, BARY)])
reg("pull_weighted", [low, top], [bar(0.5, BARY)])

# L-sit pull-up
lowL = hang(H, (0.5, BARY - ARM), 90, (0.5, 0.0))
topL = hang(H, (0.43, 1.10), 100, (0.5, 0.04), hd=-20)
reg("pull_lpullup", [lowL, topL], [bar(0.5, BARY)])

# explosive / chest to bar
topE = hang(H, (0.40, 1.12), 112, (0.12, -0.48), hd=-30)
reg("pull_explosive", [low, topE], [bar(0.5, BARY)])
reg("pull_ctb", [low, topE], [bar(0.5, BARY)])

# archer
lowA = hang(H, (0.5, BARY - ARM), 90, (0.02, -0.5), hf=(0.5, BARY))
topA = hang(H, (0.43, 1.10), 100, (0.06, -0.5), hd=-20, hf=(0.80, 1.13))
reg("pull_archer", [lowA, topA], [bar(0.5, BARY)])

# one arm family
relax = lambda hip, S: (hip[0] + 0.06, hip[1] + 0.02)
lowO = hang(H, (0.5, BARY - ARM), 90, (0.02, -0.5), hf=relax)
topO = hang(H, (0.43, 1.10), 100, (0.06, -0.5), hd=-20, hf=relax)
reg("pull_oa", [lowO, topO], [bar(0.5, BARY)])
reg("pull_oa_neg", [topO, lowO], [bar(0.5, BARY)])
holdw = (0.52, 0.99)
lowW = hang(H, (0.5, BARY - ARM), 90, (0.02, -0.5), hf=holdw)
topW = hang(H, (0.43, 1.10), 100, (0.06, -0.5), hd=-20, hf=(0.46, 1.0))
reg("pull_oa_assist", [lowW, topW], [bar(0.5, BARY)])


# inverted rows
def row(bar_h, props_extra=None, rings=False):
    Hx = 0.6
    Fy = 0.02
    S_straight_y = bar_h - ARM
    phi_s = math.degrees(math.asin((S_straight_y - Fy) / BODY))
    phi_p = math.degrees(math.asin((bar_h - 0.07 - Fy) / BODY))
    # place feet so that straight-arm shoulder sits below the hands
    Fx = Hx - BODY * math.cos(math.radians(phi_s))
    a, b = sup((Fx, Fy), phi_s, 90, phi_p, eb=1)
    if rings:
        pr = [FL, ring(a[4] - 0.05, a[5]), ring(a[4] + 0.05, a[5])]
    else:
        pr = [FL, bar(a[4], bar_h)]
    return a, b, pr


a, b, pr = row(0.85); reg("pull_row_inc", [a, b], pr)
a, b, pr = row(0.52); reg("pull_row", [a, b], pr)

# muscle-ups (high bar, no floor)
MV = (-0.4, 1.55)
MB = 0.95
MH = (0.5, MB)
mh = hang(MH, (0.5, MB - ARM), 90, (0.02, -0.5))
mp = hang(MH, (0.40, 0.99), 125, (0.22, -0.44), hd=-30)
mt = hang(MH, (0.50, MB + 0.17), 100, (0.10, -0.47), hd=-10)
ms = hang(MH, (0.50, MB + ARM - 0.005), 88, (0.04, -0.5), eb=1)
reg("pull_mu", [mh, mp, mt, ms], [bar(0.5, MB)], view=MV)
reg("pull_mu_strict", [mh, mp, mt, ms], [bar(0.5, MB)], view=MV)

# transition drill on a low bar (feet on / near the floor)
LB = 0.62
LH = (0.5, LB)
t0 = hang(LH, (0.40, 0.60), 35, (0.0, 0), fa=(0.15, 0.0))
t1 = hang(LH, (0.5, 0.78), 70, (0.0, 0), fa=(0.32, 0.0))
t2 = hang(LH, (0.5, LB + ARM - 0.005), 90, (0.0, 0), fa=(0.5, 0.16))
reg("pull_mu_trans", [t0, t1, t2], [FL, bar(0.5, LB)])

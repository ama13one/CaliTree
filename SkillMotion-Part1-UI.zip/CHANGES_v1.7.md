# SkillMotion 1.7

- Added push-up and pull-up self-assessment to onboarding; values are stored locally.
- Workout suggestions limit difficulty using the user's self-assessment.
- Added workout-focus filters for core/side body, handstand, upper body, legs, planche, levers, human flag, and rings.
- Added a settings gear on the profile and clearer full-theme labeling.
- Kept the original exercise data, tree, progress storage, favorites, and existing workout planner.

Build verification: this archive has not been compiled in this environment. Run the repository's GitHub Actions build and confirm success before installing the APK.

package com.calitree.app.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.R
import java.io.BufferedInputStream
import java.io.DataInputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// ---------------------------------------------------------------------------------------------
// Data. The file assets/demo3d.bin is produced by tools3d/build3d.py: for every exercise it holds
// baked joint positions (20 joints, millimetres) for the whole movement, the camera presets and
// the props. The app only plays it back, so what you see is exactly what the tools verified.
// ---------------------------------------------------------------------------------------------

class D3Prop(val kind: Int, val a: FloatArray)
class D3View(val name: String, val az: Float, val el: Float)

class Demo3D(
    val id: String,
    val hold: Boolean,
    val loop: Boolean,
    val center: FloatArray,
    val radius: Float,
    val props: List<D3Prop>,
    val views: List<D3View>,
    val keys: IntArray,
    val durs: FloatArray,
    val rdurs: FloatArray,
    val frames: ShortArray,
    val nFrames: Int
)

object Demo3DStore {
    private var all: HashMap<String, Demo3D>? = null

    @Synchronized
    fun get(context: Context, id: String): Demo3D? {
        var m = all
        if (m == null) {
            m = load(context.applicationContext)
            all = m
        }
        return m[id]
    }

    private fun load(context: Context): HashMap<String, Demo3D> {
        val out = HashMap<String, Demo3D>()
        try {
            DataInputStream(BufferedInputStream(context.assets.open("demo3d.bin"))).use { s ->
                s.readInt()
                val n = s.readInt()
                for (i in 0 until n) {
                    val id = s.readUTF()
                    val flags = s.readUnsignedByte()
                    val cx = s.readFloat()
                    val cy = s.readFloat()
                    val cz = s.readFloat()
                    val rad = s.readFloat()
                    val np = s.readUnsignedByte()
                    val props = ArrayList<D3Prop>()
                    for (k in 0 until np) {
                        val kind = s.readUnsignedByte()
                        val a = FloatArray(6)
                        for (j in 0 until 6) a[j] = s.readFloat()
                        props.add(D3Prop(kind, a))
                    }
                    val nv = s.readUnsignedByte()
                    val views = ArrayList<D3View>()
                    for (k in 0 until nv) {
                        val nm = s.readUTF()
                        val az = s.readFloat()
                        val el = s.readFloat()
                        views.add(D3View(nm, az, el))
                    }
                    val nk = s.readUnsignedByte()
                    val keys = IntArray(nk)
                    for (k in 0 until nk) keys[k] = s.readUnsignedShort()
                    val durs = FloatArray(max(nk - 1, 0))
                    for (k in durs.indices) durs[k] = s.readFloat()
                    val rdurs = FloatArray(max(nk - 1, 0))
                    for (k in rdurs.indices) rdurs[k] = s.readFloat()
                    val nf = s.readUnsignedShort()
                    val fr = ShortArray(nf * 60)
                    for (k in fr.indices) fr[k] = s.readShort()
                    out[id] = Demo3D(
                        id, (flags and 1) != 0, (flags and 2) != 0, floatArrayOf(cx, cy, cz), rad,
                        props, views, keys, durs, rdurs, fr, nf
                    )
                }
            }
        } catch (e: Exception) {
            // A missing or damaged asset simply means the app falls back to the old demonstration.
        }
        return out
    }
}

// ---------------------------------------------------------------------------------------------
// Playback schedule
// ---------------------------------------------------------------------------------------------

private const val PH_START = 0
private const val PH_MOVE = 1
private const val PH_END = 2

private class D3Seg(val dur: Float, val f0: Float, val f1: Float, val phase: Int)

private fun buildSchedule(d: Demo3D): List<D3Seg> {
    val segs = ArrayList<D3Seg>()
    val n = d.keys.size
    segs.add(D3Seg(0.9f, d.keys[0].toFloat(), d.keys[0].toFloat(), PH_START))
    for (i in 0 until n - 1) {
        segs.add(D3Seg(d.durs[i], d.keys[i].toFloat(), d.keys[i + 1].toFloat(), PH_MOVE))
    }
    val last = d.keys[n - 1].toFloat()
    segs.add(D3Seg(if (d.hold) 2.6f else 1.0f, last, last, PH_END))
    if (!d.loop) {
        for (i in n - 2 downTo 0) {
            segs.add(D3Seg(d.rdurs[i], d.keys[i + 1].toFloat(), d.keys[i].toFloat(), PH_MOVE))
        }
    }
    return segs
}

private fun locate(segs: List<D3Seg>, time: Float): Pair<D3Seg, Float> {
    var t = time
    for (s in segs) {
        if (t < s.dur) return Pair(s, if (s.dur > 0f) t / s.dur else 0f)
        t -= s.dur
    }
    val s = segs[segs.size - 1]
    return Pair(s, 1f)
}

private fun samplePose(d: Demo3D, frame: Float, out: FloatArray) {
    val lo = min(max(floor(frame).toInt(), 0), d.nFrames - 1)
    val hi = min(lo + 1, d.nFrames - 1)
    val t = (frame - lo).coerceIn(0f, 1f)
    val a = lo * 60
    val b = hi * 60
    for (i in 0 until 60) {
        val va = d.frames[a + i].toFloat()
        val vb = d.frames[b + i].toFloat()
        out[i] = (va + (vb - va) * t) / 1000f
    }
}

// ---------------------------------------------------------------------------------------------
// Camera + renderer (perspective projection, depth sorted shaded capsules)
// ---------------------------------------------------------------------------------------------

private const val J_PELVIS = 0
private const val J_SPINE = 1
private const val J_CHEST = 2
private const val J_HEAD = 3
private const val J_SH_R = 4
private const val J_EL_R = 5
private const val J_WR_R = 6
private const val J_HA_R = 7
private const val J_SH_L = 8
private const val J_EL_L = 9
private const val J_WR_L = 10
private const val J_HA_L = 11
private const val J_HIP_R = 12
private const val J_KN_R = 13
private const val J_AN_R = 14
private const val J_TO_R = 15
private const val J_HIP_L = 16
private const val J_KN_L = 17
private const val J_AN_L = 18
private const val J_TO_L = 19

private const val FOV_HALF_DEG = 24.0

private class Cam(az: Float, el: Float, tx: Float, ty: Float, tz: Float, radius: Float, val cx: Float, val cy: Float, val focal: Float) {
    val ox: Float
    val oy: Float
    val oz: Float
    val rx: Float
    val rz: Float
    val ux: Float
    val uy: Float
    val uz: Float
    val fx: Float
    val fy: Float
    val fz: Float
    val px: Float
    val py: Float
    val pz: Float
    val dist: Float

    init {
        val a = (az * PI / 180.0).toFloat()
        val e = (el * PI / 180.0).toFloat()
        ox = cos(e) * cos(a)
        oy = sin(e)
        oz = cos(e) * sin(a)
        dist = radius / sin((FOV_HALF_DEG * PI / 180.0)).toFloat()
        px = tx + dist * ox
        py = ty + dist * oy
        pz = tz + dist * oz
        fx = -ox
        fy = -oy
        fz = -oz
        // right = forward x up(0,1,0) = (-fz, 0, fx), normalised
        val rl = sqrt(fz * fz + fx * fx).coerceAtLeast(1e-4f)
        rx = -fz / rl
        rz = fx / rl
        // up = right x forward
        ux = 0f * fz - rz * fy
        uy = rz * fx - rx * fz
        uz = rx * fy - 0f * fx
    }

    /** out = [screenX, screenY, depth]; false if behind the camera. */
    fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        val vx = x - px
        val vy = y - py
        val vz = z - pz
        val zc = vx * fx + vy * fy + vz * fz
        if (zc < 0.15f) return false
        val xc = vx * rx + vz * rz
        val yc = vx * ux + vy * uy + vz * uz
        out[0] = cx + focal * xc / zc
        out[1] = cy - focal * yc / zc
        out[2] = zc
        return true
    }
}

private class D3Colors(
    val cloth: Color,
    val skin: Color,
    val pants: Color,
    val shoe: Color,
    val floorLine: Color,
    val prop: Color,
    val rope: Color
)

private class D3Item(val z: Float, val draw: DrawScope.() -> Unit)

private fun shade(c: Color, f: Float): Color =
    Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), c.alpha)

private fun DrawScope.sphere(center: Offset, r: Float, base: Color) {
    if (r < 0.5f) return
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(shade(base, 1.25f), base, shade(base, 0.6f)),
            center = Offset(center.x - r * 0.3f, center.y - r * 0.3f),
            radius = r * 1.5f
        ),
        radius = r,
        center = center
    )
}

private fun DrawScope.capsule(a: Offset, b: Offset, wpx: Float, base: Color) {
    if (wpx < 1f) return
    drawLine(shade(base, 0.62f), a, b, strokeWidth = wpx, cap = StrokeCap.Round)
    drawLine(base, a, b, strokeWidth = wpx * 0.78f, cap = StrokeCap.Round)
    val off = wpx * 0.12f
    drawLine(
        shade(base, 1.3f), Offset(a.x - off, a.y - off), Offset(b.x - off, b.y - off),
        strokeWidth = wpx * 0.32f, cap = StrokeCap.Round
    )
}

private val BOX_FACES = arrayOf(
    intArrayOf(0, 1, 3, 2), intArrayOf(4, 5, 7, 6), intArrayOf(0, 1, 5, 4),
    intArrayOf(2, 3, 7, 6), intArrayOf(0, 2, 6, 4), intArrayOf(1, 3, 7, 5)
)

private fun DrawScope.drawScene(d: Demo3D, j: FloatArray, cam: Cam, c: D3Colors) {
    val items = ArrayList<D3Item>()
    val tmp = FloatArray(3)
    val tmp2 = FloatArray(3)
    val near = cam.dist - d.radius
    val span = 2f * d.radius

    fun jx(i: Int) = j[i * 3]
    fun jy(i: Int) = j[i * 3 + 1]
    fun jz(i: Int) = j[i * 3 + 2]

    // ---- floor grid and soft shadow
    val half = min(2.6f, cam.dist * 0.75f)
    val gx0 = floor(d.center[0] / 0.5f) * 0.5f
    val gz0 = floor(d.center[2] / 0.5f) * 0.5f
    var g = -half
    while (g <= half + 0.001f) {
        if (cam.project(gx0 + g, 0f, gz0 - half, tmp) && cam.project(gx0 + g, 0f, gz0 + half, tmp2)) {
            drawLine(c.floorLine, Offset(tmp[0], tmp[1]), Offset(tmp2[0], tmp2[1]), strokeWidth = 1.5f)
        }
        if (cam.project(gx0 - half, 0f, gz0 + g, tmp) && cam.project(gx0 + half, 0f, gz0 + g, tmp2)) {
            drawLine(c.floorLine, Offset(tmp[0], tmp[1]), Offset(tmp2[0], tmp2[1]), strokeWidth = 1.5f)
        }
        g += 0.5f
    }
    val shadow = Path()
    var started = false
    for (k in 0 until 20) {
        val ang = (k * 2.0 * PI / 20.0).toFloat()
        if (cam.project(jx(J_PELVIS) + 0.42f * cos(ang), 0f, jz(J_PELVIS) + 0.42f * sin(ang), tmp)) {
            if (!started) { shadow.moveTo(tmp[0], tmp[1]); started = true } else shadow.lineTo(tmp[0], tmp[1])
        }
    }
    if (started) {
        shadow.close()
        drawPath(shadow, Color(0f, 0f, 0f, 0.13f))
    }

    // ---- props
    for (p in d.props) {
        val a = p.a
        when (p.kind) {
            1 -> { // bar: x, y, halfwidth
                val x = a[0]; val y = a[1]; val hw = a[2]
                if (cam.project(x, y, -hw, tmp) && cam.project(x, y, hw, tmp2)) {
                    val s0 = Offset(tmp[0], tmp[1]); val s1 = Offset(tmp2[0], tmp2[1])
                    val z = (tmp[2] + tmp2[2]) / 2f
                    val w = 0.04f * cam.focal / z
                    items.add(D3Item(z) { drawLine(c.prop, s0, s1, strokeWidth = max(w, 3f), cap = StrokeCap.Round) })
                    for (sg in floatArrayOf(-1f, 1f)) {
                        if (cam.project(x, 0f, sg * hw, tmp) && cam.project(x, y, sg * hw, tmp2)) {
                            val u0 = Offset(tmp[0], tmp[1]); val u1 = Offset(tmp2[0], tmp2[1])
                            items.add(D3Item(tmp[2] + 0.5f) { drawLine(shade(c.prop, 0.7f), u0, u1, strokeWidth = max(w * 0.8f, 2f)) })
                        }
                    }
                }
            }
            2 -> { // wall at x
                val x = a[0]
                val pts = floatArrayOf(-1.1f, 0f, 1.1f, 0f, 1.1f, 2.7f, -1.1f, 2.7f)
                val path = Path()
                var ok = true
                for (k in 0 until 4) {
                    if (!cam.project(x, pts[k * 2 + 1], pts[k * 2], tmp)) { ok = false; break }
                    if (k == 0) path.moveTo(tmp[0], tmp[1]) else path.lineTo(tmp[0], tmp[1])
                }
                if (ok) {
                    path.close()
                    items.add(D3Item(near + span * 2f) {
                        drawPath(path, Color(0.55f, 0.6f, 0.7f, 0.22f))
                        drawPath(path, Color(0.55f, 0.6f, 0.7f, 0.6f), style = Stroke(width = 2f))
                    })
                }
            }
            3 -> { // box: x0 y0 z0 x1 y1 z1
                val xs = floatArrayOf(a[0], a[3]); val ys = floatArrayOf(a[1], a[4]); val zs = floatArrayOf(a[2], a[5])
                val px = FloatArray(8); val py = FloatArray(8); val pd = FloatArray(8)
                var ok = true
                for (ix in 0..1) for (iy in 0..1) for (iz in 0..1) {
                    val idx = ix * 4 + iy * 2 + iz
                    if (!cam.project(xs[ix], ys[iy], zs[iz], tmp)) { ok = false } else { px[idx] = tmp[0]; py[idx] = tmp[1]; pd[idx] = tmp[2] }
                }
                if (ok) {
                    for (f in BOX_FACES.indices) {
                        val face = BOX_FACES[f]
                        val path = Path()
                        var zsum = 0f
                        for (k in 0 until 4) {
                            val idx = face[k]
                            if (k == 0) path.moveTo(px[idx], py[idx]) else path.lineTo(px[idx], py[idx])
                            zsum += pd[idx]
                        }
                        path.close()
                        val top = (f == 3)
                        val col = shade(Color(0.42f, 0.47f, 0.55f, 0.85f), if (top) 1.25f else 0.9f - 0.05f * f)
                        items.add(D3Item(zsum / 4f + 0.3f) {
                            drawPath(path, col)
                            drawPath(path, Color(0.1f, 0.12f, 0.16f, 0.5f), style = Stroke(width = 1.5f))
                        })
                    }
                }
            }
            5 -> { // pole: x, z, height
                if (cam.project(a[0], 0f, a[1], tmp) && cam.project(a[0], a[2], a[1], tmp2)) {
                    val s0 = Offset(tmp[0], tmp[1]); val s1 = Offset(tmp2[0], tmp2[1])
                    val z = (tmp[2] + tmp2[2]) / 2f
                    val w = 0.07f * cam.focal / z
                    items.add(D3Item(z) { drawLine(c.prop, s0, s1, strokeWidth = max(w, 4f), cap = StrokeCap.Round) })
                }
            }
            6 -> { // parallel bars / parallettes: x0 x1 y halfspacing
                for (sg in floatArrayOf(-1f, 1f)) {
                    val z0 = sg * a[3]
                    if (cam.project(a[0], a[2], z0, tmp) && cam.project(a[1], a[2], z0, tmp2)) {
                        val s0 = Offset(tmp[0], tmp[1]); val s1 = Offset(tmp2[0], tmp2[1])
                        val z = (tmp[2] + tmp2[2]) / 2f
                        val w = 0.04f * cam.focal / z
                        items.add(D3Item(z) { drawLine(c.prop, s0, s1, strokeWidth = max(w, 3f), cap = StrokeCap.Round) })
                        for (xx in floatArrayOf(a[0], a[1])) {
                            if (cam.project(xx, 0f, z0, tmp) && cam.project(xx, a[2], z0, tmp2)) {
                                val u0 = Offset(tmp[0], tmp[1]); val u1 = Offset(tmp2[0], tmp2[1])
                                items.add(D3Item(tmp[2] + 0.4f) { drawLine(shade(c.prop, 0.7f), u0, u1, strokeWidth = max(w * 0.8f, 2f)) })
                            }
                        }
                    }
                }
            }
            7 -> { // weight plate hanging from a belt at the pelvis
                if (cam.project(jx(J_PELVIS), jy(J_PELVIS), jz(J_PELVIS), tmp) &&
                    cam.project(jx(J_PELVIS), jy(J_PELVIS) - 0.30f, jz(J_PELVIS), tmp2)
                ) {
                    val s0 = Offset(tmp[0], tmp[1]); val s1 = Offset(tmp2[0], tmp2[1])
                    val r = 0.09f * cam.focal / tmp2[2]
                    items.add(D3Item(tmp2[2] - 0.2f) {
                        drawLine(Color(0.25f, 0.25f, 0.28f), s0, s1, strokeWidth = 3f)
                        sphere(s1, r, Color(0.22f, 0.23f, 0.27f))
                    })
                }
            }
            9 -> { // gymnastic rings that follow the hands: top, anchorHalfSpacing, ringOffsetY
                val top = a[0]; val az = a[1]; val off = a[2]
                val wrists = intArrayOf(J_WR_R, J_WR_L)
                val sides = floatArrayOf(1f, -1f)
                for (k in 0 until 2) {
                    val w = wrists[k]
                    val rx = jx(w); val ry = jy(w) + off; val rz = jz(w)
                    if (cam.project(rx, ry, rz, tmp) && cam.project(0f, top, sides[k] * az, tmp2)) {
                        val ring = Offset(tmp[0], tmp[1]); val anchor = Offset(tmp2[0], tmp2[1])
                        val r = 0.115f * cam.focal / tmp[2]
                        items.add(D3Item(tmp[2] - 0.05f) {
                            drawLine(c.rope, anchor, ring, strokeWidth = 4f)
                            drawCircle(c.prop, r, ring, style = Stroke(width = max(r * 0.18f, 2f)))
                        })
                    }
                }
            }
        }
    }

    // ---- the figure
    fun depthLight(z: Float): Float = 0.78f + 0.3f * (1f - ((z - near) / span).coerceIn(0f, 1f))
    fun cap(ja: Int, jb: Int, r: Float, base: Color, left: Boolean) {
        if (!cam.project(jx(ja), jy(ja), jz(ja), tmp) || !cam.project(jx(jb), jy(jb), jz(jb), tmp2)) return
        val a = Offset(tmp[0], tmp[1]); val b = Offset(tmp2[0], tmp2[1])
        val z = (tmp[2] + tmp2[2]) / 2f
        val col = shade(base, depthLight(z) * (if (left) 0.86f else 1f))
        val w = 2f * r * cam.focal / z
        items.add(D3Item(z) { capsule(a, b, w, col) })
    }
    fun ball(ji: Int, r: Float, base: Color, left: Boolean) {
        if (!cam.project(jx(ji), jy(ji), jz(ji), tmp)) return
        val p = Offset(tmp[0], tmp[1])
        val z = tmp[2]
        val col = shade(base, depthLight(z) * (if (left) 0.86f else 1f))
        val rr = r * cam.focal / z
        items.add(D3Item(z - 0.02f) { sphere(p, rr, col) })
    }

    cap(J_PELVIS, J_SPINE, 0.105f, c.pants, false)
    cap(J_SPINE, J_CHEST, 0.118f, c.cloth, false)
    cap(J_CHEST, J_HEAD, 0.045f, c.skin, false)
    ball(J_HEAD, 0.105f, c.skin, false)
    cap(J_CHEST, J_SH_L, 0.058f, c.cloth, true)
    cap(J_CHEST, J_SH_R, 0.058f, c.cloth, false)
    cap(J_PELVIS, J_HIP_L, 0.078f, c.pants, true)
    cap(J_PELVIS, J_HIP_R, 0.078f, c.pants, false)
    // left side first so the right limbs sit slightly in front when depth ties
    cap(J_SH_L, J_EL_L, 0.050f, c.cloth, true)
    cap(J_EL_L, J_WR_L, 0.040f, c.skin, true)
    cap(J_WR_L, J_HA_L, 0.034f, c.skin, true)
    cap(J_HIP_L, J_KN_L, 0.078f, c.pants, true)
    cap(J_KN_L, J_AN_L, 0.058f, c.pants, true)
    cap(J_AN_L, J_TO_L, 0.044f, c.shoe, true)
    cap(J_SH_R, J_EL_R, 0.050f, c.cloth, false)
    cap(J_EL_R, J_WR_R, 0.040f, c.skin, false)
    cap(J_WR_R, J_HA_R, 0.034f, c.skin, false)
    cap(J_HIP_R, J_KN_R, 0.078f, c.pants, false)
    cap(J_KN_R, J_AN_R, 0.058f, c.pants, false)
    cap(J_AN_R, J_TO_R, 0.044f, c.shoe, false)
    ball(J_EL_L, 0.046f, c.skin, true)
    ball(J_EL_R, 0.046f, c.skin, false)
    ball(J_KN_L, 0.066f, c.pants, true)
    ball(J_KN_R, 0.066f, c.pants, false)

    items.sortByDescending { it.z }
    for (it in items) it.draw(this)
}

// ---------------------------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------------------------

@Composable
private fun D3Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    TextButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        colors = ButtonDefaults.textButtonColors(
            containerColor = if (selected) cs.primaryContainer else Color.Transparent,
            contentColor = if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant
        )
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun D3Phase(text: String, active: Boolean) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(50),
        color = if (active) cs.primary else cs.surfaceVariant
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (active) cs.onPrimary else cs.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun Demo3DPlayer(skillName: String, demo: Demo3D, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val segs = remember(demo) { buildSchedule(demo) }
    val cycle = remember(demo) { segs.sumOf { it.dur.toDouble() }.toFloat() }
    var time by remember(demo) { mutableStateOf(0f) }
    var playing by remember(demo) { mutableStateOf(true) }
    var speed by remember(demo) { mutableStateOf(1f) }
    var viewIdx by remember(demo) { mutableStateOf(0) }
    var az by remember(demo) { mutableStateOf(demo.views[0].az) }
    var el by remember(demo) { mutableStateOf(demo.views[0].el) }
    val pose = remember(demo) { FloatArray(60) }

    LaunchedEffect(playing, speed, demo) {
        if (!playing) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000.0).toFloat().coerceIn(0f, 0.1f)
            last = now
            var t = time + dt * speed
            while (t >= cycle) t -= cycle
            time = t
        }
    }

    val colors = D3Colors(
        cloth = cs.primary,
        skin = Color(0xFFD9A47E),
        pants = Color(0xFF3F4C63),
        shoe = Color(0xFF22262E),
        floorLine = cs.onSurface.copy(alpha = 0.10f),
        prop = Color(0xFFB7791F),
        rope = Color(0xFF8A8F99)
    )
    val located = locate(segs, time)
    val phase = located.first.phase
    val description = skillName + " " + stringResource(R.string.demo3d_description_suffix)

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceVariant.copy(alpha = 0.45f)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.1f)
                    .semantics { contentDescription = description }
                    .pointerInput(demo) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            az -= drag.x * 0.45f
                            el = (el + drag.y * 0.3f).coerceIn(-8f, 88f)
                        }
                    }
            ) {
                val seg = located.first
                val f = seg.f0 + (seg.f1 - seg.f0) * located.second
                samplePose(demo, f, pose)
                val focal = (min(size.width, size.height) / 2f) / tan((FOV_HALF_DEG * PI / 180.0)).toFloat()
                val cam = Cam(az, el, demo.center[0], demo.center[1], demo.center[2], demo.radius,
                    size.width / 2f, size.height / 2f, focal)
                drawScene(demo, pose, cam, colors)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            D3Phase(stringResource(R.string.demo_start), phase == PH_START)
            D3Phase(stringResource(R.string.demo_movement), phase == PH_MOVE)
            D3Phase(stringResource(if (demo.hold) R.string.demo_hold else R.string.demo_end), phase == PH_END)
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.demo3d_camera), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                modifier = Modifier.padding(end = 4.dp))
            for (i in demo.views.indices) {
                D3Chip(demo.views[i].name, i == viewIdx) {
                    viewIdx = i
                    az = demo.views[i].az
                    el = demo.views[i].el
                }
            }
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { time = 0f; playing = true }) { Text(stringResource(R.string.demo_replay)) }
            TextButton(onClick = { playing = !playing }) {
                Text(stringResource(if (playing) R.string.demo_pause else R.string.demo_play))
            }
            Text(stringResource(R.string.demo3d_speed), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                modifier = Modifier.padding(start = 8.dp, end = 4.dp))
            D3Chip("0.25x", speed == 0.25f) { speed = 0.25f }
            D3Chip("0.5x", speed == 0.5f) { speed = 0.5f }
            D3Chip("1x", speed == 1f) { speed = 1f }
            D3Chip("1.5x", speed == 1.5f) { speed = 1.5f }
        }
    }
}

package com.calitree.app.data

enum class TreeId(val title: String, val tagline: String) {
    PUSH("Push", "Push-ups, dips and pressing strength"),
    PULL("Pull", "Rows, pull-ups, muscle-ups and one-arm pulls"),
    LEGS("Legs", "Squats, pistols, nordics and jumping"),
    CORE("Core", "Planks, L-sit, V-sit, dragon flag and manna"),
    HANDSTAND("Handstand", "Balance, presses and handstand push-ups"),
    LEVERS("Levers", "Front lever (left) and back lever (right)"),
    PLANCHE("Planche", "Lean, tuck, straddle and full planche"),
    FLAG("Human Flag", "Pole strength and the human flag"),
    RINGS("Rings", "Ring strength, support and ring muscle-ups")
}

data class Skill(
    val id: String,
    val tree: TreeId,
    val name: String,
    val difficulty: Int,
    val lane: Int,
    val prereqs: List<String>,
    val description: String,
    val requirement: String,
    val volume: String,
    val goal: String,
    val steps: List<String>,
    val tip: String
)

fun difficultyLabel(d: Int): String = when (d) {
    1 -> "Beginner"
    2 -> "Novice"
    3 -> "Intermediate"
    4 -> "Advanced"
    else -> "Elite"
}

fun levelTitle(completed: Int): String = when {
    completed < 5 -> "Newcomer"
    completed < 15 -> "Apprentice"
    completed < 35 -> "Athlete"
    completed < 65 -> "Advanced Athlete"
    completed < 100 -> "Master"
    else -> "Legend"
}

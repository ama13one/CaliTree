@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.TreeId
import com.calitree.app.data.levelTitle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProgressScreen(
    store: ProgressStore,
    onOpen: (String) -> Unit,
    onGoTree: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val all = SkillData.all
    val doneList = all
        .filter { store.isDone(it.id) }
        .sortedByDescending { store.completedAt[it.id] ?: 0L }
    val percent = doneList.size * 100 / all.size
    val recommended = all
        .filter { store.statusOf(it) == Status.AVAILABLE }
        .sortedBy { it.difficulty }
        .take(6)
    val dateFormat = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    val trees = TreeId.values().toList()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Progress",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "$percent% of the tree completed",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer
                    )
                    LinearProgressIndicator(
                        progress = { doneList.size.toFloat() / all.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Text(
                        "${doneList.size} of ${all.size} skills. Level: ${levelTitle(doneList.size)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }

        item { SectionTitle("Recommended next") }
        if (recommended.isEmpty()) {
            item {
                Text(
                    "Nothing available right now. Complete more prerequisites to unlock new skills.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(recommended, key = { "next_" + it.id }) { s ->
                SkillRow(s, store.statusOf(s), store.isFavorite(s.id), { onOpen(s.id) })
            }
        }

        item { SectionTitle("By tree") }
        itemsIndexed(trees, key = { _, t -> "tree_" + t.name }) { i, t ->
            val list = SkillData.inTree(t)
            val done = list.count { store.isDone(it.id) }
            Card(
                onClick = { onGoTree(i) },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.surface),
                border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            t.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "$done / ${list.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.onSurfaceVariant
                        )
                    }
                    LinearProgressIndicator(
                        progress = { done.toFloat() / list.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        item { SectionTitle("Completed (${doneList.size})") }
        if (doneList.isEmpty()) {
            item {
                Text(
                    "Nothing completed yet. Open a skill in the tree and tap Mark as completed.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(doneList, key = { "done_" + it.id }) { s ->
                val date = dateFormat.format(Date(store.completedAt[s.id] ?: 0L))
                SkillRow(s, Status.DONE, store.isFavorite(s.id), { onOpen(s.id) }, extra = date)
            }
        }
    }
}

@Composable
fun ProfileScreen(store: ProgressStore, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var confirmReset by remember { mutableStateOf(false) }
    val done = store.completed.size

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Profile",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (store.name.isBlank()) "Athlete" else store.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Level: " + levelTitle(done),
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.primary
                )
                Text(
                    "$done of ${SkillData.all.size} skills completed, ${store.favorites.size} favorites",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                if (store.goal.isNotBlank()) {
                    Text(
                        "Goal: " + store.goal,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        OutlinedTextField(
            value = store.name,
            onValueChange = { store.updateName(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Your name") }
        )
        OutlinedTextField(
            value = store.goal,
            onValueChange = { store.updateGoal(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Your goal, e.g. first muscle-up") }
        )

        SectionTitle("Appearance")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                FilterChip(
                    selected = store.themeMode == i,
                    onClick = { store.updateTheme(i) },
                    label = { Text(label) }
                )
            }
        }

        SectionTitle("Data")
        Text(
            "Everything is stored only on this phone. The app works fully offline.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
        OutlinedButton(onClick = { confirmReset = true }) {
            Text("Reset all progress")
        }

        SectionTitle("Training safety")
        Text(
            "Warm up before every session, build up slowly and stop if you feel sharp pain. " +
                "Wrists, elbows and shoulders need weeks to adapt to new skills. " +
                "This app gives general training guidance and is not medical advice. " +
                "If you have an injury or health condition, talk to a doctor or qualified coach first.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset progress?") },
            text = { Text("All completed skills will be cleared. Favorites and your profile are kept.") },
            confirmButton = {
                TextButton(onClick = {
                    store.resetProgress()
                    confirmReset = false
                }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            }
        )
    }
}

package com.calitree.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF05260F),
    primaryContainer = Color(0xFF14391F),
    onPrimaryContainer = Color(0xFFB7F5C8),
    secondary = Color(0xFF7DD3FC),
    tertiary = Color(0xFFFBBF24),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE6EAF0),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EAF0),
    surfaceVariant = Color(0xFF212833),
    onSurfaceVariant = Color(0xFFA7B0BE),
    outline = Color(0xFF3A4454)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF15803D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD1F5DC),
    onPrimaryContainer = Color(0xFF0B3D1B),
    secondary = Color(0xFF0369A1),
    tertiary = Color(0xFFD97706),
    background = Color(0xFFF5F7FA),
    onBackground = Color(0xFF12161C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF12161C),
    surfaceVariant = Color(0xFFE6EAF0),
    onSurfaceVariant = Color(0xFF4B5565),
    outline = Color(0xFFB3BCC9)
)

/** mode: 0 = follow system, 1 = light, 2 = dark */
@Composable
fun CaliTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content
    )
}

# 3D exercise demonstrations

The app plays back `app/src/main/assets/demo3d.bin` (about 380 KB for all 132 exercises). Nothing is downloaded and no
3D library is needed; the renderer is `app/src/main/java/com/calitree/app/ui/Demo3D.kt` (Jetpack Compose Canvas).

How it is built
- `rig.py`     20-joint skeleton, bone lengths of a 1.77 m athlete, analytic 2-bone IK for arms and legs.
- `h.py`       builders (push-up support, hangs, handstands, ...).
- `ex_*.py`    one file per skill tree. Every exercise is a list of key poses (start ... end) written as
               positions of hands, feet, pelvis and torso direction, so contacts (palms on the floor, hands on
               the bar, toes on the wall) stay put. Each exercise also lists its own camera angles and props.
- `motion.py`  baking (eased IK frames between key poses, with reach/contact checks).
- `build3d.py` writes the binary asset and fails if an exercise id is missing.
- `preview.py` / `t_gen.py`  contact sheets for review:  `python3 tools3d/t_gen.py push ex_push 12`

Rebuild after editing a pose:  `python3 tools3d/build3d.py`   (needs Python 3, numpy, matplotlib for previews)

World axes: +x = direction the athlete faces, +y up, +z = athlete's right side. Units: metres.

"""Registry + baking of exercise motions."""
import math
import numpy as np
from rig import solve, lerp_pose, JI, NJ

EX = {}
SIDE, FRONT, REAR, LEFT = 90, 0, 180, 270


def smooth(t):
    return t * t * (3 - 2 * t)


# prop helpers: (kind, six floats)
def bar(x, y, hw=0.6): return (1, x, y, hw, 0, 0, 0)
def wall(x): return (2, x, 0, 0, 0, 0, 0)
def box(x0, y0, z0, x1, y1, z1): return (3, x0, y0, z0, x1, y1, z1)
def rings(x, y, top=2.6, hs=0.26): return (4, x, y, top, hs, 0, 0)
def pole(x, z=0.0, h=2.4): return (5, x, z, h, 0, 0, 0)
def pbars(x0, x1, y, hs=0.28): return (6, x0, x1, y, hs, 0, 0)


def cam(name, az, el=12): return (name, az, el)


STEPS = 16


def reg(id, keys, props=(), views=((("Side", 90, 10)),), hold=False, loop=False, durs=None, steps=STEPS, rdurs=None):
    nseg = len(keys) - 1
    durs = list(durs) if durs else [1.0] * nseg
    if len(durs) == 1 and nseg > 1:
        durs = durs * nseg
    assert len(durs) == nseg, (id, len(durs), nseg)
    rdurs = list(rdurs) if rdurs else list(durs)
    if len(rdurs) == 1 and nseg > 1:
        rdurs = rdurs * nseg
    assert len(rdurs) == nseg, (id, "rdurs")
    frames, key_idx, warns = [], [0], []
    for i in range(nseg):
        for s in range(steps):
            t = smooth(s / steps)
            frames.append(lerp_pose(keys[i], keys[i + 1], t))
        key_idx.append((i + 1) * steps)
    frames.append(keys[-1])
    J, miny = [], 0.0
    for fi, q in enumerate(frames):
        j, w = solve(q)
        J.append(j)
        if fi in key_idx:
            warns += ["key%d %s" % (key_idx.index(fi), x) for x in w]
    J = np.array(J)
    EX[id] = dict(id=id, keys=keys, props=list(props), views=list(views), hold=hold, loop=loop,
                  durs=durs, rdurs=rdurs, frames=J, key_idx=key_idx, warns=warns,
                  miny=float(J[:, [JI["toR"], JI["toL"], JI["haR"], JI["haL"], JI["anR"], JI["anL"]], 1].min()))

"""Shared builders for the exercise files."""
import math
import numpy as np
from rig import *          # noqa
from motion import *       # noqa

SIDE_V = ("Side", 90, 8)
FRONT_V = ("Front", 0, 8)
REAR_V = ("Rear", 180, 8)
TQ = ("3/4 front", 50, 16)
TQB = ("3/4 rear", 130, 16)
TOP = ("Top", 0, 78)
LEFT_V = ("Left side", 270, 8)
SIDE_HI = ("Side", 90, 22)


def HS(x, y, z):
    return dict(hr=V(x, y, z), hl=V(x, y, -z))


def FS(x, y, z):
    return dict(fr=V(x, y, z), fl=V(x, y, -z))


def dg(x):
    return math.degrees(x)


def th_for(Fy, Sy):
    """Body angle (deg above +x) of a straight body pivoting on an ankle at height Fy
    so that the shoulders are at height Sy."""
    return dg(math.asin(max(-1.0, min(1.0, (Sy - Fy) / (LEG + TORSO)))))


def fit_toes(q, toe_y=0.02, sides="rl"):
    """Set plantar flexion so the toes just touch the floor (toe_y)."""
    for k in sides:
        best = None
        for pf in np.arange(0, 88, 1.0):
            q2 = dict(q)
            q2["pf" + k] = float(pf)
            J, _ = solve(q2)
            e = abs(J[JI["to" + k.upper()], 1] - toe_y)
            if best is None or e < best[0]:
                best = (e, pf)
        q["pf" + k] = float(best[1])
    return q


def sup(Fx, Fy, th, hx, hy, hz, feet_z=0.10, er=(-1, 0.35, 0.45), toes=True, hw=1.0, **kw):
    dz = max(0.0, feet_z - HIP_HALF)
    delta = LEG - math.sqrt(LEG * LEG - dz * dz)      # wide feet: ankles sit a little closer to the hips
    d = V(math.cos(math.radians(th)), math.sin(math.radians(th)), 0)
    fx, fy = V(Fx, Fy, 0) + d * delta, None
    q = line_pose(V(Fx, Fy, 0), th, er=V(*er), el=V(*er), hwr=hw, hwl=hw,
                  **HS(hx, hy, hz), fr=fx + V(0, 0, feet_z), fl=fx + V(0, 0, -feet_z), **kw)
    return fit_toes(q) if toes else q


def pushup_keys(Fy=0.25, hy=0.05, hz=0.25, dnS=0.21, hand_dx=-0.04, er=(-1, 0.35, 0.45),
                Fx=0.0, feet_z=0.10, **kw):
    dy = math.sqrt((ARM * 0.985) ** 2 - hand_dx ** 2 - (hz - SH_HALF) ** 2)
    th_up = th_for(Fy, hy + dy)
    S = shoulder_of(line_pose(V(Fx, Fy, 0), th_up))
    hx = S[0] + hand_dx
    top = sup(Fx, Fy, th_up, hx, hy, hz, feet_z=feet_z, er=er, **kw)
    bot = sup(Fx, Fy, th_for(Fy, dnS), hx, hy, hz, feet_z=feet_z, er=er, **kw)
    return top, bot, hx


def stand(x=0.0, **kw):
    d = dict(p=V(x, HIP_Y, 0), **FS(x, ANKLE_H, 0.10), flr=1, fll=1,
             hr=V(x, SH_Y - ARM + 0.02, 0.26), hl=V(x, SH_Y - ARM + 0.02, -0.26))
    d.update(kw)
    return P(**d)


def hang_pose(bx, by, Sy, grip=0.28, ta=90, **kw):
    """Hanging from a bar at (bx, by): wrists just under the bar, shoulder centre at height Sy
    (shoulder x follows the wrist x unless p / ta say otherwise)."""
    return None


def fix_hang(q, bx, by, grip):
    q["hr"] = V(bx, by - 0.075, grip)
    q["hl"] = V(bx, by - 0.075, -grip)
    return q


def pose_from_shoulder(S, ta, **kw):
    """Pose whose shoulder-centre is at S (straight spine) for torso angle ta."""
    t = math.radians(ta)
    u = V(math.cos(t), math.sin(t), 0)
    yaw = kw.get("yaw", 0.0)
    u2 = rot(u, Y, yaw)
    return P(p=S - TORSO * u2, ta=ta, **kw)


def hang_body(bx, by, grip, Sy, ta=90, legs=None, sx=None, **kw):
    """Generic hang: shoulders at (sx or bx, Sy); legs dict of ankle targets or None (straight down)."""
    sx = bx if sx is None else sx
    q = pose_from_shoulder(V(sx, Sy, 0), ta, **kw)
    fix_hang(q, bx, by, grip)
    return q


def dir_pt(origin, ang, dist):
    t = math.radians(ang)
    return origin + dist * V(math.cos(t), math.sin(t), 0)


def reach_arms(q, off=(0.5, 0.0, 0.0), z=0.19, er=(0, -1, 0.3), hw=0.0):
    """Wrists at a fixed offset from the shoulder centre (arms raised forward etc.)."""
    S = shoulder_of(q)
    o = V(*off)
    q["hr"] = S + o + V(0, 0, z)
    q["hl"] = S + o + V(0, 0, -z)
    q["er"] = V(*er); q["el"] = V(*er)
    q["hwr"] = q["hwl"] = hw
    return q


def stand_on(q, ax, ay, zr=0.10, zl=-0.10, flat=1.0):
    q.update(fr=V(ax, ay, zr), fl=V(ax, ay, zl), flr=flat, fll=flat)
    return q


# ---- floor / lying / support builders used by core, levers, planche ----
def lying_back(shx=0.0, shy=0.11, hip_lift=0.0, **kw):
    """Supine, head toward -x, shoulders on the floor, spine straight; hip_lift = hip height above floor."""
    py = 0.11 + hip_lift
    q = P(p=V(shx + TORSO, py, 0), ta=180.0, **kw)
    return q


def set_leg_dir(q, ang, z=0.07, pf=40, knee=(0, 1, 0.05), scale=0.998, side="both"):
    """Straight legs from the pelvis at ang degrees above +x (0 = along floor toward the feet, 90 = up)."""
    a = math.radians(ang)
    t = q["p"] + LEG * scale * V(math.cos(a), math.sin(a), 0)
    q.update(fr=t + V(0, 0, z), fl=t - V(0, 0, z), pfr=pf, pfl=pf, flr=0, fll=0, kr=V(*knee), kl=V(*knee))
    return q


def hands_floor(q, x, y=0.04, z=0.24, er=(-1, 0.3, 0.5), hw=1.0):
    q.update(hr=V(x, y, z), hl=V(x, y, -z), er=V(*er), el=V(*er), hwr=hw, hwl=hw)
    return q


# ---- inverted (handstand family) builders ----
def circ_hip(S, A, upper=True, leg_frac=0.995):
    """Hip centre (xy-plane) that keeps the torso length from S and straight legs to ankle A."""
    sx, sy, ax, ay = S[0], S[1], A[0], A[1]
    L = LEG * leg_frac
    dx, dy = ax - sx, ay - sy
    d = math.hypot(dx, dy)
    a = (TORSO ** 2 - L ** 2 + d * d) / (2 * d)
    hh = math.sqrt(max(0.0, TORSO ** 2 - a * a))
    bx, by = sx + a * dx / d, sy + a * dy / d
    nx, ny = -dy / d, dx / d
    c1, c2 = (bx + hh * nx, by + hh * ny), (bx - hh * nx, by - hh * ny)
    c = c1 if ((c1[1] > c2[1]) == upper) else c2
    return V(c[0], c[1], 0.0)


def pose_pa(S, A, z=0.0, **kw):
    """Straight legs from ankle A to hip, torso length to shoulder S."""
    p = circ_hip(S, A)
    ta = math.degrees(math.atan2(S[1] - p[1], S[0] - p[0]))
    return P(p=p + V(0, 0, z), ta=ta % 360, **kw)


def hs_pose(hx=0.0, Sy=None, lam=0.0, sz=0.0, strad=0.0, hy=0.04, hz=0.20, shup=0.05, neck=-8,
            lift_r=0.0, lift_l=0.0, hdx=0.0, er=(1, 0.1, 0.4), pf=65, sx=None, hwid=0.06, slead=0.0):
    """Handstand: hands on the floor at x=hx, body line tilted lam degrees (feet toward +x)."""
    Sy = hy + ARM * 0.985 + shup if Sy is None else Sy
    sx = hx if sx is None else sx
    S = V(sx, Sy, sz)
    d = V(math.sin(math.radians(lam)), math.cos(math.radians(lam)), 0)
    q = P(p=S + TORSO * d, ta=270.0 - lam, shup=shup, neck=neck, er=V(*er), el=V(*er))
    q["hr"] = V(hx + hdx, hy + lift_r, hz); q["hl"] = V(hx + hdx, hy + lift_l, -hz)
    q["hwr"] = q["hwl"] = 1.0
    a = math.radians(strad)
    t = q["p"] + LEG * 0.995 * V(d[0], d[1], 0)
    if strad > 0:
        dr = V(d[0] * math.cos(a), d[1] * math.cos(a), math.sin(a)); dl = V(dr[0], dr[1], -dr[2])
        q["fr"] = q["p"] + LEG * 0.995 * dr + V(0, 0, 0); q["fl"] = q["p"] + LEG * 0.995 * dl
    else:
        q["fr"] = t + V(0, 0, hwid); q["fl"] = t + V(0, 0, -hwid)
    q.update(pfr=pf, pfl=pf, flr=0, fll=0, kr=V(-1, 0, 0.1), kl=V(-1, 0, 0.1))
    return q

@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.TreeId
import com.calitree.app.data.levelTitle

@Composable
fun ProgressScreen(
    store: ProgressStore,
    onOpen: (String) -> Unit,
    onGoTree: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val all = SkillData.all
    val doneList = all
        .filter { store.isDone(it.id) }
        .sortedByDescending { store.completedAt[it.id] ?: 0L }
    val percent = doneList.size * 100 / all.size
    val recommended = all
        .filter { store.statusOf(it) == Status.AVAILABLE }
        .sortedBy { it.difficulty }
        .take(6)
    val trees = TreeId.values().toList()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "پیشرفت",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        fa(percent) + "٪ از درخت تکمیل شده",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer
                    )
                    LinearProgressIndicator(
                        progress = { doneList.size.toFloat() / all.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Text(
                        fa(doneList.size) + " از " + fa(all.size) + " مهارت. سطح: " + levelTitle(doneList.size),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }

        item { SectionTitle("پیشنهاد بعدی") }
        if (recommended.isEmpty()) {
            item {
                Text(
                    "فعلاً چیزی در دسترس نیست. با تکمیل پیش‌نیازهای بیشتر مهارت‌های جدید باز می‌شوند.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(recommended, key = { "next_" + it.id }) { s ->
                SkillRow(s, store.statusOf(s), store.isFavorite(s.id), { onOpen(s.id) })
            }
        }

        item { SectionTitle("بر اساس درخت") }
        itemsIndexed(trees, key = { _, t -> "tree_" + t.name }) { i, t ->
            val list = SkillData.inTree(t)
            val done = list.count { store.isDone(it.id) }
            Card(
                onClick = { onGoTree(i) },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.surface),
                border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            t.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            fa(done) + " / " + fa(list.size),
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.onSurfaceVariant
                        )
                    }
                    LinearProgressIndicator(
                        progress = { done.toFloat() / list.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        item { SectionTitle("تکمیل‌شده‌ها (" + fa(doneList.size) + ")") }
        if (doneList.isEmpty()) {
            item {
                Text(
                    "هنوز چیزی تکمیل نشده است. یک مهارت را در درخت باز کنید و «علامت‌گذاری به‌عنوان تکمیل‌شده» را بزنید.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(doneList, key = { "done_" + it.id }) { s ->
                val date = faDate(store.completedAt[s.id] ?: 0L)
                SkillRow(s, Status.DONE, store.isFavorite(s.id), { onOpen(s.id) }, extra = date)
            }
        }
    }
}

@Composable
fun ProfileScreen(store: ProgressStore, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var confirmReset by remember { mutableStateOf(false) }
    val done = store.completed.size

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "پروفایل",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (store.name.isBlank()) "ورزشکار" else store.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "سطح: " + levelTitle(done),
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.primary
                )
                Text(
                    fa(done) + " از " + fa(SkillData.all.size) + " مهارت تکمیل شده، " + fa(store.favorites.size) + " علاقه‌مندی",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                if (store.goal.isNotBlank()) {
                    Text(
                        "هدف: " + store.goal,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        OutlinedTextField(
            value = store.name,
            onValueChange = { store.updateName(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("نام شما") }
        )
        OutlinedTextField(
            value = store.goal,
            onValueChange = { store.updateGoal(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("هدف شما، مثلاً اولین ماسل‌آپ") }
        )

        SectionTitle("ظاهر")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("سیستم", "روشن", "تاریک").forEachIndexed { i, label ->
                FilterChip(
                    selected = store.themeMode == i,
                    onClick = { store.updateTheme(i) },
                    label = { Text(label) }
                )
            }
        }

        SectionTitle("داده‌ها")
        Text(
            "همه‌چیز فقط روی همین گوشی ذخیره می‌شود. برنامه کاملاً آفلاین کار می‌کند.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
        OutlinedButton(onClick = { confirmReset = true }) {
            Text("بازنشانی همه‌ی پیشرفت")
        }

        SectionTitle("ایمنی تمرین")
        Text(
            "پیش از هر جلسه بدن را گرم کنید، آهسته پیشرفت کنید و با احساس درد تیز متوقف شوید. " +
                "مچ‌ها، آرنج‌ها و شانه‌ها برای سازگاری با مهارت‌های جدید به هفته‌ها زمان نیاز دارند. " +
                "این برنامه راهنمایی عمومی تمرین می‌دهد و توصیه‌ی پزشکی نیست. " +
                "اگر آسیب‌دیدگی یا بیماری دارید، ابتدا با پزشک یا مربی مجرب مشورت کنید.",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("پیشرفت بازنشانی شود؟") },
            text = { Text("همه‌ی مهارت‌های تکمیل‌شده پاک می‌شوند. علاقه‌مندی‌ها و پروفایل شما حفظ می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    store.resetProgress()
                    confirmReset = false
                }) { Text("بازنشانی") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("انصراف") }
            }
        )
    }
}

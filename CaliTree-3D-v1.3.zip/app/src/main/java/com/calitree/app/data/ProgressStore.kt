package com.calitree.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Status { DONE, AVAILABLE, LOCKED }

/** Saves everything on the phone (SharedPreferences). Works fully offline. */
class ProgressStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("calitree_progress", Context.MODE_PRIVATE)

    var completedAt: Map<String, Long> by mutableStateOf(readDates())
        private set
    var favorites: Set<String> by mutableStateOf(readSet("favorites"))
        private set
    var name: String by mutableStateOf(prefs.getString("name", "") ?: "")
        private set
    var motivation: String by mutableStateOf(prefs.getString("motivation", "") ?: "")
        private set
    var onboardingComplete: Boolean by mutableStateOf(prefs.getBoolean("onboarding_complete", false))
        private set
    /** Default exercise view: 0 = 2D, 1 = 3D. */
    var demoMode: Int by mutableStateOf(prefs.getInt("demo_mode", 0).coerceIn(0, 1))
        private set
    var themeMode: Int by mutableStateOf(prefs.getInt("theme", 0))
        private set

    val completed: Set<String> get() = completedAt.keys

    private fun readSet(key: String): Set<String> =
        (prefs.getStringSet(key, emptySet()) ?: emptySet()).toSet()

    private fun readDates(): Map<String, Long> {
        val result = HashMap<String, Long>()
        for (entry in readSet("completed")) {
            val i = entry.lastIndexOf('=')
            if (i > 0) {
                result[entry.substring(0, i)] = entry.substring(i + 1).toLongOrNull() ?: 0L
            }
        }
        return result
    }

    fun isDone(id: String): Boolean = completedAt.containsKey(id)

    fun isFavorite(id: String): Boolean = favorites.contains(id)

    fun statusOf(skill: Skill): Status = when {
        isDone(skill.id) -> Status.DONE
        skill.prereqs.all { isDone(it) } -> Status.AVAILABLE
        else -> Status.LOCKED
    }

    fun toggleDone(id: String) {
        val map = completedAt.toMutableMap()
        if (map.containsKey(id)) map.remove(id) else map[id] = System.currentTimeMillis()
        // The check mark is shown only after the new state was written to storage successfully.
        val saved = prefs.edit()
            .putStringSet("completed", map.map { "${it.key}=${it.value}" }.toSet())
            .commit()
        if (saved) completedAt = map
    }

    fun toggleFavorite(id: String) {
        val set = favorites.toMutableSet()
        if (!set.add(id)) set.remove(id)
        favorites = set
        prefs.edit().putStringSet("favorites", set).apply()
    }

    fun updateName(value: String) {
        name = value
        prefs.edit().putString("name", value).apply()
    }

    fun completeOnboarding(userName: String, userMotivation: String) {
        name = userName.trim()
        motivation = userMotivation.trim()
        onboardingComplete = true
        prefs.edit()
            .putString("name", name)
            .putString("motivation", motivation)
            .putBoolean("onboarding_complete", true)
            .apply()
    }

    fun updateMotivation(value: String) {
        motivation = value
        prefs.edit().putString("motivation", value).apply()
    }

    fun updateDemoMode(mode: Int) {
        demoMode = mode.coerceIn(0, 1)
        prefs.edit().putInt("demo_mode", demoMode).apply()
    }

    fun updateTheme(mode: Int) {
        themeMode = mode
        prefs.edit().putInt("theme", mode).apply()
    }

    fun resetProgress() {
        completedAt = emptyMap()
        prefs.edit().putStringSet("completed", emptySet()).apply()
    }
}

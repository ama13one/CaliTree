@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.calitree.app.R
import com.calitree.app.data.DemoData
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.difficultyLabel

@Composable
fun SkillDetailScreen(
    skillId: String,
    store: ProgressStore,
    onBack: () -> Unit,
    onOpen: (String) -> Unit
) {
    val skill = SkillData.byId[skillId]
    if (skill == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val cs = MaterialTheme.colorScheme
    val status = store.statusOf(skill)
    val favorite = store.isFavorite(skill.id)
    val previous = skill.prereqs.mapNotNull { SkillData.byId[it] }
    val next = SkillData.nextOf(skill.id)
    val missing = previous.filter { !store.isDone(it.id) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(skill.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = { store.toggleFavorite(skill.id) }) {
                        Icon(
                            if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (favorite) "حذف از علاقه‌مندی‌ها" else "افزودن به علاقه‌مندی‌ها",
                            tint = if (favorite) cs.tertiary else cs.onSurfaceVariant
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { store.toggleDone(skill.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(52.dp),
                    colors = if (status == Status.DONE) {
                        ButtonDefaults.filledTonalButtonColors()
                    } else {
                        ButtonDefaults.buttonColors()
                    }
                ) {
                    Text(
                        when (status) {
                            Status.DONE -> "تکمیل شده است. برای لغو بزنید"
                            Status.LOCKED -> "با این حال تکمیل‌شده علامت بزن"
                            Status.AVAILABLE -> "علامت‌گذاری به‌عنوان تکمیل‌شده"
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            val demo = DemoData.forId(skill.id)
            val appContext = androidx.compose.ui.platform.LocalContext.current
            val demo3d = androidx.compose.runtime.remember(skill.id) { Demo3DStore.get(appContext, skill.id) }
            if (demo3d != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Demo3DPlayer(skillName = skill.name, demo = demo3d)
                    Text(
                        stringResource(R.string.demo3d_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant
                    )
                }
            } else if (demo != null) {
                // Fallback to the original 2D demonstration if the 3D asset is missing.
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DemoPlayer(skillName = skill.name, demo = demo)
                    Text(
                        stringResource(R.string.demo_side_view_note),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    "درخت " + skill.tree.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.secondary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.width(12.dp))
                // Difficulty color badge. It does not change when the exercise is completed.
                DifficultyBadge(skill.difficulty, 22.dp)
                Spacer(Modifier.width(6.dp))
                Text(
                    difficultyLabel(skill.difficulty),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
            }
            DifficultyLegend()

            Surface(
                shape = RoundedCornerShape(50),
                color = when (status) {
                    Status.DONE -> cs.primaryContainer
                    Status.AVAILABLE -> cs.surfaceVariant
                    Status.LOCKED -> cs.surfaceVariant
                }
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    StatusIcon(status, Modifier.height(18.dp).width(18.dp))
                    Text(
                        "  " + when (status) {
                            Status.DONE -> "تکمیل‌شده"
                            Status.AVAILABLE -> "آماده‌ی تمرین"
                            Status.LOCKED -> "قفل‌شده"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            if (status == Status.LOCKED) {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.surfaceVariant) {
                    Text(
                        "ابتدا این‌ها را تکمیل کنید: " + missing.joinToString("، ") { it.name } +
                            ". اگر این مهارت را از قبل دارید، می‌توانید آن را تکمیل‌شده علامت بزنید.",
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Section("درباره‌ی تمرین") {
                Text(skill.description, style = MaterialTheme.typography.bodyLarge)
            }

            Section("پیش از شروع") {
                Text(skill.requirement, style = MaterialTheme.typography.bodyLarge)
            }

            Section("حجم تمرین") {
                Text(skill.volume, style = MaterialTheme.typography.bodyLarge)
            }

            Section("روش اجرا") {
                skill.steps.forEachIndexed { i, step ->
                    Row {
                        Text(
                            fa(i + 1) + ".",
                            modifier = Modifier.width(26.dp),
                            fontWeight = FontWeight.Bold,
                            color = cs.primary
                        )
                        Text(step, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            if (demo != null && demo.formTips.isNotEmpty()) {
                Section(stringResource(R.string.section_form_tips)) {
                    demo.formTips.forEach { BulletText(it) }
                }
            }

            if (demo != null && demo.commonMistakes.isNotEmpty()) {
                Section(stringResource(R.string.section_mistakes)) {
                    demo.commonMistakes.forEach { BulletText(it) }
                }
            }

            Section("معیار پیشروی") {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.primaryContainer) {
                    Text(
                        skill.goal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onPrimaryContainer,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Section("نکته‌ی مربی") {
                Text(skill.tip, style = MaterialTheme.typography.bodyLarge)
            }

            Section("پیش‌نیاز (مرحله‌ی قبل)") {
                if (previous.isEmpty()) {
                    Text(
                        "ندارد. این نقطه‌ی شروع این مسیر است.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    previous.forEach { p ->
                        SkillRow(p, store.statusOf(p), store.isFavorite(p.id), { onOpen(p.id) })
                    }
                }
            }

            Section("مرحله‌ی بعد") {
                if (next.isEmpty()) {
                    Text(
                        "ندارد. این بالاترین مرحله‌ی این مسیر است.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    next.forEach { n ->
                        SkillRow(n, store.statusOf(n), store.isFavorite(n.id), { onOpen(n.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun BulletText(text: String) {
    Row {
        Text(
            "•",
            modifier = Modifier.width(18.dp),
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

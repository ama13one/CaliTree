package com.calitree.app.ui

import android.content.ActivityNotFoundException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.calitree.app.audio.MusicPlayerViewModel
import com.calitree.app.audio.PlayState

/**
 * Music player card of the profile screen. The audio file is chosen with the system document picker
 * (OpenDocument), so the app needs no storage permission at all.
 */
@Composable
fun MusicCard(music: MusicPlayerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) music.select(uri)
    }
    val state = music.state
    val tight = PaddingValues(horizontal = 6.dp, vertical = 8.dp)

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("موسیقی")

            if (state == PlayState.NO_FILE) {
                Text(
                    "هنوز آهنگی انتخاب نشده است. یک فایل صوتی از حافظه‌ی گوشی انتخاب کنید.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            } else {
                Text(
                    music.fileName ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    when {
                        music.loading -> "در حال آماده‌سازی…"
                        state == PlayState.PLAYING -> "در حال پخش"
                        state == PlayState.PAUSED -> "متوقف‌شده (مکث)"
                        state == PlayState.ERROR -> "پخش نشد"
                        else -> "آماده‌ی پخش"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = if (state == PlayState.ERROR) cs.error else cs.primary
                )
            }

            music.error?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = cs.error)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { music.play() },
                    modifier = Modifier.weight(1f),
                    enabled = state == PlayState.STOPPED || state == PlayState.PAUSED || state == PlayState.ERROR,
                    contentPadding = tight
                ) { Text("پخش", maxLines = 1) }
                FilledTonalButton(
                    onClick = { music.pause() },
                    modifier = Modifier.weight(1f),
                    enabled = state == PlayState.PLAYING,
                    contentPadding = tight
                ) { Text("توقف موقت", maxLines = 1) }
                FilledTonalButton(
                    onClick = { music.stop() },
                    modifier = Modifier.weight(1f),
                    enabled = state == PlayState.PLAYING || state == PlayState.PAUSED,
                    contentPadding = tight
                ) { Text("توقف", maxLines = 1) }
            }

            OutlinedButton(
                onClick = {
                    try {
                        picker.launch(arrayOf("audio/*"))
                    } catch (e: ActivityNotFoundException) {
                        music.reportError("برنامه‌ی انتخاب فایل در این گوشی پیدا نشد.")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (state == PlayState.NO_FILE) "انتخاب فایل صوتی" else "تغییر آهنگ") }

            Text(
                "فقط فایل انتخاب‌شده خوانده می‌شود و هیچ مجوز اضافه‌ای لازم نیست. با خروج از برنامه، پخش متوقف می‌شود.",
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore

private const val MAX_NAME = 30
private const val MAX_GOAL = 60
private const val MAX_MOTIVATION = 140

/** Dedicated settings screen: appearance, display name / goal / motivational text, and data. */
@Composable
fun SettingsScreen(store: ProgressStore, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val focus = LocalFocusManager.current
    var confirmReset by remember { mutableStateOf(false) }

    // Drafts: reset to the stored value whenever it changes (e.g. right after saving).
    var name by rememberSaveable(store.name) { mutableStateOf(store.name) }
    var goal by rememberSaveable(store.goal) { mutableStateOf(store.goal) }
    var motivation by rememberSaveable(store.motivation) { mutableStateOf(store.motivation) }
    var justSaved by remember { mutableStateOf(false) }
    val dirty = name.trim() != store.name || goal.trim() != store.goal || motivation.trim() != store.motivation

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingsCard("ظاهر") {
                Text(
                    "حالت نمایش برای همه‌ی صفحه‌های برنامه اعمال می‌شود و بعد از بستن برنامه هم حفظ می‌شود.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("مطابق سیستم", "روشن", "تاریک").forEachIndexed { i, label ->
                        FilterChip(
                            selected = store.themeMode == i,
                            onClick = { store.updateTheme(i) },
                            label = { Text(label, maxLines = 1) }
                        )
                    }
                }
            }

            SettingsCard("شخصی‌سازی") {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(MAX_NAME); justSaved = false },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("نام نمایشی") }
                )
                OutlinedTextField(
                    value = goal,
                    onValueChange = { goal = it.take(MAX_GOAL); justSaved = false },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("هدف شما، مثلاً اولین ماسل‌آپ") }
                )
                OutlinedTextField(
                    value = motivation,
                    onValueChange = { motivation = it.take(MAX_MOTIVATION); justSaved = false },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 4,
                    label = { Text("متن انگیزشی") },
                    supportingText = {
                        Text("اگر خالی بماند، متن پیش‌فرض نمایش داده می‌شود. " + fa(motivation.length) + " / " + fa(MAX_MOTIVATION))
                    }
                )
                Button(
                    onClick = {
                        store.updateName(name.trim())
                        store.updateGoal(goal.trim())
                        store.updateMotivation(motivation.trim())
                        focus.clearFocus()
                        justSaved = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = dirty
                ) { Text("ذخیره") }
                if (justSaved && !dirty) {
                    Text("ذخیره شد.", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                }
            }

            SettingsCard("داده‌ها") {
                Text(
                    "همه‌چیز فقط روی همین گوشی ذخیره می‌شود. برنامه کاملاً آفلاین کار می‌کند.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                OutlinedButton(onClick = { confirmReset = true }) {
                    Text("بازنشانی همه‌ی پیشرفت")
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("پیشرفت بازنشانی شود؟") },
            text = { Text("همه‌ی مهارت‌های تکمیل‌شده پاک می‌شوند. علاقه‌مندی‌ها و پروفایل شما حفظ می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    store.resetProgress()
                    confirmReset = false
                }) { Text("بازنشانی") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("انصراف") }
            }
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle(title)
            content()
        }
    }
}

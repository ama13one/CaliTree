package com.calitree.app.audio

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

enum class PlayState { NO_FILE, STOPPED, PLAYING, PAUSED, ERROR }

/**
 * Plays ONE audio file the user picked with the system file picker (ActivityResultContracts.OpenDocument, so no
 * storage permission is needed). It lives in a ViewModel: playback survives screen changes and rotation, and the
 * MediaPlayer is released on stop, on completion, on any error and when the activity is finished (onCleared).
 * Without a foreground service the music is paused when the app goes to the background.
 */
class MusicPlayerViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("calitree_music", Context.MODE_PRIVATE)
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    var state: PlayState by mutableStateOf(PlayState.NO_FILE)
        private set
    var fileName: String? by mutableStateOf(null)
        private set
    var error: String? by mutableStateOf(null)
        private set
    /** True while the file is being opened (between pressing Play and the first sound). */
    var loading: Boolean by mutableStateOf(false)
        private set

    private var uri: Uri? = null
    private var player: MediaPlayer? = null
    private var preparing = false
    private var startWhenPrepared = false
    private var focusRequest: AudioFocusRequest? = null

    private val attrs = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause()
    }

    init {
        restore()
    }

    // ---------------------------------------------------------------- selection
    /** Restores the track chosen in an earlier session, if the file can still be opened. */
    private fun restore() {
        val saved = prefs.getString("uri", null) ?: return
        val u = Uri.parse(saved)
        if (canOpen(u)) {
            uri = u
            fileName = prefs.getString("name", null) ?: displayName(u)
            state = PlayState.STOPPED
        } else {
            prefs.edit().remove("uri").remove("name").apply()
            error = "فایل آهنگ قبلی دیگر در دسترس نیست. یک فایل دیگر انتخاب کنید."
        }
    }

    /** Called with the document returned by the file picker. A bad pick leaves the previous track untouched. */
    fun select(picked: Uri) {
        val type = try { app.contentResolver.getType(picked) } catch (e: Exception) { null }
        if (type != null && !type.startsWith("audio/") && type != "application/ogg") {
            error = "فایل انتخاب‌شده صوتی نیست."
            return
        }
        if (!canOpen(picked)) {
            error = "این فایل باز نشد. فایل دیگری انتخاب کنید."
            return
        }
        try {
            app.contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Some providers do not offer persistable access: the track still plays in this session.
        }
        val old = uri
        releasePlayer()
        if (old != null && old != picked) {
            try {
                app.contentResolver.releasePersistableUriPermission(old, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
        }
        uri = picked
        fileName = displayName(picked)
        error = null
        state = PlayState.STOPPED
        prefs.edit().putString("uri", picked.toString()).putString("name", fileName).apply()
    }

    fun reportError(message: String) {
        error = message
    }

    private fun canOpen(u: Uri): Boolean = try {
        val fd = app.contentResolver.openFileDescriptor(u, "r")
        fd?.close()
        fd != null
    } catch (e: Exception) {
        false
    }

    private fun displayName(u: Uri): String {
        try {
            app.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) {
                        val n = c.getString(i)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment?.substringAfterLast('/') ?: "آهنگ"
    }

    // ---------------------------------------------------------------- controls
    fun play() {
        val u = uri ?: return
        if (state == PlayState.NO_FILE || state == PlayState.PLAYING) return
        error = null
        val p = player
        if (state == PlayState.PAUSED && p != null) {
            if (preparing) {
                startWhenPrepared = true
            } else {
                try {
                    requestFocus()
                    p.start()
                } catch (e: IllegalStateException) {
                    fail("پخش ادامه پیدا نکرد. دوباره تلاش کنید.")
                    return
                }
            }
            state = PlayState.PLAYING
            return
        }
        startNew(u)
    }

    private fun startNew(u: Uri) {
        releasePlayer()
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(attrs)
            mp.setOnPreparedListener { m ->
                if (player === m) {
                    preparing = false
                    loading = false
                    if (startWhenPrepared) {
                        try {
                            m.start()
                        } catch (e: IllegalStateException) {
                            fail("پخش شروع نشد. دوباره تلاش کنید.")
                        }
                    }
                }
            }
            mp.setOnCompletionListener { m ->
                if (player === m) {
                    releasePlayer()
                    state = PlayState.STOPPED
                }
            }
            mp.setOnErrorListener { m, what, extra ->
                if (player === m) fail(messageFor(what, extra))
                true
            }
            mp.setDataSource(app, u)
            preparing = true
            startWhenPrepared = true
            loading = true
            state = PlayState.PLAYING
            requestFocus()
            mp.prepareAsync()
        } catch (e: java.io.FileNotFoundException) {
            fail("فایل پیدا نشد. ممکن است جابه‌جا یا حذف شده باشد.")
        } catch (e: SecurityException) {
            fail("دسترسی به این فایل از بین رفته است. دوباره آن را انتخاب کنید.")
        } catch (e: Exception) {
            fail("این فایل پخش نشد. قالب آن ممکن است پشتیبانی نشود.")
        }
    }

    fun pause() {
        if (state != PlayState.PLAYING) return
        startWhenPrepared = false
        try {
            if (!preparing) player?.pause()
        } catch (e: IllegalStateException) {
            fail("توقف موقت انجام نشد.")
            return
        }
        state = PlayState.PAUSED
    }

    fun stop() {
        if (uri == null) return
        releasePlayer()
        error = null
        state = PlayState.STOPPED
    }

    /** The app has no foreground service, so the music must not keep running unseen: pause it. */
    fun pauseForBackground() {
        pause()
    }

    // ---------------------------------------------------------------- internals
    private fun fail(message: String) {
        releasePlayer()
        error = message
        state = if (uri != null) PlayState.ERROR else PlayState.NO_FILE
    }

    private fun messageFor(what: Int, extra: Int): String = when {
        what == MediaPlayer.MEDIA_ERROR_SERVER_DIED -> "پخش‌کننده متوقف شد. دوباره تلاش کنید."
        extra == MEDIA_ERROR_UNSUPPORTED || extra == MEDIA_ERROR_MALFORMED -> "قالب این فایل صوتی پشتیبانی نمی‌شود."
        extra == MEDIA_ERROR_IO -> "خواندن فایل ممکن نشد."
        extra == MEDIA_ERROR_TIMED_OUT -> "باز کردن فایل بیش از حد طول کشید."
        else -> "خطا در پخش فایل."
    }

    private fun releasePlayer() {
        val p = player
        player = null
        preparing = false
        startWhenPrepared = false
        loading = false
        if (p != null) {
            p.setOnPreparedListener(null)
            p.setOnCompletionListener(null)
            p.setOnErrorListener(null)
            try {
                p.reset()
            } catch (e: Exception) {
            }
            p.release()
        }
        abandonFocus()
    }

    private fun requestFocus() {
        if (focusRequest != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusRequest = req
        audioManager.requestAudioFocus(req)   // playback is allowed even if focus is refused
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    override fun onCleared() {
        releasePlayer()
        super.onCleared()
    }

    private companion object {
        // MediaPlayer's hidden MEDIA_ERROR_* "extra" codes
        const val MEDIA_ERROR_IO = -1004
        const val MEDIA_ERROR_MALFORMED = -1007
        const val MEDIA_ERROR_UNSUPPORTED = -1010
        const val MEDIA_ERROR_TIMED_OUT = -110
    }
}

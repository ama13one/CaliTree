@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.Skill
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.difficultyLabel

private val planLengths = listOf(7, 14, 30, 45, 60)
private val planDifficultyNames = listOf("آسان‌تر", "متعادل", "چالش‌برانگیز")

@Composable
fun WorkoutPlanScreen(store: ProgressStore, onOpen: (String) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val available = SkillData.all.filter { store.statusOf(it) == Status.AVAILABLE && !store.isDone(it.id) }
    val maxDifficulty = when (store.planDifficulty) { 0 -> 2; 1 -> 3; else -> 4 }
    val minDifficulty = when (store.planDifficulty) { 0 -> 1; 1 -> 1; else -> 2 }
    val candidates = available.filter { it.difficulty in minDifficulty..maxDifficulty }
        .sortedWith(compareBy<Skill> { it.difficulty }.thenBy { it.name })
    val fallback = available.sortedBy { it.difficulty }
    val choices = (if (candidates.isNotEmpty()) candidates else fallback).take(store.planSessionsPerDay)
    val finished = store.planDay > store.planDuration
    val progress = if (finished) 1f else (store.planDay - 1).toFloat() / store.planDuration

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("برنامه‌ی تمرینی", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("برنامه را با زمان و سطح خودت هماهنگ کن. پیشرفت باید تدریجی باشد، نه مسابقه با بدن.", color = cs.onSurfaceVariant)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (finished) "🎉 برنامه کامل شد!" else "روز ${fa(store.planDay)} از ${fa(store.planDuration)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text(if (finished) "می‌توانی برنامه را از روز اول دوباره شروع کنی یا مدت و سطحش را تغییر بدهی." else "جلسه‌های انجام‌شده امروز: ${fa(store.planSessionsDone)} از ${fa(store.planSessionsPerDay)}", color = cs.onPrimaryContainer)
                }
            }
        }
        item { Text("مدت برنامه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                planLengths.forEach { days ->
                    FilterChip(selected = store.planDuration == days, onClick = { store.configurePlan(days, store.planDifficulty, store.planSessionsPerDay) }, label = { Text("${fa(days)} روز") })
                }
            }
        }
        item { Text("شدت پیشنهادی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                planDifficultyNames.forEachIndexed { i, label ->
                    FilterChip(selected = store.planDifficulty == i, onClick = { store.configurePlan(store.planDuration, i, store.planSessionsPerDay) }, label = { Text(label) })
                }
            }
            Text(when (store.planDifficulty) {
                0 -> "تمرکز روی مهارت‌های ساده‌تر و آشنایی با حرکت‌هاست."
                1 -> "ترکیبی از مهارت‌های پایه و متوسط، با توجه به پیش‌نیازهای بازشده."
                else -> "پیشنهادها چالش‌برانگیزترند، اما فقط از مهارت‌هایی که پیش‌نیازهایشان باز شده‌اند."
            }, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        item { Text("تعداد جلسه در روز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..3).forEach { count ->
                    FilterChip(selected = store.planSessionsPerDay == count, onClick = { store.configurePlan(store.planDuration, store.planDifficulty, count) }, label = { Text("${fa(count)} جلسه") })
                }
            }
            Text("اگر وقت یا انرژی نداری، یک جلسه کافی است. استراحت هم بخشی از تمرین است.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        item { Text("پیشنهادهای امروز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (finished) {
            item { Text("آفرین که برنامه را تا انتها دنبال کردی! برای شروع دوباره، دکمه‌ی زیر را بزن.", color = cs.onSurfaceVariant) }
            item { Button(onClick = { store.restartPlan() }, modifier = Modifier.fillMaxWidth()) { Text("شروع دوباره از روز اول") } }
        } else if (choices.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.4f))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("فعلاً مهارت تازه‌ای برای پیشنهاد نداریم.", fontWeight = FontWeight.SemiBold)
                        Text("از درخت مهارت‌ها پیش‌نیازهای در دسترس را بررسی کن یا مهارتی را که بلدی تکمیل‌شده علامت بزن.", color = cs.onSurfaceVariant)
                    }
                }
            }
        } else {
            items(choices.size) { index ->
                val skill = choices[index]
                Card(onClick = { onOpen(skill.id) }, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.4f)), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("جلسه ${fa(index + 1)} · ${skill.name}", fontWeight = FontWeight.SemiBold)
                        Text("${skill.tree.title} · ${difficultyLabel(skill.difficulty)}", style = MaterialTheme.typography.bodySmall, color = cs.primary)
                        Text(skill.description, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }
            item {
                Button(onClick = {
                    choices.firstOrNull()?.let { if (!store.isDone(it.id)) store.toggleDone(it.id) }
                    store.completePlanSession()
                }, modifier = Modifier.fillMaxWidth()) { Text("جلسه‌ی بعدی را انجام دادم ✓") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { store.skipPlanDay(1) }, modifier = Modifier.weight(1f), enabled = !finished) { Text("رد کردن امروز") }
                OutlinedButton(onClick = { store.skipPlanDay(2) }, modifier = Modifier.weight(1f), enabled = !finished) { Text("جلو رفتن ۲ روز") }
            }
            Text("می‌توانی روزها را رد کنی یا جلوتر بروی؛ برنامه تو را مجبور به جبران چند روز در یک روز نمی‌کند. اگر چند جلسه انجام می‌دهی، بین تمرین‌های سنگین استراحت کن.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

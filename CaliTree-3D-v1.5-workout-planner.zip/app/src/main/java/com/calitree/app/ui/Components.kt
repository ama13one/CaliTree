@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.calitree.app.data.Skill
import com.calitree.app.data.Status
import com.calitree.app.data.difficultyLabel

@Composable
fun StatusIcon(status: Status, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    when (status) {
        Status.DONE -> Icon(
            Icons.Filled.CheckCircle,
            contentDescription = "تکمیل‌شده",
            tint = cs.primary,
            modifier = modifier
        )
        Status.LOCKED -> Icon(
            Icons.Filled.Lock,
            contentDescription = "قفل‌شده",
            tint = cs.onSurfaceVariant,
            modifier = modifier
        )
        Status.AVAILABLE -> Icon(
            Icons.Filled.PlayArrow,
            contentDescription = "آماده‌ی تمرین",
            tint = cs.primary,
            modifier = modifier
        )
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle(title)
        content()
    }
}

/** A list row used by search, favorites, progress and the previous/next lists. */
@Composable
fun SkillRow(
    skill: Skill,
    status: Status,
    favorite: Boolean,
    onClick: () -> Unit,
    extra: String? = null
) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Difficulty color (never changes) and, beside it, the status icon.
            // The green check only appears for exercises that are recorded as completed.
            DifficultyBadge(skill.difficulty, 22.dp)
            Spacer(Modifier.width(6.dp))
            StatusIcon(status, Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    skill.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface
                )
                val sub = skill.tree.title + " · " + difficultyLabel(skill.difficulty) +
                    (if (extra != null) " · " + extra else "")
                Text(
                    sub,
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant
                )
            }
            if (favorite) {
                Icon(
                    Icons.Filled.Star,
                    contentDescription = "علاقه‌مندی",
                    tint = cs.tertiary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/** A node drawn inside the tree. */
@Composable
fun NodeCard(
    skill: Skill,
    status: Status,
    favorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val bg = when (status) {
        Status.DONE -> cs.primaryContainer
        Status.AVAILABLE -> cs.surface
        Status.LOCKED -> cs.surfaceVariant.copy(alpha = 0.6f)
    }
    val borderColor = when (status) {
        Status.DONE -> cs.primary
        Status.AVAILABLE -> cs.primary.copy(alpha = 0.7f)
        Status.LOCKED -> cs.outline
    }
    val textColor = if (status == Status.LOCKED) cs.onSurfaceVariant else cs.onSurface
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = bg,
        border = BorderStroke(if (status == Status.AVAILABLE) 2.dp else 1.dp, borderColor)
    ) {
        Column(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().height(22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exercise icon: the difficulty color, with the completion check right beside it.
                // The color never depends on completion and the check never depends on difficulty.
                DifficultyBadge(skill.difficulty, 22.dp)
                if (status == Status.DONE) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = "تکمیل‌شده",
                        tint = cs.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                if (status == Status.LOCKED) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = "قفل‌شده",
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
                if (favorite) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = "علاقه‌مندی",
                        tint = cs.tertiary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                skill.name,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = textColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.calitree.app.data.DemoData
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.i18n.LocalLang
import com.calitree.app.i18n.S
import com.calitree.app.i18n.difficultyName
import com.calitree.app.i18n.Lang
import com.calitree.app.i18n.localBody
import com.calitree.app.i18n.localName
import com.calitree.app.i18n.localTitle
import com.calitree.app.i18n.numText
import com.calitree.app.i18n.tr

@Composable
fun SkillDetailScreen(
    skillId: String,
    store: ProgressStore,
    onBack: () -> Unit,
    onOpen: (String) -> Unit
) {
    val skill = SkillData.byId[skillId]
    if (skill == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val cs = MaterialTheme.colorScheme
    val status = store.statusOf(skill)
    val favorite = store.isFavorite(skill.id)
    val previous = skill.prereqs.mapNotNull { SkillData.byId[it] }
    val next = SkillData.nextOf(skill.id)
    val missing = previous.filter { !store.isDone(it.id) }
    val body = skill.localBody()
    val lang = LocalLang.current
    val description = body?.description ?: skill.description
    val requirement = body?.requirement ?: skill.requirement
    val volume = body?.volume ?: skill.volume
    val goal = body?.goal ?: skill.goal
    val steps = body?.steps ?: skill.steps
    val tip = body?.tip ?: skill.tip
    val title = skill.localName()
    val listSep = tr(S.LIST_SEP)
    val missingNames = missing.map { it.localName() }.joinToString(listSep)

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr(S.CD_BACK))
                    }
                },
                actions = {
                    IconButton(onClick = { store.toggleFavorite(skill.id) }) {
                        Icon(
                            if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (favorite) tr(S.CD_REMOVE_FAV) else tr(S.CD_ADD_FAV),
                            tint = if (favorite) cs.tertiary else cs.onSurfaceVariant
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { store.toggleDone(skill.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(52.dp),
                    colors = if (status == Status.DONE) {
                        ButtonDefaults.filledTonalButtonColors()
                    } else {
                        ButtonDefaults.buttonColors()
                    }
                ) {
                    Text(
                        when (status) {
                            Status.DONE -> tr(S.BTN_UNDO)
                            Status.LOCKED -> tr(S.BTN_MARK_ANYWAY)
                            Status.AVAILABLE -> tr(S.BTN_MARK)
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            val demo = DemoData.forId(skill.id)
            if (demo != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DemoPlayer(skillName = title, demo = demo)
                    Text(
                        tr(S.DEMO_SIDE_NOTE),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    tr(S.DETAIL_TREE_SUFFIX, skill.tree.localTitle()),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.secondary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "   " + difficultyName(skill.difficulty) + "  " + dots(skill.difficulty),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = when (status) {
                    Status.DONE -> cs.primaryContainer
                    Status.AVAILABLE -> cs.surfaceVariant
                    Status.LOCKED -> cs.surfaceVariant
                }
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    StatusIcon(status, Modifier.height(18.dp).width(18.dp))
                    Text(
                        "  " + when (status) {
                            Status.DONE -> tr(S.ST_COMPLETED)
                            Status.AVAILABLE -> tr(S.ST_READY)
                            Status.LOCKED -> tr(S.ST_LOCKED)
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            if (status == Status.LOCKED) {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.surfaceVariant) {
                    Text(
                        tr(S.FINISH_FIRST, missingNames),
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (lang != Lang.EN && body == null) {
                Text(
                    tr(S.NOTE_EN_ONLY),
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant
                )
            }

            Section(tr(S.SEC_ABOUT)) {
                Text(description, style = MaterialTheme.typography.bodyLarge)
            }

            Section(tr(S.SEC_BEFORE)) {
                Text(requirement, style = MaterialTheme.typography.bodyLarge)
            }

            Section(tr(S.SEC_DOSAGE)) {
                Text(volume, style = MaterialTheme.typography.bodyLarge)
            }

            Section(tr(S.SEC_HOW)) {
                steps.forEachIndexed { i, step ->
                    Row {
                        Text(
                            numText("${i + 1}."),
                            modifier = Modifier.width(26.dp),
                            fontWeight = FontWeight.Bold,
                            color = cs.primary
                        )
                        Text(step, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            if (demo != null && (demo.formTips.isNotEmpty() || demo.commonMistakes.isNotEmpty()) && lang != Lang.EN) {
                Text(
                    tr(S.NOTE_DEMO_EN_ONLY),
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant
                )
            }

            if (demo != null && demo.formTips.isNotEmpty()) {
                Section(tr(S.SEC_FORM_TIPS)) {
                    demo.formTips.forEach { BulletText(it) }
                }
            }

            if (demo != null && demo.commonMistakes.isNotEmpty()) {
                Section(tr(S.SEC_MISTAKES)) {
                    demo.commonMistakes.forEach { BulletText(it) }
                }
            }

            Section(tr(S.SEC_STANDARD)) {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.primaryContainer) {
                    Text(
                        goal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onPrimaryContainer,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Section(tr(S.SEC_TIP)) {
                Text(tip, style = MaterialTheme.typography.bodyLarge)
            }

            Section(tr(S.SEC_PREV)) {
                if (previous.isEmpty()) {
                    Text(
                        tr(S.NONE_PREV),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    previous.forEach { p ->
                        SkillRow(p, store.statusOf(p), store.isFavorite(p.id), { onOpen(p.id) })
                    }
                }
            }

            Section(tr(S.SEC_NEXT)) {
                if (next.isEmpty()) {
                    Text(
                        tr(S.NONE_NEXT),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    next.forEach { n ->
                        SkillRow(n, store.statusOf(n), store.isFavorite(n.id), { onOpen(n.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun BulletText(text: String) {
    Row {
        Text(
            "•",
            modifier = Modifier.width(18.dp),
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

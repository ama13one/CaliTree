# CaliTree

Offline calisthenics training app for Android (Kotlin + Jetpack Compose).
132 skills in 9 connected trees: Push, Pull, Legs, Core, Handstand, Levers, Planche, Human Flag, Rings.
Progress, favorites and profile are saved locally on the phone. No internet, no ads, no subscriptions.

## Build an APK with only a phone (GitHub Actions, free)
Method A (easiest): put CaliTree.zip and build-from-zip.yml in a new GitHub repo
(workflow file path: .github/workflows/build.yml), then open Actions -> Build APK.
Download app-debug.apk from the Releases section of the repo.

Method B: upload the unzipped project folders as they are (the workflow in .github/workflows already works).

## Build on a computer
Install Android Studio, open this folder and press Run, or run `gradle assembleDebug`
(JDK 17, Gradle 8.7). The APK is at app/build/outputs/apk/debug/app-debug.apk.

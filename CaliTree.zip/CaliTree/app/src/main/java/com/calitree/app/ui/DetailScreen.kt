@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.difficultyLabel

@Composable
fun SkillDetailScreen(
    skillId: String,
    store: ProgressStore,
    onBack: () -> Unit,
    onOpen: (String) -> Unit
) {
    val skill = SkillData.byId[skillId]
    if (skill == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val cs = MaterialTheme.colorScheme
    val status = store.statusOf(skill)
    val favorite = store.isFavorite(skill.id)
    val previous = skill.prereqs.mapNotNull { SkillData.byId[it] }
    val next = SkillData.nextOf(skill.id)
    val missing = previous.filter { !store.isDone(it.id) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(skill.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { store.toggleFavorite(skill.id) }) {
                        Icon(
                            if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (favorite) "Remove from favorites" else "Add to favorites",
                            tint = if (favorite) cs.tertiary else cs.onSurfaceVariant
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { store.toggleDone(skill.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(52.dp),
                    colors = if (status == Status.DONE) {
                        ButtonDefaults.filledTonalButtonColors()
                    } else {
                        ButtonDefaults.buttonColors()
                    }
                ) {
                    Text(
                        when (status) {
                            Status.DONE -> "Completed. Tap to undo"
                            Status.LOCKED -> "Mark complete anyway"
                            Status.AVAILABLE -> "Mark as completed"
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    skill.tree.title + " tree",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.secondary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "   " + difficultyLabel(skill.difficulty) + "  " + dots(skill.difficulty),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = when (status) {
                    Status.DONE -> cs.primaryContainer
                    Status.AVAILABLE -> cs.surfaceVariant
                    Status.LOCKED -> cs.surfaceVariant
                }
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    StatusIcon(status, Modifier.height(18.dp).width(18.dp))
                    Text(
                        "  " + when (status) {
                            Status.DONE -> "Completed"
                            Status.AVAILABLE -> "Ready to train"
                            Status.LOCKED -> "Locked"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            if (status == Status.LOCKED) {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.surfaceVariant) {
                    Text(
                        "Finish first: " + missing.joinToString(", ") { it.name } +
                            ". If you already have this skill, you can still mark it complete.",
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Section("About") {
                Text(skill.description, style = MaterialTheme.typography.bodyLarge)
            }

            Section("Before you start") {
                Text(skill.requirement, style = MaterialTheme.typography.bodyLarge)
            }

            Section("Training dosage") {
                Text(skill.volume, style = MaterialTheme.typography.bodyLarge)
            }

            Section("How to perform") {
                skill.steps.forEachIndexed { i, step ->
                    Row {
                        Text(
                            "${i + 1}.",
                            modifier = Modifier.width(26.dp),
                            fontWeight = FontWeight.Bold,
                            color = cs.primary
                        )
                        Text(step, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            Section("Standard to move on") {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.primaryContainer) {
                    Text(
                        skill.goal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = cs.onPrimaryContainer,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Section("Coaching tip") {
                Text(skill.tip, style = MaterialTheme.typography.bodyLarge)
            }

            Section("Previous progression") {
                if (previous.isEmpty()) {
                    Text(
                        "None. This is a starting point of its path.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    previous.forEach { p ->
                        SkillRow(p, store.statusOf(p), store.isFavorite(p.id), { onOpen(p.id) })
                    }
                }
            }

            Section("Next progression") {
                if (next.isEmpty()) {
                    Text(
                        "None. This is the top of this path.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                } else {
                    next.forEach { n ->
                        SkillRow(n, store.statusOf(n), store.isFavorite(n.id), { onOpen(n.id) })
                    }
                }
            }
        }
    }
}

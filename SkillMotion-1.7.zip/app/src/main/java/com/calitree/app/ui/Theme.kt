package com.calitree.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF05260F),
    primaryContainer = Color(0xFF14391F),
    onPrimaryContainer = Color(0xFFB7F5C8),
    secondary = Color(0xFF7DD3FC),
    tertiary = Color(0xFFFBBF24),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE6EAF0),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EAF0),
    surfaceVariant = Color(0xFF212833),
    onSurfaceVariant = Color(0xFFA7B0BE),
    outline = Color(0xFF3A4454)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF15803D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD1F5DC),
    onPrimaryContainer = Color(0xFF0B3D1B),
    secondary = Color(0xFF0369A1),
    tertiary = Color(0xFFD97706),
    background = Color(0xFFF5F7FA),
    onBackground = Color(0xFF12161C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF12161C),
    surfaceVariant = Color(0xFFE6EAF0),
    onSurfaceVariant = Color(0xFF4B5565),
    outline = Color(0xFFB3BCC9)
)

/**
 * Persian typography. Letter spacing must be zero: any extra spacing breaks the joining of
 * Persian letters. The line height is slightly larger than the Latin default so the dots and
 * marks above and below the letters do not collide between lines.
 */
private fun faStyle(s: TextStyle): TextStyle = s.copy(
    letterSpacing = 0.sp,
    lineHeight = if (s.fontSize.isSp) (s.fontSize.value * 1.55f).sp else s.lineHeight
)

private val PersianTypography: Typography = Typography().let { d ->
    Typography(
        displayLarge = faStyle(d.displayLarge),
        displayMedium = faStyle(d.displayMedium),
        displaySmall = faStyle(d.displaySmall),
        headlineLarge = faStyle(d.headlineLarge),
        headlineMedium = faStyle(d.headlineMedium),
        headlineSmall = faStyle(d.headlineSmall),
        titleLarge = faStyle(d.titleLarge),
        titleMedium = faStyle(d.titleMedium),
        titleSmall = faStyle(d.titleSmall),
        bodyLarge = faStyle(d.bodyLarge),
        bodyMedium = faStyle(d.bodyMedium),
        bodySmall = faStyle(d.bodySmall),
        labelLarge = faStyle(d.labelLarge),
        labelMedium = faStyle(d.labelMedium),
        labelSmall = faStyle(d.labelSmall)
    )
}

/**
 * mode: 0 = follow system, 1 = light, 2 = dark.
 * The whole app is Persian only, so the layout direction is always right-to-left. Dialogs and
 * other windows opened from inside this theme inherit the same direction.
 */
private data class AccentPalette(
    val primary: Color,
    val primaryDark: Color,
    val secondary: Color,
    val tertiary: Color
)

private val AccentPalettes = listOf(
    AccentPalette(Color(0xFF15803D), Color(0xFF4ADE80), Color(0xFF0369A1), Color(0xFFD97706)), // سبز جنگلی
    AccentPalette(Color(0xFF2563EB), Color(0xFF60A5FA), Color(0xFF0891B2), Color(0xFF7C3AED)), // آبی
    AccentPalette(Color(0xFFDC2626), Color(0xFFF87171), Color(0xFFEA580C), Color(0xFFFBBF24)), // قرمز
    AccentPalette(Color(0xFF7C3AED), Color(0xFFA78BFA), Color(0xFFDB2777), Color(0xFF0891B2)), // بنفش
    AccentPalette(Color(0xFF0F766E), Color(0xFF5EEAD4), Color(0xFF0284C7), Color(0xFF65A30D)), // اقیانوسی
    AccentPalette(Color(0xFFDB2777), Color(0xFFF9A8D4), Color(0xFFEA580C), Color(0xFF7C3AED)), // غروب
    AccentPalette(Color(0xFFCA8A04), Color(0xFFFACC15), Color(0xFFEA580C), Color(0xFF854D0E)), // زرد آفتابی
    AccentPalette(Color(0xFF64748B), Color(0xFFE2E8F0), Color(0xFF475569), Color(0xFF94A3B8)), // سفید و نقره‌ای
    AccentPalette(Color(0xFF9A3412), Color(0xFFFB923C), Color(0xFFB45309), Color(0xFF166534))  // نارنجی گرم
)

@Composable
fun CaliTheme(mode: Int, accentTheme: Int = 0, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val palette = AccentPalettes[accentTheme.coerceIn(0, AccentPalettes.lastIndex)]
    val colors = if (dark) {
        darkColorScheme(
            primary = palette.primaryDark,
            onPrimary = Color(0xFF10131A),
            primaryContainer = palette.primaryDark.copy(alpha = 0.22f),
            onPrimaryContainer = Color(0xFFF4F6FB),
            secondary = palette.secondary,
            tertiary = palette.tertiary,
            background = Color(0xFF0E1116),
            onBackground = Color(0xFFE6EAF0),
            surface = Color(0xFF161B22),
            onSurface = Color(0xFFE6EAF0),
            surfaceVariant = Color(0xFF212833),
            onSurfaceVariant = Color(0xFFA7B0BE),
            outline = Color(0xFF3A4454)
        )
    } else {
        lightColorScheme(
            primary = palette.primary,
            onPrimary = Color.White,
            primaryContainer = palette.primary.copy(alpha = 0.13f),
            onPrimaryContainer = Color(0xFF17202A),
            secondary = palette.secondary,
            tertiary = palette.tertiary,
            background = Color(0xFFF5F7FA),
            onBackground = Color(0xFF12161C),
            surface = Color.White,
            onSurface = Color(0xFF12161C),
            surfaceVariant = Color(0xFFE6EAF0),
            onSurfaceVariant = Color(0xFF4B5565),
            outline = Color(0xFFB3BCC9)
        )
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colors,
            typography = PersianTypography,
            content = content
        )
    }
}

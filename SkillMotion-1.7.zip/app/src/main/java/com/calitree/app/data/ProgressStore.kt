package com.calitree.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Status { DONE, AVAILABLE, LOCKED }

/** Saves everything on the phone (SharedPreferences). Works fully offline. */
class ProgressStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("calitree_progress", Context.MODE_PRIVATE)

    var completedAt: Map<String, Long> by mutableStateOf(readDates())
        private set
    var favorites: Set<String> by mutableStateOf(readSet("favorites"))
        private set
    var name: String by mutableStateOf(prefs.getString("name", "") ?: "")
        private set
    var appName: String by mutableStateOf(prefs.getString("app_name", "کالی‌تری") ?: "کالی‌تری")
        private set
    var motivation: String by mutableStateOf(prefs.getString("motivation", "") ?: "")
        private set
    var onboardingComplete: Boolean by mutableStateOf(prefs.getBoolean("onboarding_complete", false))
        private set
    /** Default exercise view: 0 = 2D, 1 = 3D. */
    var demoMode: Int by mutableStateOf(prefs.getInt("demo_mode", 0).coerceIn(0, 1))
        private set
    var themeMode: Int by mutableStateOf(prefs.getInt("theme", 0).coerceIn(0, 2))
        private set
    /** Nine selectable accent palettes. */
    var accentTheme: Int by mutableStateOf(prefs.getInt("accent_theme", 0).coerceIn(0, 8))
        private set
    var pushupBaseline: Int by mutableStateOf(prefs.getInt("pushup_baseline", 0).coerceAtLeast(0))
        private set
    var pullupBaseline: Int by mutableStateOf(prefs.getInt("pullup_baseline", 0).coerceAtLeast(0))
        private set
    var workoutFocus: String by mutableStateOf(prefs.getString("workout_focus", "همه") ?: "همه")
        private set
    /** Workout plan length in days. */
    var planDuration: Int by mutableStateOf(prefs.getInt("plan_duration", 30).coerceIn(7, 60))
        private set
    /** 0 = gentle, 1 = balanced, 2 = challenging. */
    var planDifficulty: Int by mutableStateOf(prefs.getInt("plan_difficulty", 1).coerceIn(0, 2))
        private set
    /** Number of short sessions to aim for each plan day. */
    var planSessionsPerDay: Int by mutableStateOf(prefs.getInt("plan_sessions_per_day", 1).coerceIn(1, 3))
        private set
    var planDay: Int by mutableStateOf(prefs.getInt("plan_day", 1).coerceAtLeast(1))
        private set
    var planSessionsDone: Int by mutableStateOf(prefs.getInt("plan_sessions_done", 0).coerceAtLeast(0))
        private set

    val completed: Set<String> get() = completedAt.keys

    private fun readSet(key: String): Set<String> =
        (prefs.getStringSet(key, emptySet()) ?: emptySet()).toSet()

    private fun readDates(): Map<String, Long> {
        val result = HashMap<String, Long>()
        for (entry in readSet("completed")) {
            val i = entry.lastIndexOf('=')
            if (i > 0) {
                result[entry.substring(0, i)] = entry.substring(i + 1).toLongOrNull() ?: 0L
            }
        }
        return result
    }

    fun isDone(id: String): Boolean = completedAt.containsKey(id)

    fun isFavorite(id: String): Boolean = favorites.contains(id)

    fun statusOf(skill: Skill): Status = when {
        isDone(skill.id) -> Status.DONE
        skill.prereqs.all { isDone(it) } -> Status.AVAILABLE
        else -> Status.LOCKED
    }

    fun toggleDone(id: String) {
        val map = completedAt.toMutableMap()
        if (map.containsKey(id)) map.remove(id) else map[id] = System.currentTimeMillis()
        // The check mark is shown only after the new state was written to storage successfully.
        val saved = prefs.edit()
            .putStringSet("completed", map.map { "${it.key}=${it.value}" }.toSet())
            .commit()
        if (saved) completedAt = map
    }

    fun toggleFavorite(id: String) {
        val set = favorites.toMutableSet()
        if (!set.add(id)) set.remove(id)
        favorites = set
        prefs.edit().putStringSet("favorites", set).apply()
    }

    fun updateName(value: String) {
        name = value
        prefs.edit().putString("name", value).apply()
    }

    fun updateAppName(value: String) {
        appName = value
        prefs.edit().putString("app_name", value).apply()
    }

    fun completeOnboarding(userName: String, userMotivation: String) {
        name = userName.trim()
        motivation = userMotivation.trim()
        onboardingComplete = true
        prefs.edit()
            .putString("name", name)
            .putString("motivation", motivation)
            .putBoolean("onboarding_complete", true)
            .apply()
    }

    fun updateMotivation(value: String) {
        motivation = value
        prefs.edit().putString("motivation", value).apply()
    }

    fun updateDemoMode(mode: Int) {
        demoMode = mode.coerceIn(0, 1)
        prefs.edit().putInt("demo_mode", demoMode).apply()
    }

    fun updateTheme(mode: Int) {
        themeMode = mode.coerceIn(0, 2)
        prefs.edit().putInt("theme", themeMode).apply()
    }

    fun updateAccentTheme(value: Int) {
        accentTheme = value.coerceIn(0, 8)
        prefs.edit().putInt("accent_theme", accentTheme).apply()
    }

    fun saveFitnessBaseline(pushups: Int, pullups: Int) {
        pushupBaseline = pushups.coerceIn(0, 200)
        pullupBaseline = pullups.coerceIn(0, 100)
        prefs.edit().putInt("pushup_baseline", pushupBaseline).putInt("pullup_baseline", pullupBaseline).apply()
    }

    fun updateWorkoutFocus(value: String) {
        workoutFocus = value
        prefs.edit().putString("workout_focus", value).apply()
    }

    fun configurePlan(duration: Int, difficulty: Int, sessionsPerDay: Int) {
        planDuration = duration.coerceIn(7, 60)
        planDifficulty = difficulty.coerceIn(0, 2)
        planSessionsPerDay = sessionsPerDay.coerceIn(1, 3)
        planDay = planDay.coerceAtMost(planDuration + 1)
        planSessionsDone = planSessionsDone.coerceAtMost(planSessionsPerDay - 1)
        prefs.edit()
            .putInt("plan_duration", planDuration)
            .putInt("plan_difficulty", planDifficulty)
            .putInt("plan_sessions_per_day", planSessionsPerDay)
            .putInt("plan_day", planDay)
            .putInt("plan_sessions_done", planSessionsDone)
            .apply()
    }

    /** Complete a planned session. After the chosen number of sessions, move to the next day. */
    fun completePlanSession() {
        planSessionsDone += 1
        if (planSessionsDone >= planSessionsPerDay) {
            planDay = (planDay + 1).coerceAtMost(planDuration + 1)
            planSessionsDone = 0
        }
        prefs.edit().putInt("plan_day", planDay).putInt("plan_sessions_done", planSessionsDone).apply()
    }

    /** Skip today's session or intentionally move ahead to another day. */
    fun skipPlanDay(days: Int = 1) {
        planDay = (planDay + days.coerceIn(1, 3)).coerceAtMost(planDuration + 1)
        planSessionsDone = 0
        prefs.edit().putInt("plan_day", planDay).putInt("plan_sessions_done", 0).apply()
    }

    fun restartPlan() {
        planDay = 1
        planSessionsDone = 0
        prefs.edit().putInt("plan_day", 1).putInt("plan_sessions_done", 0).apply()
    }

    fun resetProgress() {
        completedAt = emptyMap()
        prefs.edit().putStringSet("completed", emptySet()).apply()
    }
}

# Release checklist (v1.2)

No update-category checklist existed in the project, so this file records the categories addressed by this release.

- [x] 🌱 Skill Trees & Progression
- [x] 🎨 UI, Themes & Customization
- [x] 🏋️ Exercise & Skill System
- [x] 📊 Progress Tracking & Statistics
- [x] 🌍 Languages & Accessibility
- [ ] ⚡ Performance & Optimization (no measurable optimization work was done in this release)
- [x] 💻 Technical & Developer Improvements

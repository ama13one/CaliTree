# CaliTree

Offline calisthenics training app for Android (Kotlin + Jetpack Compose).
132 skills in 9 connected trees: Push, Pull, Legs, Core, Handstand, Levers, Planche, Human Flag, Rings.
Progress, favorites and profile are saved locally on the phone. No internet, no ads, no subscriptions.

## v1.1: exercise demonstrations
Every skill opens with an animated demonstration (Start -> Movement -> End, looping, with Replay and Pause),
form tips and common mistakes. The animations are original vector drawings made of a few key poses per
exercise, so all 132 together are only a few kilobytes and work fully offline.

- Runtime: app/src/main/java/com/calitree/app/ui/DemoPlayer.kt (no extra libraries)
- Data model: data/Demo.kt, generated data: data/DemoMotions.kt and data/DemoTexts.kt
- 3D demonstrations: ui/Demo3D.kt plays assets/demo3d.bin, built by tools3d/ (see tools3d/README.md).
  The old 2D player (ui/DemoPlayer.kt) stays as an automatic fallback.
- Authoring tools (optional, need Python 3 + matplotlib): tools/  (edit poses/texts, then run
  `python3 tools/generate.py` to regenerate the Kotlin data files)

## Build an APK with only a phone (GitHub Actions, free)
Upload all files (keeping the folders) to a GitHub repository. The workflow in .github/workflows/build.yml
builds the APK. Download app-debug.apk from the Releases section of the repository.

## Build on a computer
Android Studio: open this folder and press Run, or run `gradle assembleDebug` (JDK 17, Gradle 8.7).

## v1.2: Persian only, difficulty colors, completion checks
- The app is Persian only (fa-IR) with a permanent right-to-left layout. All skill texts, UI texts and the
  3D camera names are Persian. Persian sources: `tools/fa/` (apply with `python3 tools/apply_fa.py`),
  camera names in `tools3d/build3d.py` (`VIEW_FA`).
- Five difficulty colors (green, yellow, orange, red, purple) defined in `ui/Difficulty.kt`; the old dot display is gone.
- A green check beside the exercise icon marks exercises recorded as completed (stored in `ProgressStore`).
- The tree diagram itself stays left-to-right (front lever on the left, back lever on the right); node text is RTL.

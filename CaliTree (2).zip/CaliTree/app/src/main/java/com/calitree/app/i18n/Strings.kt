package com.calitree.app.i18n

/** Every user-facing UI string. Translations live in StringsEn/Fa/Fr/Es.kt. */
enum class S {
    NAV_TREE, NAV_SEARCH, NAV_FAVORITES, NAV_PROGRESS, NAV_PROFILE,
    CD_BACK, CD_CLEAR, CD_FAVORITE, CD_COMPLETED, CD_LOCKED, CD_AVAILABLE, CD_ADD_FAV, CD_REMOVE_FAV,
    TREE_TITLE, TREE_PROGRESS,
    TREE_PUSH, TREE_PULL, TREE_LEGS, TREE_CORE, TREE_HANDSTAND, TREE_LEVERS, TREE_PLANCHE, TREE_FLAG, TREE_RINGS,
    TAG_PUSH, TAG_PULL, TAG_LEGS, TAG_CORE, TAG_HANDSTAND, TAG_LEVERS, TAG_PLANCHE, TAG_FLAG, TAG_RINGS,
    DETAIL_TREE_SUFFIX, BTN_UNDO, BTN_MARK_ANYWAY, BTN_MARK,
    ST_COMPLETED, ST_READY, ST_LOCKED, FINISH_FIRST, NOTE_EN_ONLY,
    SEC_ABOUT, SEC_BEFORE, SEC_DOSAGE, SEC_HOW, SEC_STANDARD, SEC_TIP, SEC_PREV, SEC_NEXT,
    NONE_PREV, NONE_NEXT,
    DIFF_1, DIFF_2, DIFF_3, DIFF_4, DIFF_5,
    LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5,
    SEARCH_TITLE, SEARCH_HINT, SEARCH_COUNT, SEARCH_EMPTY,
    FAV_TITLE, FAV_EMPTY,
    PROGRESS_TITLE, PROGRESS_PERCENT, PROGRESS_DETAIL, SEC_RECOMMENDED, REC_EMPTY,
    SEC_BY_TREE, SEC_COMPLETED, COMPLETED_EMPTY,
    PROFILE_TITLE, ATHLETE, LEVEL_LINE, PROFILE_STATS, GOAL_LINE, LABEL_NAME, LABEL_GOAL,
    SEC_APPEARANCE, THEME_SYSTEM, THEME_LIGHT, THEME_DARK, SEC_LANGUAGE,
    SEC_DATA, DATA_NOTE, BTN_RESET_ALL, SEC_SAFETY, SAFETY_TEXT,
    DLG_RESET_TITLE, DLG_RESET_TEXT, BTN_RESET, BTN_CANCEL, LIST_SEP
}

/** Plain lookup. Placeholders are {1}, {2}, {3}. Falls back to English, then to the key name. */
fun text(lang: Lang, key: S, vararg args: Any): String {
    val table = when (lang) {
        Lang.FA -> stringsFa
        Lang.FR -> stringsFr
        Lang.ES -> stringsEs
        Lang.EN -> stringsEn
    }
    var out = table[key] ?: stringsEn[key] ?: key.name
    for (i in args.indices) {
        out = out.replace("{" + (i + 1) + "}", args[i].toString())
    }
    return out
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.Skill
import com.calitree.app.data.SkillData
import com.calitree.app.data.TreeId
import com.calitree.app.i18n.S
import com.calitree.app.i18n.localTagline
import com.calitree.app.i18n.localTitle
import com.calitree.app.i18n.num
import com.calitree.app.i18n.tr

@Composable
fun TreeScreen(
    store: ProgressStore,
    treeIdx: Int,
    onTreeChange: (Int) -> Unit,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val trees = TreeId.values().toList()
    val tree = trees[treeIdx]
    val skills = SkillData.inTree(tree)
    val doneCount = skills.count { store.isDone(it.id) }

    Column(modifier.fillMaxSize()) {
        Text(
            tr(S.TREE_TITLE),
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(trees) { i, t ->
                FilterChip(
                    selected = i == treeIdx,
                    onClick = { onTreeChange(i) },
                    label = { Text(t.localTitle()) }
                )
            }
        }
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(
                tree.localTagline(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { if (skills.isEmpty()) 0f else doneCount.toFloat() / skills.size },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Text(
                tr(S.TREE_PROGRESS, num(doneCount), num(skills.size)),
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        key(tree.name) {
            TreeCanvas(
                skills = skills,
                store = store,
                onOpen = onOpen,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun TreeCanvas(
    skills: List<Skill>,
    store: ProgressStore,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val nodeW = 148f
    val nodeH = 70f
    val gapX = 20f
    val gapY = 44f
    val pad = 16f

    val levels = skills.associate { it.id to SkillData.level(it.id) }
    val byId = skills.associateBy { it.id }
    val maxLane = skills.maxOf { it.lane }
    val maxLevel = levels.values.max()
    val totalW = pad * 2 + (maxLane + 1) * nodeW + maxLane * gapX
    val totalH = pad * 2 + (maxLevel + 1) * nodeH + maxLevel * gapY

    fun nodeX(s: Skill): Float = pad + s.lane * (nodeW + gapX)
    fun nodeY(s: Skill): Float = pad + (levels[s.id] ?: 0) * (nodeH + gapY)

    val cs = MaterialTheme.colorScheme
    val activeColor = cs.primary
    val idleColor = cs.outline

    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val appDirection = LocalLayoutDirection.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Box(
        modifier
            .fillMaxSize()
            .verticalScroll(vScroll)
            .horizontalScroll(hScroll)
    ) {
        Box(Modifier.size(totalW.dp, totalH.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                for (s in skills) {
                    for (pid in s.prereqs) {
                        val p = byId[pid] ?: continue
                        val x1 = (nodeX(p) + nodeW / 2f).dp.toPx()
                        val y1 = (nodeY(p) + nodeH).dp.toPx()
                        val x2 = (nodeX(s) + nodeW / 2f).dp.toPx()
                        val y2 = nodeY(s).dp.toPx()
                        val midY = (y1 + y2) / 2f
                        val path = Path()
                        path.moveTo(x1, y1)
                        path.cubicTo(x1, midY, x2, midY, x2, y2)
                        val active = store.isDone(p.id)
                        drawPath(
                            path = path,
                            color = if (active) activeColor else idleColor,
                            style = Stroke(
                                width = (if (active) 3f else 2f).dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        )
                    }
                }
            }
            for (s in skills) {
                NodeCard(
                    skill = s,
                    status = store.statusOf(s),
                    favorite = store.isFavorite(s.id),
                    onClick = { onOpen(s.id) },
                    modifier = Modifier
                        .offset(nodeX(s).dp, nodeY(s).dp)
                        .size(nodeW.dp, nodeH.dp),
                    contentDirection = appDirection
                )
            }
        }
    }
    }
}

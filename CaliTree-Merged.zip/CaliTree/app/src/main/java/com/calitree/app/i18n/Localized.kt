package com.calitree.app.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import com.calitree.app.data.Skill
import com.calitree.app.data.TreeId
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The language currently shown. Provided once at the top of the app (see CaliApp). */
val LocalLang = staticCompositionLocalOf { Lang.EN }

@Composable
fun tr(key: S, vararg args: Any): String = text(LocalLang.current, key, *args)

/** Persian uses Persian digits, all other languages keep normal digits. */
fun localizeDigits(s: String, lang: Lang): String {
    if (lang != Lang.FA) return s
    val sb = StringBuilder(s.length)
    for (ch in s) {
        if (ch in '0'..'9') sb.append('۰' + (ch - '0')) else sb.append(ch)
    }
    return sb.toString()
}

@Composable
fun num(n: Int): String = localizeDigits(n.toString(), LocalLang.current)

@Composable
fun numText(s: String): String = localizeDigits(s, LocalLang.current)

fun formatDate(millis: Long, lang: Lang): String {
    val formatted = SimpleDateFormat("d MMM yyyy", Locale(lang.code)).format(Date(millis))
    return localizeDigits(formatted, lang)
}

fun skillName(lang: Lang, skill: Skill): String = when (lang) {
    Lang.FA -> skillNamesFa[skill.id]
    Lang.FR -> skillNamesFr[skill.id]
    Lang.ES -> skillNamesEs[skill.id]
    Lang.EN -> null
} ?: skill.name

@Composable
fun Skill.localName(): String = skillName(LocalLang.current, this)

/** Detail text in the current language, or null when only English exists. */
@Composable
fun Skill.localBody(): SkillBody? = SkillBodies.get(LocalLang.current, id)

fun treeTitleKey(tree: TreeId): S = when (tree) {
    TreeId.PUSH -> S.TREE_PUSH
    TreeId.PULL -> S.TREE_PULL
    TreeId.LEGS -> S.TREE_LEGS
    TreeId.CORE -> S.TREE_CORE
    TreeId.HANDSTAND -> S.TREE_HANDSTAND
    TreeId.LEVERS -> S.TREE_LEVERS
    TreeId.PLANCHE -> S.TREE_PLANCHE
    TreeId.FLAG -> S.TREE_FLAG
    TreeId.RINGS -> S.TREE_RINGS
}

fun treeTaglineKey(tree: TreeId): S = when (tree) {
    TreeId.PUSH -> S.TAG_PUSH
    TreeId.PULL -> S.TAG_PULL
    TreeId.LEGS -> S.TAG_LEGS
    TreeId.CORE -> S.TAG_CORE
    TreeId.HANDSTAND -> S.TAG_HANDSTAND
    TreeId.LEVERS -> S.TAG_LEVERS
    TreeId.PLANCHE -> S.TAG_PLANCHE
    TreeId.FLAG -> S.TAG_FLAG
    TreeId.RINGS -> S.TAG_RINGS
}

@Composable
fun TreeId.localTitle(): String = tr(treeTitleKey(this))

@Composable
fun TreeId.localTagline(): String = tr(treeTaglineKey(this))

fun difficultyKey(d: Int): S = when (d) {
    1 -> S.DIFF_1
    2 -> S.DIFF_2
    3 -> S.DIFF_3
    4 -> S.DIFF_4
    else -> S.DIFF_5
}

@Composable
fun difficultyName(d: Int): String = tr(difficultyKey(d))

fun levelKey(completed: Int): S = when {
    completed < 5 -> S.LEVEL_0
    completed < 15 -> S.LEVEL_1
    completed < 35 -> S.LEVEL_2
    completed < 65 -> S.LEVEL_3
    completed < 100 -> S.LEVEL_4
    else -> S.LEVEL_5
}

@Composable
fun levelName(completed: Int): String = tr(levelKey(completed))

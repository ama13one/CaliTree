package com.calitree.app.i18n

/** Translated detail text of one skill. Steps are pipe separated in the builder, like in the English data. */
data class SkillBody(
    val description: String,
    val requirement: String,
    val volume: String,
    val goal: String,
    val steps: List<String>,
    val tip: String
)

internal fun body(
    desc: String,
    req: String,
    vol: String,
    goal: String,
    steps: String,
    tip: String
): SkillBody = SkillBody(desc, req, vol, goal, steps.split("|"), tip)

/**
 * Detail text per language, keyed by skill id. A skill without an entry falls back to the English
 * text and the detail screen shows a small note. Add new translations to the maps below
 * (one list per tree keeps the files small).
 */
object SkillBodies {
    fun get(lang: Lang, id: String): SkillBody? = when (lang) {
        Lang.FA -> bodiesFa[id]
        Lang.FR -> bodiesFr[id]
        Lang.ES -> bodiesEs[id]
        Lang.EN -> null
    }
}

internal val bodiesFa: Map<String, SkillBody> = emptyMap()
internal val bodiesFr: Map<String, SkillBody> = emptyMap()
internal val bodiesEs: Map<String, SkillBody> = emptyMap()

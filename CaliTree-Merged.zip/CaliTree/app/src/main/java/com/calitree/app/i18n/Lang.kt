package com.calitree.app.i18n

import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

/** The four supported app languages. Persian is right-to-left, the others left-to-right. */
enum class Lang(val code: String, val nativeName: String, val rtl: Boolean) {
    FA("fa", "فارسی", true),
    EN("en", "English", false),
    FR("fr", "Français", false),
    ES("es", "Español", false);

    val direction: LayoutDirection
        get() = if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    companion object {
        fun fromCode(code: String?): Lang? = values().firstOrNull { it.code == code }

        /** First launch: use the phone language when supported, otherwise English. */
        fun systemDefault(): Lang = fromCode(Locale.getDefault().language) ?: EN
    }
}

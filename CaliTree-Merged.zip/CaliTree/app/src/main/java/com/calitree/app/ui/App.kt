@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import com.calitree.app.data.ProgressStore
import com.calitree.app.i18n.LocalLang
import com.calitree.app.i18n.S
import com.calitree.app.i18n.tr

private data class NavItem(val label: S, val icon: ImageVector)

private val navItems = listOf(
    NavItem(S.NAV_TREE, Icons.Filled.Share),
    NavItem(S.NAV_SEARCH, Icons.Filled.Search),
    NavItem(S.NAV_FAVORITES, Icons.Filled.Favorite),
    NavItem(S.NAV_PROGRESS, Icons.Filled.CheckCircle),
    NavItem(S.NAV_PROFILE, Icons.Filled.Person)
)

@Composable
fun CaliApp(store: ProgressStore) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var treeIdx by rememberSaveable { mutableStateOf(0) }
    // Stack of opened skill ids, stored as a comma separated string so it survives rotation.
    var stack by rememberSaveable { mutableStateOf("") }

    val ids = if (stack.isEmpty()) emptyList() else stack.split(",")
    val openId = ids.lastOrNull()

    val open: (String) -> Unit = { id ->
        stack = if (stack.isEmpty()) id else "$stack,$id"
    }
    val back: () -> Unit = {
        stack = ids.dropLast(1).joinToString(",")
    }

    val lang = store.lang
    CompositionLocalProvider(
        LocalLang provides lang,
        LocalLayoutDirection provides lang.direction
    ) {
    CaliTheme(store.themeMode) {
        Surface(color = MaterialTheme.colorScheme.background) {
            BackHandler(enabled = ids.isNotEmpty()) { back() }

            if (openId != null) {
                SkillDetailScreen(
                    skillId = openId,
                    store = store,
                    onBack = back,
                    onOpen = open
                )
            } else {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar {
                            navItems.forEachIndexed { i, item ->
                                NavigationBarItem(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    icon = { Icon(item.icon, contentDescription = tr(item.label)) },
                                    label = { Text(tr(item.label)) }
                                )
                            }
                        }
                    }
                ) { padding ->
                    val m = Modifier.padding(padding)
                    when (tab) {
                        0 -> TreeScreen(
                            store = store,
                            treeIdx = treeIdx,
                            onTreeChange = { treeIdx = it },
                            onOpen = open,
                            modifier = m
                        )
                        1 -> SearchScreen(store = store, onOpen = open, modifier = m)
                        2 -> FavoritesScreen(store = store, onOpen = open, modifier = m)
                        3 -> ProgressScreen(
                            store = store,
                            onOpen = open,
                            onGoTree = { idx ->
                                treeIdx = idx
                                tab = 0
                            },
                            modifier = m
                        )
                        else -> ProfileScreen(store = store, modifier = m)
                    }
                }
            }
        }
    }
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.calitree.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calitree.app.data.ProgressStore
import com.calitree.app.data.SkillData
import com.calitree.app.data.Status
import com.calitree.app.data.TreeId
import com.calitree.app.i18n.Lang
import com.calitree.app.i18n.LocalLang
import com.calitree.app.i18n.S
import com.calitree.app.i18n.formatDate
import com.calitree.app.i18n.levelName
import com.calitree.app.i18n.localTitle
import com.calitree.app.i18n.num
import com.calitree.app.i18n.tr

@Composable
fun ProgressScreen(
    store: ProgressStore,
    onOpen: (String) -> Unit,
    onGoTree: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val all = SkillData.all
    val doneList = all
        .filter { store.isDone(it.id) }
        .sortedByDescending { store.completedAt[it.id] ?: 0L }
    val percent = doneList.size * 100 / all.size
    val recommended = all
        .filter { store.statusOf(it) == Status.AVAILABLE }
        .sortedBy { it.difficulty }
        .take(6)
    val lang = LocalLang.current
    val trees = TreeId.values().toList()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                tr(S.PROGRESS_TITLE),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        tr(S.PROGRESS_PERCENT, num(percent)),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer
                    )
                    LinearProgressIndicator(
                        progress = { doneList.size.toFloat() / all.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Text(
                        tr(S.PROGRESS_DETAIL, num(doneList.size), num(all.size), levelName(doneList.size)),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }

        item { SectionTitle(tr(S.SEC_RECOMMENDED)) }
        if (recommended.isEmpty()) {
            item {
                Text(
                    tr(S.REC_EMPTY),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(recommended, key = { "next_" + it.id }) { s ->
                SkillRow(s, store.statusOf(s), store.isFavorite(s.id), { onOpen(s.id) })
            }
        }

        item { SectionTitle(tr(S.SEC_BY_TREE)) }
        itemsIndexed(trees, key = { _, t -> "tree_" + t.name }) { i, t ->
            val list = SkillData.inTree(t)
            val done = list.count { store.isDone(it.id) }
            Card(
                onClick = { onGoTree(i) },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cs.surface),
                border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            t.localTitle(),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            num(done) + " / " + num(list.size),
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.onSurfaceVariant
                        )
                    }
                    LinearProgressIndicator(
                        progress = { done.toFloat() / list.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        item { SectionTitle(tr(S.SEC_COMPLETED, num(doneList.size))) }
        if (doneList.isEmpty()) {
            item {
                Text(
                    tr(S.COMPLETED_EMPTY),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        } else {
            items(doneList, key = { "done_" + it.id }) { s ->
                val date = formatDate(store.completedAt[s.id] ?: 0L, lang)
                SkillRow(s, Status.DONE, store.isFavorite(s.id), { onOpen(s.id) }, extra = date)
            }
        }
    }
}

@Composable
fun ProfileScreen(store: ProgressStore, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var confirmReset by remember { mutableStateOf(false) }
    val done = store.completed.size
    val lang = LocalLang.current

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            tr(S.PROFILE_TITLE),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.5f))
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (store.name.isBlank()) tr(S.ATHLETE) else store.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    tr(S.LEVEL_LINE, levelName(done)),
                    style = MaterialTheme.typography.bodyLarge,
                    color = cs.primary
                )
                Text(
                    tr(S.PROFILE_STATS, num(done), num(SkillData.all.size), num(store.favorites.size)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
                if (store.goal.isNotBlank()) {
                    Text(
                        tr(S.GOAL_LINE, store.goal),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        OutlinedTextField(
            value = store.name,
            onValueChange = { store.updateName(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(tr(S.LABEL_NAME)) }
        )
        OutlinedTextField(
            value = store.goal,
            onValueChange = { store.updateGoal(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(tr(S.LABEL_GOAL)) }
        )

        SectionTitle(tr(S.SEC_LANGUAGE))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Lang.values().forEach { l ->
                FilterChip(
                    selected = lang == l,
                    onClick = { store.updateLang(l) },
                    label = { Text(l.nativeName) }
                )
            }
        }

        SectionTitle(tr(S.SEC_APPEARANCE))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(tr(S.THEME_SYSTEM), tr(S.THEME_LIGHT), tr(S.THEME_DARK)).forEachIndexed { i, label ->
                FilterChip(
                    selected = store.themeMode == i,
                    onClick = { store.updateTheme(i) },
                    label = { Text(label) }
                )
            }
        }

        SectionTitle(tr(S.SEC_DATA))
        Text(
            tr(S.DATA_NOTE),
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
        OutlinedButton(onClick = { confirmReset = true }) {
            Text(tr(S.BTN_RESET_ALL))
        }

        SectionTitle(tr(S.SEC_SAFETY))
        Text(
            tr(S.SAFETY_TEXT),
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(tr(S.DLG_RESET_TITLE)) },
            text = { Text(tr(S.DLG_RESET_TEXT)) },
            confirmButton = {
                TextButton(onClick = {
                    store.resetProgress()
                    confirmReset = false
                }) { Text(tr(S.BTN_RESET)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text(tr(S.BTN_CANCEL)) }
            }
        )
    }
}

# CaliTree

Offline calisthenics training app for Android (Kotlin + Jetpack Compose).
132 skills in 9 connected trees: Push, Pull, Legs, Core, Handstand, Levers, Planche, Human Flag, Rings.
Progress, favorites and profile are saved locally on the phone. No internet, no ads, no subscriptions.

## Build an APK with only a phone (GitHub Actions, free)
Method A (easiest): put CaliTree.zip and build-from-zip.yml in a new GitHub repo
(workflow file path: .github/workflows/build.yml), then open Actions -> Build APK.
Download app-debug.apk from the Releases section of the repo.

Method B: upload the unzipped project folders as they are (the workflow in .github/workflows already works).

## Build on a computer
Install Android Studio, open this folder and press Run, or run `gradle assembleDebug`
(JDK 17, Gradle 8.7). The APK is at app/build/outputs/apk/debug/app-debug.apk.

## Languages
The app is available in Persian (RTL), English, French and Spanish. Change the language in
Profile & Settings. UI texts live in `app/src/main/java/com/calitree/app/i18n/Strings*.kt`,
skill names in `SkillNames*.kt` and translated skill detail text in `SkillBodies.kt`.
A skill without a translated detail text falls back to English.

## Exercise demonstrations
Every skill opens with an animated demonstration (Start -> Movement -> End, looping, with Replay and Pause),
form tips and common mistakes. The animations are original vector drawings made of a few key poses per
exercise, so all 132 together are only a few kilobytes and work fully offline.
The labels around the animation are translated into all four languages; form tips and common mistakes
are currently English only (a note is shown in the other languages).

- Runtime: app/src/main/java/com/calitree/app/ui/DemoPlayer.kt (no extra libraries)
- Data model: data/Demo.kt, generated data: data/DemoMotions.kt and data/DemoTexts.kt
- Authoring tools (optional, need Python 3 + matplotlib): tools/  (edit poses/texts, then run
  `python3 tools/generate.py` to regenerate the Kotlin data files)
